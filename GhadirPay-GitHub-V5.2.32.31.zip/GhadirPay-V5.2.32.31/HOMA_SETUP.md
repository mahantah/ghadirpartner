# Homa CRM — V5.2.32.31

این نسخه طراحی اتوماسیون V5.2.32.29 را حفظ می‌کند و فقط ارسال API جدید هما را اصلاح می‌کند.

در `public_html/config.php` روی سرور (نه GitHub) تنظیم شود:

```php
'homa_api_token' => 'YOUR_REAL_TOKEN',
'homa_api_endpoint' => 'https://www.homacrm.com/api/v1/external/messaging/send',
```

در API جدید، شماره مقصد با فیلد `recipient` و متن با `message` ارسال می‌شود.

توکن واقعی، `config.php` و داده زنده نباید داخل GitHub یا ZIP انتشار قرار بگیرند.

لاگ ارسال شامل HTTP status، error code، requestId، endpoint و raw response است.
