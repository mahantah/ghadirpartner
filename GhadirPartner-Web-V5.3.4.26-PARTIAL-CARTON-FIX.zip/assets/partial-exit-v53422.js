(()=>{
'use strict';
function shippedSet(o){
  const set=new Set();
  (o?.exit_items||[]).forEach(it=>(it.serials||[]).forEach(sn=>set.add(String(sn).trim().toUpperCase())));
  return set;
}
function partialMode(o){return !!(o&&o.status==='ارسال شد'&&(o.partial_exit||o.incomplete_status==='تأیید شده'));}

window.prepItems=function(o){
  const shipped=shippedSet(o);
  return (o.items||[]).map((it,idx)=>{
    let p=PROD.find(p=>p.name===it.product),sr=p&&p.serial_required,serials=orderItemSerials(o,it);
    let editable=serials.filter(s=>!shipped.has(String(s).trim().toUpperCase()));
    return `<div class="card"><div style="display:flex;justify-content:space-between;gap:10px;align-items:center"><div><b class="product-name">${esc(it.product)}</b> — تعداد ${it.qty} ${sr?`— سریال ${serials.length}/${it.qty}`:'— بدون سریال اجباری'}</div>${sr?`<button class="btnlight" type="button" onclick="toggleSerialPanel(${idx})">نمایش / مدیریت سریال‌ها</button>`:''}</div>${sr?`<div id="serialPanel_${idx}" class="hidden" style="margin-top:10px;border-top:1px solid #e5ebf2;padding-top:10px">
      ${partialMode(o)?`<div class="mutedbox partial-continue-note"><b>ارسال ناقص فعال است</b><div class="small">سریال‌های «ارسال شده» قفل هستند. سریال‌های باقی‌مانده را اضافه یا ویرایش کنید و بعد ارسال باقی‌مانده را ثبت کنید.</div></div>`:''}
      <div class="mutedbox"><b>تخصیص دستی از مخزن</b><div class="small">شماره باکس را برای تخصیص همه سریال‌های آزاد آن، یا شماره یک سریال موجود را وارد کنید.</div><div class="toolbar" style="margin-top:7px"><input id="alloc_${idx}" class="code" placeholder="شماره باکس یا سریال موجود در مخزن"><button class="btn2" onclick="allocateWarehouseCode(${o.id},${idx})">تخصیص از مخزن</button></div></div>
      <div class="small" style="margin-top:9px">ثبت سریال دستی خارج از مخزن — الگو: <span class="code">${esc(p.example)}</span></div>
      <div class="toolbar" style="margin-top:8px"><input id="scan_${idx}" class="code" placeholder="سریال خارج از مخزن"><input id="imei_${idx}" class="code" inputmode="numeric" maxlength="15" placeholder="IMEI اختیاری - ۱۵ رقم"><button onclick="scanSerial(${o.id},${idx})">ثبت دستی</button><input id="sf_${idx}" type="file" accept=".xlsx,.csv"><button class="btnlight" onclick="importOrderSerials(${o.id},${idx})">ورود Excel</button></div>
      ${editable.length?`<div class="toolbar" style="margin-top:7px"><button class="danger" onclick="removeAllOrderSerials(${o.id},'${esc(it.product).replace(/'/g,'&#39;')}')">حذف سریال‌های ارسال‌نشده (${editable.length})</button></div>`:''}
      <div class="serial-list">${serials.length?serials.map(s=>{let iv=invBySerial(s,o.id),im=iv&&iv.imei?` <small>IMEI: ${esc(iv.imei)}</small>`:'',source=serialSource(iv),sent=shipped.has(String(s).trim().toUpperCase());return `<span class="serial-chip ${sent?'serial-shipped':''}"><span>${esc(s)}${im} <small>(${esc(source)})</small>${sent?` <b class="sent-lock">ارسال شده</b>`:''}</span>${sent?'':`<button class="xbtn" onclick="removeOrderSerial(${o.id},'${esc(it.product).replace(/'/g,'&#39;')}','${esc(s)}')">×</button>`}</span>`}).join(''):'<span class="small">بدون سریال</span>'}</div>
    </div>`:''}</div>`;
  }).join('');
};

const previousOpenPrep=window.openPrep;
window.openPrep=function(id){
  previousOpenPrep(id);
  const o=ORD.find(x=>x.id===id);
  if(!partialMode(o))return;
  const body=document.getElementById('modalbody');
  if(!body)return;
  const h=body.querySelector('h3');
  if(h&&!body.querySelector('.partial-exit-banner'))h.insertAdjacentHTML('afterend','<div class="mutedbox partial-exit-banner"><b>ادامه ارسال ناقص</b><div class="small">سریال‌های باقی‌مانده را ثبت کنید. سریال‌هایی که در مرحله قبل ارسال شده‌اند قفل هستند و تغییر نمی‌کنند.</div></div>');
  const save=[...body.querySelectorAll('button')].find(b=>b.getAttribute('onclick')===`saveStatus(${id})`);
  if(save){save.textContent='ثبت ارسال باقی‌مانده';save.classList.add('btn2');}
  const help=document.getElementById('statusHelp');
  if(help)help.textContent='سریال‌های جدید را ثبت کنید، وضعیت را روی «ارسال شد» نگه دارید و سپس «ثبت ارسال باقی‌مانده» را بزنید.';
};

const previousToggle=window.toggleOrderMenu;
window.toggleOrderMenu=function(ev,id){
  previousToggle(ev,id);
  const o=ORD.find(x=>x.id===id);
  if(!partialMode(o)||!has('prep'))return;
  setTimeout(()=>{
    const m=[...document.querySelectorAll('.order-menu.open')].slice(-1)[0];
    if(!m||m.querySelector('.partial-continue-action'))return;
    m.insertAdjacentHTML('beforeend',`<button class="partial-continue-action" onclick="closeOrderMenus();openPrep(${id})">📦 ثبت سریال / ارسال باقی‌مانده</button>`);
  },0);
};

const previousOpenOrderEdit=window.openOrderEdit;
window.openOrderEdit=function(id){
  previousOpenOrderEdit(id);
  const o=ORD.find(x=>x.id===id);
  if(!partialMode(o))return;
  const body=document.getElementById('modalbody'),h=body?.querySelector('h3');
  if(h)h.insertAdjacentHTML('afterend','<div class="mutedbox partial-exit-banner"><b>ویرایش سفارش دارای خروج ناقص</b><div class="small">مشتری و سریال‌های قبلاً ارسال‌شده قفل هستند؛ بخش باقی‌مانده سفارش قابل اصلاح است.</div></div>');
};

window.saveStatus=async function(id){
  const o=ORD.find(x=>x.id===id),continuing=partialMode(o)&&document.getElementById('pst')?.value==='ارسال شد';
  try{
    let isCancel=$('pst').value==='لغو شد',cr=isCancel?($('cancelReasonSelect')?.value||''):'',cn=isCancel?($('cancelNote')?.value.trim()||''):'';
    if(isCancel&&!cr)throw new Error('یکی از علت‌های لغو سفارش را انتخاب کنید');
    const r=await req('/api/status',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,status:$('pst').value,shipping_type:isCancel?'':$('ship').value,tracking_code:isCancel?'':($('trackingCode')?.value.trim()||''),cancel_reason:cr,cancel_note:cn})});
    closeModal();
    if(continuing)toast(r.partial_exit?'بخش دیگری از سفارش ارسال شد؛ هنوز باقی‌مانده دارد':'ارسال باقی‌مانده تکمیل شد');
    else toast('وضعیت سفارش تغییر کرد');
    await refresh();
  }catch(e){alert(e.message)}
};
})();