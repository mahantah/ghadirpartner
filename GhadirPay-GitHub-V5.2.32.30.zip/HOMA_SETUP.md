# تنظیم Homa CRM — V5.2.32.30

نسخه 30 از API جدید هما استفاده می‌کند:

`https://www.homacrm.com/api/v1/external/messaging/send`

## تنظیمات اصلی در `public_html/config.php`

```php
'homa_api_token' => 'TOKEN_REAL',
'homa_api_endpoint' => 'https://www.homacrm.com/api/v1/external/messaging/send',
```

توکن واقعی را داخل GitHub یا ZIP قرار ندهید.

## تغییر مهم نسخه 30

Payload پیامک جدید به‌جای `mobile` از فیلد `recipient` استفاده می‌کند:

```json
{
  "recipient": "0912XXXXXXX",
  "message": "متن پیام"
}
```

این تغییر برای رفع خطای Homa با کد `E2002` و پیام `recipient is required` انجام شده است.

## لاگ عیب‌یابی

در بخش «مرکز پیامک» اتوماسیون موارد زیر نمایش داده می‌شوند:
- HTTP Status
- کد خطا / نتیجه
- Request ID
- متن خطای API
- Raw Response
- Endpoint استفاده‌شده

Fallback قدیمی فقط در صورت تنظیم صریح `homa_legacy_fallback => true` و داشتن username/password واقعی فعال می‌شود.
