<?php
return [
    'timezone' => 'Asia/Tehran',
    'warehouse_connected' => false,
    'storage' => __DIR__ . '/storage',

    // Storage: json برای سازگاری، mysql برای نسخه تراکنشی جدید
    'storage_driver' => 'mysql',
    'mysql' => [
        'host' => 'localhost', 'port' => 3306, 'database' => '',
        'username' => '', 'password' => '', 'charset' => 'utf8mb4',
        'auto_migrate_from_json' => false,
    ],

    // Homa CRM API جدید — روش اصلی با API Token
    'homa_api_token' => '',
    'homa_api_endpoint' => 'https://www.homacrm.com/api/v1/external/messaging/send',
    // طبق تأیید پشتیبانی Homa، نام دقیق فیلد JSON خط فرستنده senderId است.
    'homa_sender_id' => '989982007480',
    // زمان انتظار درخواست در کد ۳۰ ثانیه است.

    // سرویس عمومی جایگزین؛ فقط در صورت استفاده از ارائه‌دهنده دیگری پر شود.
    'sms_endpoint' => '',
    'sms_token' => '',
    // پرداخت آنلاین تا زمان دریافت API درگاه غیرفعال بماند.
    'online_payment_enabled' => false,
    'payment_demo_enabled' => false,
    'payment_endpoint' => '',
];
