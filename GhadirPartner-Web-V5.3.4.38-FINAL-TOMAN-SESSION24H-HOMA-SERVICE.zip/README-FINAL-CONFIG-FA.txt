قدیر پارتنر — نسخه نهایی قابل تنظیم

مبنا: V5.3.4.38-INVENTORY-LAZY-API-FIX

اصلاحات این بسته:
- ماندگاری ورود اتوماسیون: 24 ساعت
- رفع تکرار پیام «ورود الزامی است»
- نمایش مبلغ نمودارهای فروش به تومان
- تنظیم خط خدماتی هما با senderId = 989982007480
- استفاده از API جدید هما:
  https://www.homacrm.com/api/v1/external/messaging/send
- عدم استفاده عملیاتی از api.homais.com

تنظیم هما در config.php خصوصی سرور:
'homa_api_token' => 'TOKEN_PRIVATE',
'homa_api_endpoint' => 'https://www.homacrm.com/api/v1/external/messaging/send',
'homa_sender_id' => '989982007480',

نکته امنیتی:
توکن واقعی API داخل این بسته قرار داده نشده است.
config.php و storage سرور هنگام به‌روزرسانی باید حفظ شوند.

پس از تنظیم، یک پیام آزمایشی به شماره‌ای که دریافت پیامک تبلیغاتی را بسته است ارسال کنید.
