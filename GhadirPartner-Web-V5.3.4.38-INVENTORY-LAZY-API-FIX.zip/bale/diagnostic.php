<?php
declare(strict_types=1);
ini_set('display_errors','0');
header('Content-Type: text/html; charset=utf-8');
try {
    require __DIR__.'/lib.php';
    ini_set('session.use_strict_mode','1');
    ini_set('session.cookie_httponly','1');
    ini_set('session.cookie_samesite','Lax');
    if(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')ini_set('session.cookie_secure','1');
    session_name('ghadir_session');session_start();
    $uid=(int)($_SESSION['uid']??0);
    $admin=false;
    if($uid>0){
        $admin=bp_state(false,function($s)use($uid){
            foreach($s['users']??[] as $u){
                if((int)($u['id']??0)===$uid)return !empty($u['active'])&&in_array('admin',$u['roles']??[],true);
            }
            return false;
        });
    }
    if(!$admin){http_response_code(403);echo 'دسترسی مدیر لازم است';exit;}
    $cfg=bp_bot_config();
    $storage=bp_bot_config_file();
    $tests=[
      'PHP'=>PHP_VERSION,
      'cURL'=>function_exists('curl_init')?'OK':'MISSING',
      'PDO MySQL'=>in_array('mysql',PDO::getAvailableDrivers(),true)?'OK':'MISSING',
      'config.php'=>is_file(dirname(__DIR__).'/config.php')?'OK':'MISSING',
      'storage dir'=>is_dir(dirname($storage))?'OK':'MISSING',
      'storage writable'=>(is_dir(dirname($storage))&&is_writable(dirname($storage)))?'YES':'NO',
      'bot config'=>is_file($storage)?'EXISTS':'NOT YET',
      'token saved'=>!empty($cfg['token'])?'YES':'NO'
    ];
    echo '<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><body style="font-family:Tahoma;background:#f5f7fb;padding:30px"><div style="max-width:800px;margin:auto;background:#fff;padding:24px;border-radius:16px">';
    echo '<h2>عیب‌یابی ربات بله</h2><table style="width:100%;border-collapse:collapse">';
    foreach($tests as $k=>$v)echo '<tr><td style="padding:8px;border-bottom:1px solid #eee"><b>'.htmlspecialchars($k,ENT_QUOTES,'UTF-8').'</b></td><td style="padding:8px;border-bottom:1px solid #eee;direction:ltr;text-align:left">'.htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8').'</td></tr>';
    echo '</table><p><a href="/bale/setup.php">بازگشت به تنظیم ربات</a></p></div></body></html>';
} catch(Throwable $e){
    http_response_code(500);
    echo '<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><body style="font-family:Tahoma;background:#fff3f3;padding:30px"><div style="max-width:800px;margin:auto;background:#fff;padding:24px;border-radius:16px">';
    echo '<h2>خطای ماژول بله</h2><pre style="direction:ltr;text-align:left;white-space:pre-wrap">'.htmlspecialchars($e->getMessage(),ENT_QUOTES,'UTF-8').'</pre></div></body></html>';
}
