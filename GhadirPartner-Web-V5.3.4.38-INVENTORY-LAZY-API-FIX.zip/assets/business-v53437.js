(()=>{
'use strict';
// V5.3.4.37 — follow-up filter + lighter startup
const isCustomerActive=c=>!c||!Object.prototype.hasOwnProperty.call(c,'active')||!!c.active;
window.gpCustomerActive=isCustomerActive;

function ensureCustomerForm(){
 const code=$('cc');if(code){code.readOnly=true;code.value='';code.placeholder='کد مشتری به‌صورت خودکار ایجاد می‌شود';code.title='کد مشتری هنگام ثبت به‌صورت خودکار ساخته می‌شود';}
 if(!$('customerActive')){
   const box=$('isMarketer')?.closest('.mutedbox');
   if(box){const l=document.createElement('label');l.style.cssText='display:flex;align-items:center;gap:8px;font-weight:700;margin-top:8px';l.innerHTML='<input id="customerActive" type="checkbox" style="width:auto" checked> مشتری فعال باشد';box.insertBefore(l,box.firstChild);}
 }
 const head=document.querySelector('#customers table thead tr');
 if(head&&!head.querySelector('[data-customer-status-head]')){const th=document.createElement('th');th.dataset.customerStatusHead='1';th.textContent='وضعیت';head.insertBefore(th,head.lastElementChild);}
}

window.renderCustOptions=function(){
 let q=$('csearch').value.trim().toLowerCase(),direct=CUST.filter(c=>!q||custText(c).toLowerCase().includes(q)),parentIds=new Set(direct.filter(c=>c.parent_marketer_id).map(c=>c.parent_marketer_id)),list=CUST.filter(c=>direct.includes(c)||parentIds.has(c.id));
 $('ocust').innerHTML='<option value="">انتخاب مشتری</option>'+list.slice(0,150).map(c=>`<option value="${c.id}" ${isCustomerActive(c)?'':'disabled'}>${c.is_marketer?'[بازاریاب] ':c.parent_marketer_id?'[زیرمجموعه] ':''}${esc(custText(c))}${isCustomerActive(c)?'':' — غیرفعال'}</option>`).join('');
 orderCustomerChanged();
};

window.orderCustomerChanged=function(){
 let id=+$('ocust').value,c=customerById(id),subs=c&&c.is_marketer?subCustomers(id):[],wrap=$('orderSubWrap');
 if(c&&!isCustomerActive(c)){wrap.classList.add('hidden');$('orderSubCustomer').innerHTML='';return;}
 if(c&&c.is_marketer&&subs.length){
   wrap.classList.remove('hidden');
   $('orderSubCustomer').innerHTML=`<option value="${c.id}">خود بازاریاب — ${esc(c.name)}</option>`+subs.map(x=>`<option value="${x.id}" ${isCustomerActive(x)?'':'disabled'}>${esc(x.code)} | ${esc(x.name)} | ${esc(x.mobile||'')}${isCustomerActive(x)?'':' — غیرفعال'}</option>`).join('');
 }else{wrap.classList.add('hidden');$('orderSubCustomer').innerHTML=''}
};

const baseCreateOrder=window.createOrder;
window.createOrder=async function(){
 let customer_id=+$('ocust').value;if(!$('orderSubWrap').classList.contains('hidden')&&+$('orderSubCustomer').value)customer_id=+$('orderSubCustomer').value;
 let c=customerById(customer_id);if(customer_id&&!isCustomerActive(c)){let m='این مشتری غیرفعال است و امکان ثبت سفارش برای او وجود ندارد';$('omsg').className='msg';$('omsg').textContent=m;return alert(m);}
 return baseCreateOrder();
};

window.renderCustomers=function(){
 ensureCustomerForm();let q=$('custSearch').value.trim().toLowerCase();
 $('ctbody').innerHTML=CUST.filter(c=>!q||[c.code,c.name,c.company,c.mobile,c.city,c.address,(marketerParent(c)||{}).name,isCustomerActive(c)?'فعال':'غیرفعال'].join(' ').toLowerCase().includes(q)).map(c=>{let p=marketerParent(c),active=isCustomerActive(c);return `<tr class="${active?'':'customer-inactive-row'}"><td><b>${esc(c.code||'-')}</b></td><td>${esc(c.name)}${c.is_marketer?'<span class="detail-badge" style="margin-right:5px">بازاریاب</span>':''}${p?`<div class="small">زیرمجموعه: ${esc(p.name)}</div>`:''}</td><td>${esc(c.company||'-')}</td><td>${esc(c.mobile||'-')}</td><td>${esc(c.city||'-')}</td><td>${esc(c.address||'-')}</td><td><span class="badge ${active?'customer-active-badge':'customer-inactive-badge'}">${active?'فعال':'غیرفعال'}</span></td><td>${has('sales')?`<button class="dots-btn" onclick="toggleCustomerMenu(event,${c.id})">⋮</button>`:'-'}</td></tr>`}).join('')||'<tr><td colspan="8">مشتری‌ای پیدا نشد.</td></tr>';
};

window.openCustomerEdit=function(id){
 let c=customerById(id),parent=marketerParent(c),marketers=marketerList().filter(x=>x.id!==id),active=isCustomerActive(c);
 modal(`<h3>ویرایش مشتری</h3><div class="grid"><input id="ecn" value="${esc(c.name||'')}"><input id="ecm" value="${esc(c.mobile||'')}"><input id="ecc" value="${esc(c.code||'')}" readonly title="کد مشتری خودکار است"><input id="ecco" value="${esc(c.company||'')}"><input id="ecnid" value="${esc(c.national_id||'')}"><input id="ecp" value="${esc(c.province||'')}"><input id="ecci" value="${esc(c.city||'')}"></div><textarea id="eca" style="width:100%;margin-top:8px">${esc(c.address||'')}</textarea><div class="mutedbox" style="margin-top:8px"><label style="display:flex;gap:8px;align-items:center;font-weight:900;color:${active?'#137a43':'#b42318'}"><input id="eCustomerActive" type="checkbox" style="width:auto" ${active?'checked':''}> مشتری فعال باشد</label><label style="display:flex;gap:8px;align-items:center;font-weight:700;margin-top:8px"><input id="eIsMarketer" type="checkbox" style="width:auto" ${c.is_marketer?'checked':''}> این مشتری بازاریاب است</label><label style="display:flex;gap:8px;align-items:center;font-weight:700;margin-top:8px"><input id="eHasMarketer" type="checkbox" style="width:auto" ${c.parent_marketer_id?'checked':''} onchange="$('eMarketerBox').classList.toggle('hidden',!this.checked)"> زیرمجموعه بازاریاب است</label><div id="eMarketerBox" class="${c.parent_marketer_id?'':'hidden'}" style="margin-top:7px"><select id="eMarketerSelect" style="width:100%"><option value="">انتخاب بازاریاب</option>${marketers.map(x=>`<option value="${x.id}" ${x.id===c.parent_marketer_id?'selected':''} ${isCustomerActive(x)?'':'disabled'}>${esc(marketerText(x))}${isCustomerActive(x)?'':' — غیرفعال'}</option>`).join('')}</select>${parent?`<div class="small">بازاریاب فعلی: ${esc(parent.name)} — ${esc(parent.code)}</div>`:''}</div></div><textarea id="ecno" style="width:100%;margin-top:8px">${esc(c.notes||'')}</textarea><div class="toolbar" style="margin-top:8px"><button onclick="saveCustomer(${id})">ذخیره</button><button class="btnlight" onclick="closeModal()">بستن</button></div>`);
};

window.saveCustomer=async function(id){try{let parent=$('eHasMarketer').checked?+$('eMarketerSelect').value:0;if($('eHasMarketer').checked&&!parent)throw new Error('بازاریاب را انتخاب کنید');await req('/api/customers/edit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,name:$('ecn').value,mobile:$('ecm').value,company:$('ecco').value,national_id:$('ecnid').value,province:$('ecp').value,city:$('ecci').value,address:$('eca').value,notes:$('ecno').value,is_marketer:$('eIsMarketer').checked,parent_marketer_id:parent,active:$('eCustomerActive').checked})});closeModal();toast('مشتری ویرایش شد');await refresh()}catch(e){alert(e.message)}};

window.addCustomer=async function(){try{let parent=$('hasMarketer').checked?+$('marketerSelect').value:0;if($('hasMarketer').checked&&!parent)throw new Error('بازاریاب را انتخاب کنید');let c=await req('/api/customers/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:$('cn').value,mobile:$('cm').value,company:$('cco').value,national_id:$('cnid').value,province:$('cp').value,city:$('cci').value,address:$('ca').value,notes:$('cno').value,is_marketer:$('isMarketer').checked,parent_marketer_id:parent,active:$('customerActive')?.checked!==false})});$('caddmsg').className='ok';$('caddmsg').textContent='مشتری '+c.name+' ثبت شد — کد مشتری: '+(c.code||'-');['cn','cm','cco','cnid','cp','cci','ca','cno','marketerSearch'].forEach(id=>{if($(id))$(id).value=''});if($('cc'))$('cc').value='';$('isMarketer').checked=false;$('hasMarketer').checked=false;if($('customerActive'))$('customerActive').checked=true;toggleMarketerPicker();await refresh()}catch(e){$('caddmsg').className='msg';$('caddmsg').textContent=e.message}};

window.toggleCustomerActive=async function(id){let c=customerById(id),next=!isCustomerActive(c);try{await req('/api/customers/edit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,active:next})});toast(next?'مشتری فعال شد':'مشتری غیرفعال شد');await refresh()}catch(e){alert(e.message)}};
const baseCustomerMenu=window.toggleCustomerMenu;
window.toggleCustomerMenu=function(ev,id){baseCustomerMenu(ev,id);let c=customerById(id),m=[...document.querySelectorAll('.customer-menu.open')].slice(-1)[0];if(c&&m&&!m.querySelector('.customer-active-toggle')){let sep=m.querySelector('.order-menu-sep');let b=document.createElement('button');b.className='customer-active-toggle';b.textContent=isCustomerActive(c)?'⏸ غیرفعال کردن مشتری':'▶ فعال کردن مشتری';b.onclick=()=>{closeCustomerMenus();toggleCustomerActive(id)};if(sep)m.insertBefore(b,sep);else m.append(b)}};

function pendingExitPredicate(o){return ((['ثبت شده','در حال آماده سازی','آماده ارسال'].includes(o.status))||(o.status==='ارسال شد'&&(o.partial_exit||o.incomplete_status==='تأیید شده')))&&(!o.approval_status||o.approval_status==='تأیید شده');}
function pendingExitOrders(){return ORD.filter(pendingExitPredicate);}
window.gpPendingExitPredicate=pendingExitPredicate;
window.GP_ORDER_SCOPE=window.GP_ORDER_SCOPE||'';

function syncOrderScopeNotice(){
 const card=document.querySelector('#orders .compact-filter');if(!card)return;
 let n=$('orderScopeNotice');
 if(window.GP_ORDER_SCOPE!=='pending_exit'){if(n)n.remove();return;}
 if(!n){n=document.createElement('div');n.id='orderScopeNotice';n.className='order-scope-notice';card.prepend(n);}
 n.innerHTML='<span><b>فیلتر پیگیری فعال است:</b> فقط سفارش‌های نیازمند خروج نمایش داده می‌شوند.</span><button type="button" class="btnlight" onclick="clearPendingExitOrders()">نمایش همه سفارش‌ها</button>';
}
window.showPendingExitOrders=function(){
 window.GP_ORDER_SCOPE='pending_exit';
 if($('osearch'))$('osearch').value='';
 if($('ofilter'))$('ofilter').value='';
 if($('opayfilter'))$('opayfilter').value='';
 show('orders');syncOrderScopeNotice();
 if(typeof goOrderPage==='function')goOrderPage(1);else renderOrders();
};
window.clearPendingExitOrders=function(){
 window.GP_ORDER_SCOPE='';
 syncOrderScopeNotice();
 if(typeof goOrderPage==='function')goOrderPage(1);else renderOrders();
};

const baseOrderFiltered=window.orderFiltered;
if(baseOrderFiltered)window.orderFiltered=function(){
 let rows=baseOrderFiltered();
 if(window.GP_ORDER_SCOPE==='pending_exit')rows=rows.filter(pendingExitPredicate);
 syncOrderScopeNotice();
 return rows;
};
window.renderShippingAlert=function(){
 let box=$('shippingAlert');if(!box){box=document.createElement('div');box.id='shippingAlert';box.className='shipping-alert hidden';let wrap=document.querySelector('#app>.wrap');if(wrap)wrap.insertBefore(box,wrap.firstChild);}
 let rows=pendingExitOrders();if(!rows.length){box.classList.add('hidden');box.innerHTML='';return;}
 let ready=rows.filter(o=>o.status==='آماده ارسال').length,prep=rows.filter(o=>o.status==='در حال آماده سازی').length,registered=rows.filter(o=>o.status==='ثبت شده').length,partial=rows.filter(o=>o.status==='ارسال شد'&&(o.partial_exit||o.incomplete_status==='تأیید شده')).length;
 let chips=rows.slice().reverse().slice(0,7).map(o=>`<button type="button" class="shipping-alert-order" onclick="show('orders');${has('prep')?`openPrep(${o.id})`:`openOrderDetails(${o.id})`}">${esc(o.number)} · ${esc(o.status==='ارسال شد'?'خروج ناقص':o.status)}</button>`).join('');
 box.innerHTML=`<div class="shipping-alert-main"><span class="shipping-alert-icon">!</span><div><b>${rows.length.toLocaleString('fa-IR')} سفارش نیازمند پیگیری خروج است</b><div class="shipping-alert-sub">آماده ارسال: ${ready.toLocaleString('fa-IR')} · در حال آماده‌سازی: ${prep.toLocaleString('fa-IR')} · ثبت‌شده: ${registered.toLocaleString('fa-IR')}${partial?` · خروج ناقص: ${partial.toLocaleString('fa-IR')}`:''}</div></div><button class="shipping-alert-all" type="button" onclick="showPendingExitOrders()">پیگیری این سفارش‌ها</button></div><div class="shipping-alert-orders">${chips}</div>`;
 box.classList.remove('hidden');
};

const baseRenderOrders=window.renderOrders;
window.renderOrders=function(){baseRenderOrders();document.querySelectorAll('#otbody tr').forEach(tr=>{let delivered=[...tr.querySelectorAll('.badge')].some(b=>b.textContent.trim()==='تحویل شد');tr.classList.toggle('order-delivered-row',delivered)});};
const baseRecent=window.renderDashboardRecentOrders;
window.renderDashboardRecentOrders=function(){baseRecent();document.querySelectorAll('#dashRecentBody tr').forEach(tr=>{let badges=[...tr.querySelectorAll('.badge')];let st=badges.map(b=>b.textContent.trim()).find(x=>x==='تحویل شد');tr.classList.toggle('order-delivered-row',!!st)});};
const baseDash=window.renderDash;
window.renderDash=function(){baseDash();renderShippingAlert();};

function install(){
 ensureCustomerForm();
 let active=document.querySelector('.tab:not(.hidden)')?.id||'dashboard';
 if(active==='neworder')renderCustOptions();
 if(active==='customers')renderCustomers();
 if(active==='orders')renderOrders();
 renderShippingAlert();
 $('addCustomerBtn').onclick=window.addCustomer;
 $('createOrderBtn').onclick=window.createOrder;
 const nav=document.querySelector('[data-tab="orders"]');
 if(nav&&!nav.dataset.scopeResetBound){nav.dataset.scopeResetBound='1';nav.addEventListener('click',()=>{if(window.GP_ORDER_SCOPE){window.GP_ORDER_SCOPE='';setTimeout(()=>{syncOrderScopeNotice();renderOrders()},0)}});}
}
setTimeout(install,250);
})();