(()=>{
'use strict';

/*
 V5.3.4.25: event-driven carton selection.
 No continuous DOM observer or polling is used.
*/
const selected = window.GP_CARTON_LABEL_SELECTION instanceof Set
  ? window.GP_CARTON_LABEL_SELECTION
  : new Set();
window.GP_CARTON_LABEL_SELECTION = selected;

function cartons(){
  return Array.isArray(window.WH?.cartons) ? window.WH.cartons : [];
}
function byCode(code){
  const v=String(code||'').trim();
  return cartons().find(c=>String(c.code||'').trim()===v);
}
function selectedIds(){
  const valid=new Set(cartons().map(c=>Number(c.id)));
  return [...selected].filter(id=>valid.has(Number(id)));
}
function visibleChecks(){
  return [...document.querySelectorAll('#warehouseBody .gp-carton-label-check')]
    .filter(cb=>{
      const row=cb.closest('tr');
      return row && !row.hidden && row.style.display!=='none';
    });
}
function syncSelectedCount(){
  const validIds=new Set(cartons().map(c=>Number(c.id)));
  [...selected].forEach(id=>{ if(!validIds.has(Number(id))) selected.delete(id); });

  const badge=document.getElementById('gpSelectedCartonCount');
  if(badge) badge.textContent=`${selected.size.toLocaleString('fa-IR')} کارتن انتخاب شده`;

  const printBtn=document.getElementById('gpPrintSelectedCartons');
  const pdfBtn=document.getElementById('gpPdfSelectedCartons');
  if(printBtn) printBtn.disabled=selected.size===0;
  if(pdfBtn) pdfBtn.disabled=selected.size===0;

  const master=document.getElementById('gpSelectVisibleCartons');
  if(master){
    const visible=visibleChecks();
    const checked=visible.filter(cb=>cb.checked);
    master.checked=visible.length>0 && checked.length===visible.length;
    master.indeterminate=checked.length>0 && checked.length<visible.length;
  }
}
function decorateRows(){
  const body=document.getElementById('warehouseBody');
  if(!body)return;

  [...body.rows].forEach(row=>{
    const codeEl=row.querySelector('td:first-child .code');
    if(!codeEl)return;

    const carton=byCode(codeEl.textContent);
    if(!carton)return;

    row.dataset.cartonId=String(carton.id);
    const cell=row.cells[0];
    let cb=cell.querySelector('.gp-carton-label-check');

    if(!cb){
      const wrap=document.createElement('label');
      wrap.className='gp-carton-check-wrap';
      wrap.title='انتخاب این کارتن برای چاپ لیبل';

      cb=document.createElement('input');
      cb.type='checkbox';
      cb.className='gp-carton-label-check';
      cb.value=String(carton.id);
      cb.setAttribute('aria-label',`انتخاب کارتن ${carton.code} برای چاپ لیبل`);
      cb.addEventListener('click',e=>e.stopPropagation());
      cb.addEventListener('change',()=>{
        const id=Number(cb.value);
        if(cb.checked)selected.add(id);
        else selected.delete(id);
        syncSelectedCount();
      });

      wrap.append(cb);
      cell.insertBefore(wrap,cell.firstChild);
    }

    cb.checked=selected.has(Number(carton.id));
  });

  syncSelectedCount();
}
function installToolbar(){
  const body=document.getElementById('warehouseBody');
  const listCard=body?.closest('.card');
  if(!listCard)return;
  if(document.getElementById('gpCartonSelectToolbar'))return;

  const box=document.createElement('div');
  box.id='gpCartonSelectToolbar';
  box.className='gp-carton-select-toolbar';
  box.innerHTML=`
    <div class="gp-carton-select-title">
      <b>چاپ انتخابی لیبل کارتن</b>
      <span class="small">هر کارتنی را که می‌خواهید تیک بزنید؛ چاپ فقط برای همان انتخاب‌ها انجام می‌شود.</span>
    </div>
    <div class="gp-carton-select-actions">
      <label class="gp-select-all-label">
        <input id="gpSelectVisibleCartons" type="checkbox">
        انتخاب همه کارتن‌های نمایش‌داده‌شده
      </label>
      <span id="gpSelectedCartonCount" class="badge">۰ کارتن انتخاب شده</span>
      <button id="gpPrintSelectedCartons" class="btn2" type="button">چاپ لیبل انتخابی TSC</button>
      <button id="gpPdfSelectedCartons" class="btnlight" type="button">PDF A4 انتخابی</button>
      <button id="gpClearCartonSelection" class="btnlight" type="button">پاک کردن انتخاب‌ها</button>
    </div>`;

  const table=listCard.querySelector('.tablewrap');
  if(table) listCard.insertBefore(box,table);
  else listCard.append(box);

  document.getElementById('gpSelectVisibleCartons')?.addEventListener('change',e=>{
    const checked=e.target.checked;
    visibleChecks().forEach(cb=>{
      cb.checked=checked;
      const id=Number(cb.value);
      if(checked)selected.add(id);
      else selected.delete(id);
    });
    syncSelectedCount();
  });

  document.getElementById('gpClearCartonSelection')?.addEventListener('click',()=>{
    selected.clear();
    document.querySelectorAll('.gp-carton-label-check').forEach(cb=>cb.checked=false);
    syncSelectedCount();
  });

  document.getElementById('gpPrintSelectedCartons')?.addEventListener('click',()=>printSelectedWarehouseCartons());
  document.getElementById('gpPdfSelectedCartons')?.addEventListener('click',()=>pdfSelectedWarehouseCartons());

  syncSelectedCount();
}
function bindVisibilitySync(){
  if(window.GP_CARTON_VISIBILITY_SYNC_BOUND)return;
  window.GP_CARTON_VISIBILITY_SYNC_BOUND=true;

  const search=document.getElementById('gpWhSearch');
  if(search){
    search.addEventListener('input',()=>requestAnimationFrame(syncSelectedCount));
  }

  const warehouse=document.getElementById('warehouse');
  if(warehouse){
    warehouse.addEventListener('click',e=>{
      if(e.target.closest('.gp-filter-tabs button')){
        requestAnimationFrame(syncSelectedCount);
      }
    });
  }
}
function bindTopPrintButton(){
  const btn=document.getElementById('gpWhPrint');
  if(!btn || btn.dataset.selectionBound==='1')return;

  btn.dataset.selectionBound='1';
  btn.textContent='چاپ لیبل انتخابی';
  btn.onclick=()=>{
    const ids=selectedIds();
    if(ids.length)return printSelectedWarehouseCartons();

    const warehouse=document.getElementById('warehouse');
    const panels=warehouse ? [...warehouse.querySelectorAll(':scope > .card')] : [];
    const printPanel=panels[1];
    if(printPanel){
      printPanel.classList.toggle('hidden');
      if(!printPanel.classList.contains('hidden'))printPanel.scrollIntoView({block:'start'});
    }else{
      alert('ابتدا یک یا چند کارتن را تیک بزنید.');
    }
  };
}
function updatePrintHelp(){
  const printCard=document.querySelector('#warehouse .gp-wh-panel:not(.gp-wh-entry)');
  const small=printCard?.querySelector('.section-title .small');
  if(small){
    small.textContent='روش اصلی: کارتن‌های دلخواه را از جدول تیک بزنید. فیلتر تاریخ و مدل برای چاپ بازه‌ای همچنان در دسترس است.';
  }
}
function initSelectionUi(){
  installToolbar();
  decorateRows();
  bindVisibilitySync();
  bindTopPrintButton();
  updatePrintHelp();
}

window.selectedWarehouseCartonIds=selectedIds;

window.printSelectedWarehouseCartons=function(){
  const ids=selectedIds();
  if(!ids.length)return alert('حداقل یک کارتن را از جدول تیک بزنید.');
  window.open('/print/warehouse-labels?ids='+encodeURIComponent(ids.join(',')),'_blank');
};
window.pdfSelectedWarehouseCartons=function(){
  const ids=selectedIds();
  if(!ids.length)return alert('حداقل یک کارتن را از جدول تیک بزنید.');
  window.open('/print/warehouse-carton-labels?pdf=1&ids='+encodeURIComponent(ids.join(',')),'_blank');
};

// Selection is primary; old range print remains available if nothing is selected.
const originalPrintWarehouseCartonLabels=window.printWarehouseCartonLabels;
window.printWarehouseCartonLabels=function(){
  const ids=selectedIds();
  if(ids.length)return window.open('/print/warehouse-labels?ids='+encodeURIComponent(ids.join(',')),'_blank');
  return originalPrintWarehouseCartonLabels?.();
};

const originalDownloadWarehouseCartonLabels=window.downloadWarehouseCartonLabels;
window.downloadWarehouseCartonLabels=function(){
  const ids=selectedIds();
  if(ids.length)return window.open('/print/warehouse-carton-labels?pdf=1&ids='+encodeURIComponent(ids.join(',')),'_blank');
  return originalDownloadWarehouseCartonLabels?.();
};

// The table is recreated here, so this is the only lifecycle hook required.
const baseRender=window.renderWarehouse;
if(typeof baseRender==='function'){
  window.renderWarehouse=function(){
    const result=baseRender.apply(this,arguments);
    initSelectionUi();
    return result;
  };
}

// One initial pass in case warehouse was rendered before this script loaded.
setTimeout(initSelectionUi,120);
})();