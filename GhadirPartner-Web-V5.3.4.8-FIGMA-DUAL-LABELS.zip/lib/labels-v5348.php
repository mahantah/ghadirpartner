<?php
/* Separate physical profiles; upgrading legacy shared settings never changes stock. */
function gp_label_documents($documents,$profile){
 $w=$profile['w'];$h=$profile['h'];$x=$profile['x'];$y=$profile['y'];
 $json=json_encode($documents,JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
 header('Content-Type:text/html; charset=utf-8');
 echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><title>قدیر پارتنر — لیبل '.$w.' × '.$h.'</title><style>
 @page{size:'.$w.'mm '.$h.'mm;margin:0}*{box-sizing:border-box}body{margin:0;background:#eef2f7;font:12px/1.65 Tahoma,Arial;color:#000}.toolbar{padding:12px;display:flex;gap:12px;align-items:center}.toolbar button{padding:10px;background:#0b1f3a;color:white;border:0;border-radius:8px;font:inherit}.label{width:'.$w.'mm;height:'.$h.'mm;padding:3mm;margin:5mm 0;background:white;position:relative;break-after:page;page-break-after:always;transform:translate('.$x.'mm,'.$y.'mm)}.label:last-child{break-after:auto;page-break-after:auto}.head{font-weight:bold;border-bottom:1px solid black;margin-bottom:2mm;direction:rtl;font-size:11px}.content{height:calc(100% - 10mm);overflow:visible}.block{overflow-wrap:anywhere;white-space:pre-wrap;margin:0 0 1mm}.serial{direction:ltr;text-align:left;font:12px/1.5 monospace}.foot{position:absolute;bottom:1mm;right:3mm;font-size:9px}.error{color:#a00;font-weight:bold}@media print{body{background:white;width:'.$w.'mm}.toolbar{display:none}.label{margin:0}}
 </style></head><body><div class="toolbar"><button id="print" disabled>چاپ / ذخیره PDF</button><span id="status">آماده‌سازی لیبل‌ها…</span><span>اندازه '.$w.' × '.$h.' میلی‌متر · مقیاس ۱۰۰٪ · حاشیه صفر</span></div><div id="pages"></div><script>window.GP_LABEL_DOCUMENTS='.$json.';</script><script src="/assets/label-pagination-v5348.js"></script></body></html>';
}
function gp_carton_label_document($c){
 $blocks=[['text'=>'مدل: '.($c['product']??'').' | رنگ: '.($c['color']??'—')],['text'=>'تعداد سریال: '.count($c['_serials']??[]).' | ظرفیت: '.($c['capacity']??'')]];
 foreach($c['_serials']??[] as $sn)$blocks[]=['text'=>(string)$sn,'serial'=>true];
 if(empty($c['_serials']))$blocks[]=['text'=>'بدون سریال ثبت‌شده'];
 return ['title'=>'قدیر پارتنر | '.($c['code']??''),'blocks'=>$blocks];
}
