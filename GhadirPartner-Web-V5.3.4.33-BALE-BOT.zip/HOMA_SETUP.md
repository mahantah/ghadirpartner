# Homa CRM — V5.3.4.31

پیکربندی نهایی API جدید Homa بر اساس تأیید مستقیم پشتیبانی:

```php
'homa_api_token' => 'YOUR_REAL_TOKEN',
'homa_api_endpoint' => 'https://www.homacrm.com/api/v1/external/messaging/send',
'homa_sender_id' => '50004310005294',
```

## Payload ارسالی

```json
{
  "recipient": "09xxxxxxxxx",
  "message": "متن پیام",
  "senderId": "50004310005294"
}
```

نکات:
- احراز هویت: `Authorization: Bearer <TOKEN>`
- فیلد صحیح خط فرستنده: `senderId` با حروف بزرگ I در `Id`
- خط تأییدشده: `50004310005294`
- timeout درخواست: ۳۰ ثانیه
- API قدیمی `api.homais.com` در مسیر عملیاتی استفاده نمی‌شود.
- تنظیم قدیمی `homa_sender_number` برای سازگاری خوانده می‌شود، ولی تنظیم پیشنهادی از این نسخه `homa_sender_id` است.
