<?php
declare(strict_types=1);

/* Ghadir Partner — Bale bot integration */

function bp_root_config(): array {
    static $cfg = null;
    if (is_array($cfg)) return $cfg;
    $file = dirname(__DIR__) . '/config.php';
    if (!is_file($file)) throw new RuntimeException('config.php اصلی پیدا نشد');
    $x = require $file;
    if (!is_array($x)) throw new RuntimeException('config.php معتبر نیست');
    $cfg = $x;
    return $cfg;
}

function bp_bot_config_file(): string {
    $root = bp_root_config();
    $storage = rtrim((string)($root['storage'] ?? (dirname(__DIR__).'/storage')), '/\\');
    if ($storage === '') $storage = dirname(__DIR__).'/storage';
    return $storage . '/bale-bot-config.php';
}
function bp_bot_config(): array {
    $file = bp_bot_config_file();
    if (!is_file($file)) {
        $legacy = __DIR__ . '/config.php';
        if (!is_file($legacy)) return [];
        $file = $legacy;
    }
    $x = require $file;
    return is_array($x) ? $x : [];
}

function bp_write_bot_config(array $cfg): void {
    $file = bp_bot_config_file();
    $dir = dirname($file);
    if (!is_dir($dir) && !@mkdir($dir, 0750, true)) throw new RuntimeException('پوشه storage برای تنظیمات ربات قابل ایجاد نیست');
    $body = "<?php\ndeclare(strict_types=1);\nreturn " . var_export($cfg, true) . ";\n";
    $tmp = $file . '.tmp-' . bin2hex(random_bytes(4));
    if (@file_put_contents($tmp, $body, LOCK_EX) === false) throw new RuntimeException('نوشتن تنظیمات ربات در storage ممکن نشد');
    @chmod($tmp, 0640);
    if (!@rename($tmp, $file)) { @unlink($tmp); throw new RuntimeException('ذخیره تنظیمات ربات ممکن نشد'); }
    @chmod($file, 0640);
}

function bp_pdo(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $cfg = bp_root_config();
    $m = is_array($cfg['mysql'] ?? null) ? $cfg['mysql'] : [];
    foreach (['database','username'] as $k) if (trim((string)($m[$k] ?? '')) === '') throw new RuntimeException('تنظیمات MySQL کامل نیست');
    $dsn = 'mysql:host=' . ($m['host'] ?? 'localhost') . ';port=' . (int)($m['port'] ?? 3306) . ';dbname=' . $m['database'] . ';charset=' . ($m['charset'] ?? 'utf8mb4');
    $pdo = new PDO($dsn, (string)$m['username'], (string)($m['password'] ?? ''), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_TIMEOUT => 5,
    ]);
    try { $pdo->exec("SET time_zone = '+03:30'"); } catch (Throwable $e) {}
    return $pdo;
}

function bp_state_defaults(array &$s): void {
    if (!isset($s['bale_bot']) || !is_array($s['bale_bot'])) $s['bale_bot'] = [];
    $b =& $s['bale_bot'];
    if (!isset($b['admin_ids']) || !is_array($b['admin_ids'])) $b['admin_ids'] = [];
    if (!isset($b['sessions']) || !is_array($b['sessions'])) $b['sessions'] = [];
    if (!isset($b['audit']) || !is_array($b['audit'])) $b['audit'] = [];
}

function bp_state(bool $write, callable $fn) {
    $pdo = bp_pdo();
    if ($write) $pdo->beginTransaction();
    try {
        $sql = 'SELECT state_json,revision FROM ghadir_state WHERE id=1' . ($write ? ' FOR UPDATE' : '');
        $row = $pdo->query($sql)->fetch();
        if (!$row) throw new RuntimeException('داده اصلی سامانه پیدا نشد');
        $s = json_decode((string)$row['state_json'], true);
        if (!is_array($s)) throw new RuntimeException('state_json نامعتبر است');
        bp_state_defaults($s);
        $r = $fn($s);
        if ($write) {
            $encoded = json_encode($s, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
            if ($encoded === false) throw new RuntimeException('ذخیره JSON ناموفق بود');
            $rev = (int)$row['revision'] + 1;
            $checksum = hash('sha256', $encoded);
            $st = $pdo->prepare('UPDATE ghadir_state SET state_json=?,revision=?,checksum=?,updated_at=NOW() WHERE id=1');
            $st->execute([$encoded, $rev, $checksum]);
            $pdo->exec("CREATE TABLE IF NOT EXISTS ghadir_state_audit (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,revision BIGINT UNSIGNED NOT NULL,checksum CHAR(64) NOT NULL,bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX idx_revision (revision),INDEX idx_created_at (created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            $st = $pdo->prepare('INSERT INTO ghadir_state_audit (revision,checksum,bytes) VALUES (?,?,?)');
            $st->execute([$rev, $checksum, strlen($encoded)]);
            $pdo->commit();
        }
        return $r;
    } catch (Throwable $e) {
        if ($write && $pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function bp_now(): string { return date('Y-m-d H:i:s'); }
function bp_digits(string $s): string {
    return strtr($s, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
}
function bp_num(string $s): int {
    $s = bp_digits($s);
    $s = preg_replace('/[^0-9]/u', '', $s) ?? '';
    return $s === '' ? 0 : (int)$s;
}
function bp_norm(string $s): string {
    $s = bp_digits(function_exists('mb_strtolower') ? mb_strtolower(trim($s), 'UTF-8') : strtolower(trim($s)));
    $s = strtr($s, ['ي'=>'ی','ك'=>'ک','ۀ'=>'ه','ة'=>'ه','‌'=>' ','–'=>'-','—'=>'-']);
    $s = preg_replace('/[^\p{L}\p{N}]+/u', ' ', $s) ?? $s;
    return trim(preg_replace('/\s+/u', ' ', $s) ?? $s);
}
function bp_safe_sub(string $s, int $n=32): string {
    return function_exists('mb_substr') ? mb_substr($s, 0, $n, 'UTF-8') : substr($s, 0, $n);
}
function bp_short_product(string $name): string {
    $n = str_replace(['دستگاه كارتخوان ','دستگاه کارتخوان ','دستگاه كش لس ','دستگاه کش لس ','رول حرارتي ','كيف دستگاه كارتخوان ','کیف دستگاه کارتخوان ','MOREFUN - ','TRENDIT- ','TRENDIT ','TOPWISE - ','PAX - ','AISINO - '], '', $name);
    return bp_safe_sub(trim($n), 28);
}
function bp_price_keys(): array {
    return [
        'panel_cash'=>'نقد', 'panel_7d'=>'۷ روزه', 'panel_1m'=>'۱ ماهه',
        'serial_1_50'=>'سریال ۱–۵۰', 'serial_51_200'=>'سریال ۵۱–۲۰۰', 'sales_agent'=>'عامل فروش'
    ];
}
function bp_price_label(string $key): string {
    $map = [
        'panel_cash'=>'ثبت در پنل — نقد','panel_7d'=>'ثبت در پنل — هفت‌روزه','panel_1m'=>'ثبت در پنل — یک‌ماهه',
        'serial_1_50'=>'سریال آزاد — ۱ تا ۵۰','serial_51_200'=>'سریال آزاد — ۵۱ تا ۲۰۰','sales_agent'=>'عامل فروش'
    ];
    return $map[$key] ?? $map['panel_cash'];
}
function bp_product_price(array $p, string $key='panel_cash'): int {
    return max(0, (int)($p['prices'][$key] ?? ($key==='panel_cash' ? ($p['price'] ?? 0) : 0)));
}
function bp_product_stock(array $s, string $product): int {
    $serialRequired = true;
    foreach ($s['products'] ?? [] as $p) if (($p['name'] ?? '') === $product) { $serialRequired = !empty($p['serial_required']); break; }
    if (!$serialRequired) {
        foreach ($s['products'] ?? [] as $p) if (($p['name'] ?? '') === $product) return max(0,(int)($p['sellable_stock'] ?? $p['stock'] ?? 0));
        return 0;
    }
    $free = 0;
    foreach ($s['inventory'] ?? [] as $iv) {
        if (($iv['product'] ?? '') !== $product) continue;
        if (!empty($iv['order_id']) || trim((string)($iv['order_number'] ?? '')) !== '') continue;
        if (trim((string)($iv['serial'] ?? '')) === '') continue;
        $free++;
    }
    return $free;
}
function bp_find_product_index(array $s, string $query): int {
    $q = bp_norm($query);
    if ($q === '') return -1;
    $aliases = [];
    foreach ($s['products'] ?? [] as $i=>$p) {
        $name=(string)($p['name']??'');
        $cands=[bp_norm($name), bp_norm(bp_short_product($name))];
        foreach ($cands as $c) if ($c !== '') $aliases[$i][]=$c;
    }
    foreach ($aliases as $i=>$aa) foreach ($aa as $a) if ($a === $q) return (int)$i;
    $matches=[];
    foreach ($aliases as $i=>$aa) foreach ($aa as $a) if (str_contains($a,$q)||str_contains($q,$a)) { $matches[(int)$i]=true; break; }
    return count($matches)===1 ? (int)array_key_first($matches) : -1;
}
function bp_find_customer_matches(array $s, string $query): array {
    $q=bp_norm($query); $out=[];
    foreach ($s['customers'] ?? [] as $c) {
        if (!empty($c['deleted'])) continue;
        $hay=bp_norm(implode(' ',[(string)($c['code']??''),(string)($c['mobile']??''),(string)($c['name']??''),(string)($c['company']??'')]));
        if ($q==='' || str_contains($hay,$q)) $out[]=$c;
        if (count($out)>=12) break;
    }
    return $out;
}
function bp_customer_active(array $c): bool { return !array_key_exists('active',$c) || !empty($c['active']); }
function bp_idx(array $a, int $id): int { foreach ($a as $i=>$x) if ((int)($x['id']??0)===$id) return (int)$i; return -1; }

function bp_effective_sender(array $s, array $customer): array {
    $pid=(int)($customer['parent_marketer_id']??0);
    if ($pid>0) {
        $mi=bp_idx($s['customers']??[],$pid);
        if ($mi>=0) {
            $m=$s['customers'][$mi];
            $name=trim((string)($m['name']??''));$company=trim((string)($m['company']??''));
            if ($company!=='') $name .= ($name!==''?' | ':'').$company;
            return ['sender_name'=>$name?:'بازاریاب','sender_mobile'=>$m['mobile']??'','sender_address'=>implode(' - ',array_filter([$m['province']??'',$m['city']??'',$m['address']??''])),'sender_marketer_id'=>$pid,'sender_source'=>'marketer'];
        }
    }
    $set=$s['settings']??[];
    return ['sender_name'=>$set['sender_name']??'قدیر پرداخت','sender_mobile'=>$set['sender_mobile']??'','sender_address'=>$set['sender_address']??'','sender_marketer_id'=>0,'sender_source'=>'default'];
}

function bp_audit(array &$s, int $uid, string $action, array $meta=[]): void {
    bp_state_defaults($s);
    $s['bale_bot']['audit'][]=['at'=>bp_now(),'user_id'=>$uid,'action'=>$action,'meta'=>$meta];
    if (count($s['bale_bot']['audit'])>500) $s['bale_bot']['audit']=array_slice($s['bale_bot']['audit'],-500);
}
function bp_is_admin(array $s, int $uid): bool {
    return in_array($uid, array_map('intval',$s['bale_bot']['admin_ids']??[]), true);
}
function bp_session_get(array $s, int $uid): array { return is_array($s['bale_bot']['sessions'][(string)$uid]??null)?$s['bale_bot']['sessions'][(string)$uid]:[]; }
function bp_session_set(array &$s, int $uid, string $step, array $data=[]): void { $s['bale_bot']['sessions'][(string)$uid]=['step'=>$step,'data'=>$data,'updated_at'=>bp_now()]; }
function bp_session_clear(array &$s, int $uid): void { unset($s['bale_bot']['sessions'][(string)$uid]); }

function bp_api(string $method, array $payload=[]): array {
    $cfg=bp_bot_config();
    $token=trim((string)($cfg['token']??''));
    if ($token==='') return ['ok'=>false,'error'=>'توکن ربات تنظیم نشده'];
    $base=rtrim((string)($cfg['api_base']??'https://tapi.bale.ai'),'/');
    $url=$base.'/bot'.$token.'/'.$method;
    $ch=curl_init($url);
    curl_setopt_array($ch,[
        CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>6,CURLOPT_TIMEOUT=>15,
        CURLOPT_HTTPHEADER=>['Content-Type: application/json','Accept: application/json'],
        CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE),
    ]);
    $raw=(string)curl_exec($ch);$err=(string)curl_error($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
    $j=json_decode($raw,true);if(!is_array($j))$j=[];
    $j['_http']=$http;$j['_raw']=$raw;$j['_curl_error']=$err;
    return $j;
}
function bp_send(int|string $chatId, string $text, array $keyboard=[]): array {
    $p=['chat_id'=>$chatId,'text'=>$text,'parse_mode'=>'HTML'];
    if ($keyboard) $p['reply_markup']=['inline_keyboard'=>$keyboard];
    return bp_api('sendMessage',$p);
}
function bp_answer_callback(string $id, string $text=''): void {
    if ($id==='') return;
    $p=['callback_query_id'=>$id]; if($text!=='')$p['text']=$text;
    bp_api('answerCallbackQuery',$p);
}
function bp_main_menu(): array {
    return [
        [['text'=>'💰 لیست قیمت','callback_data'=>'m:prices'],['text'=>'✏️ بروزرسانی قیمت','callback_data'=>'m:priceedit']],
        [['text'=>'🛒 ثبت سفارش','callback_data'=>'m:order'],['text'=>'🔎 پیگیری سفارش','callback_data'=>'m:track']],
        [['text'=>'📦 سفارش‌های اخیر','callback_data'=>'m:recent'],['text'=>'🔴 نیازمند اقدام','callback_data'=>'m:action']],
        [['text'=>'🏠 منوی اصلی','callback_data'=>'m:home']],
    ];
}
function bp_home_text(): string {
    return "قدیر پارتنر 🤖\n\nمدیریت سریع قیمت، ثبت سفارش و پیگیری سفارش‌ها از داخل بله.\n\nیکی از گزینه‌های زیر را انتخاب کنید:";
}
function bp_status_emoji(string $st): string {
    return match($st){'لغو شد'=>'🔴','در حال آماده سازی'=>'🟡','آماده ارسال'=>'🟠','ارسال شد'=>'🔵','تحویل شد'=>'🟢',default=>'⚪'};
}
function bp_order_summary(array $s, array $o): string {
    $ci=bp_idx($s['customers']??[],(int)($o['customer_id']??0));$c=$ci>=0?$s['customers'][$ci]:[];
    $lines=[];
    foreach($o['items']??[] as $it){$lines[]='• '.bp_short_product((string)($it['product']??'')).' × '.(int)($it['qty']??0);}
    $amount=(int)($o['approved_total']??$o['estimated_total']??0);
    $txt=bp_status_emoji((string)($o['status']??'')).' <b>'.($o['number']??'-')."</b>\n";
    $txt.='مشتری: '.($c['name']??$o['customer_name']??'-').(!empty($c['code'])?' | '.$c['code']:'')."\n";
    $txt.='وضعیت: '.($o['status']??'-')."\n";
    $txt.='تسویه: '.($o['payment_status']??'پرداخت نشده')."\n";
    $txt.='مبلغ: '.number_format($amount).' تومان'."\n";
    if(!empty($o['shipping_type']))$txt.='ارسال: '.$o['shipping_type'].(!empty($o['tracking_code'])?' | کد '.$o['tracking_code']:'')."\n";
    $txt.="\n".implode("\n",$lines);
    if(!empty($o['partial_exit']))$txt.="\n\n⚠️ خروج این سفارش ناقص است.";
    return $txt;
}
function bp_keyboard_products(array $s, string $prefix, int $page=0): array {
    $per=8;$products=$s['products']??[];$pages=max(1,(int)ceil(count($products)/$per));$page=max(0,min($pages-1,$page));
    $rows=[];$start=$page*$per;
    for($i=$start;$i<min(count($products),$start+$per);$i++){
        $p=$products[$i];$price=bp_product_price($p,'panel_cash');
        $rows[]=[['text'=>bp_short_product((string)($p['name']??'')).' · '.number_format($price),'callback_data'=>$prefix.':'.$i]];
    }
    $nav=[];$gp=$prefix==='pe'?'peg':($prefix==='op'?'opg':$prefix.'g');if($page>0)$nav[]=['text'=>'◀ قبلی','callback_data'=>$gp.':'.($page-1)];if($page<$pages-1)$nav[]=['text'=>'بعدی ▶','callback_data'=>$gp.':'.($page+1)];if($nav)$rows[]=$nav;
    $rows[]=[['text'=>'🏠 منو','callback_data'=>'m:home']];
    return $rows;
}

function bp_render_prices(int|string $chatId, int $page=0): void {
    $s=bp_state(false,fn($x)=>$x);$per=8;$products=$s['products']??[];$pages=max(1,(int)ceil(count($products)/$per));$page=max(0,min($pages-1,$page));
    $lines=["💰 لیست قیمت — صفحه ".($page+1)." از ".$pages];
    for($i=$page*$per;$i<min(count($products),($page+1)*$per);$i++){
        $p=$products[$i];$lines[]='• '.bp_short_product((string)$p['name']).': '.number_format(bp_product_price($p,'panel_cash')).' تومان · موجودی '.bp_product_stock($s,(string)$p['name']);
    }
    $kb=[];$nav=[];if($page>0)$nav[]=['text'=>'◀ قبلی','callback_data'=>'pp:'.($page-1)];if($page<$pages-1)$nav[]=['text'=>'بعدی ▶','callback_data'=>'pp:'.($page+1)];if($nav)$kb[]=$nav;$kb[]=[['text'=>'✏️ ویرایش قیمت','callback_data'=>'m:priceedit'],['text'=>'🏠 منو','callback_data'=>'m:home']];
    bp_send($chatId,implode("\n",$lines),$kb);
}

function bp_render_price_edit_products(int|string $chatId, int $page=0): void {
    $s=bp_state(false,fn($x)=>$x);$rows=bp_keyboard_products($s,'pe',$page);
    array_splice($rows,count($rows)-1,0,[[['text'=>'🧾 بروزرسانی گروهی','callback_data'=>'pb']]]);
    bp_send($chatId,"✏️ بروزرسانی قیمت\nمدل را انتخاب کنید یا برای چند مدل از بروزرسانی گروهی استفاده کنید.",$rows);
}
function bp_render_price_keys(int|string $chatId, int $pi): void {
    $s=bp_state(false,fn($x)=>$x);$p=$s['products'][$pi]??null;if(!$p){bp_send($chatId,'مدل پیدا نشد.',bp_main_menu());return;}
    $rows=[];foreach(bp_price_keys() as $k=>$label)$rows[]=[['text'=>$label.' · '.number_format(bp_product_price($p,$k)),'callback_data'=>'pk:'.$pi.':'.$k]];
    $rows[]=[['text'=>'🔙 مدل‌ها','callback_data'=>'m:priceedit'],['text'=>'🏠 منو','callback_data'=>'m:home']];
    bp_send($chatId,'مدل: '.bp_short_product((string)$p['name'])."\nستون قیمت موردنظر را انتخاب کنید:",$rows);
}

function bp_render_recent(int|string $chatId, bool $actionOnly=false): void {
    $s=bp_state(false,fn($x)=>$x);$orders=array_values($s['orders']??[]);
    usort($orders,fn($a,$b)=>(int)($b['id']??0)<=>(int)($a['id']??0));
    if($actionOnly)$orders=array_values(array_filter($orders,function($o){$st=(string)($o['status']??'');return in_array($st,['ثبت شده','در حال آماده سازی','آماده ارسال'],true)||($st==='ارسال شد'&&!empty($o['partial_exit']));}));
    $orders=array_slice($orders,0,12);
    if(!$orders){bp_send($chatId,$actionOnly?'✅ سفارش نیازمند اقدام وجود ندارد.':'سفارشی وجود ندارد.',bp_main_menu());return;}
    $rows=[];$lines=[$actionOnly?'🔴 سفارش‌های نیازمند اقدام':'📦 آخرین سفارش‌ها'];
    foreach($orders as $o){$ci=bp_idx($s['customers']??[],(int)($o['customer_id']??0));$c=$ci>=0?$s['customers'][$ci]:[];$rows[]=[['text'=>bp_status_emoji((string)($o['status']??'')).' '.($o['number']??'').' · '.bp_safe_sub((string)($c['name']??$o['customer_name']??''),18),'callback_data'=>'tr:'.(int)$o['id']]];}
    $rows[]=[['text'=>'🏠 منو','callback_data'=>'m:home']];bp_send($chatId,implode("\n",$lines),$rows);
}

function bp_claim_admin(int $uid, string $code): bool {
    $cfg=bp_bot_config();$expected=trim((string)($cfg['pair_code']??''));$exp=(int)($cfg['pair_expires_at']??0);
    if($expected===''||$exp<time()||!hash_equals($expected,trim($code)))return false;
    bp_state(true,function(&$s)use($uid){bp_state_defaults($s);if(!in_array($uid,array_map('intval',$s['bale_bot']['admin_ids']),true))$s['bale_bot']['admin_ids'][]=$uid;bp_audit($s,$uid,'bale_admin_claim');return true;});
    $cfg['pair_code']='';$cfg['pair_expires_at']=0;bp_write_bot_config($cfg);return true;
}

function bp_create_order(int $uid, array $draft): array {
    return bp_state(true,function(&$s)use($uid,$draft){
        $cid=(int)($draft['customer_id']??0);$ci=bp_idx($s['customers']??[],$cid);if($ci<0)throw new RuntimeException('مشتری پیدا نشد');$c=$s['customers'][$ci];if(!bp_customer_active($c))throw new RuntimeException('مشتری غیرفعال است');
        $priceKey=(string)($draft['price_key']??'panel_cash');if(!isset(bp_price_keys()[$priceKey]))$priceKey='panel_cash';
        $draftItems=is_array($draft['items']??null)?$draft['items']:[];if(!$draftItems)throw new RuntimeException('سبد سفارش خالی است');
        $items=[];$total=0;
        foreach($draftItems as $di){$pi=(int)($di['product_index']??-1);$qty=max(0,(int)($di['qty']??0));$p=$s['products'][$pi]??null;if(!$p||$qty<1)continue;$price=bp_product_price($p,$priceKey);$items[]=['product'=>$p['name'],'qty'=>$qty,'price_key'=>$priceKey,'price_label'=>bp_price_label($priceKey),'unit_price'=>$price,'line_total'=>$price*$qty,'serials'=>[]];$total+=$price*$qty;}
        if(!$items)throw new RuntimeException('قلم معتبر برای سفارش وجود ندارد');
        $id=max(1,(int)($s['next_order']??1));$s['next_order']=$id+1;$now=bp_now();$o=[
            'id'=>$id,'number'=>sprintf('GHP-%06d',$id),'customer_id'=>(int)$c['id'],'customer_name'=>$c['name']??'',
            'items'=>$items,'estimated_total'=>$total,'approved_total'=>$total,'approval_status'=>'تأیید شده',
            'payment_status'=>'پرداخت نشده','payment_method'=>'','payment_method_label'=>'','payment_details'=>[],
            'check_status'=>'','credit_status'=>'','installment_status'=>'','status'=>'ثبت شده','created_by'=>'bale:'.$uid,
            'created_at'=>$now,'updated_at'=>$now,'notes'=>'ثبت از ربات بله','history'=>[['at'=>$now,'by'=>'bale:'.$uid,'action'=>'سفارش از ربات بله ثبت شد؛ تخصیص سریال فقط دستی انجام می‌شود']]
        ];
        $o=array_merge($o,bp_effective_sender($s,$c));$s['orders'][]=$o;bp_audit($s,$uid,'order_create',['order_id'=>$id,'number'=>$o['number'],'customer_id'=>$cid,'amount'=>$total]);return $o;
    });
}

function bp_update_price(int $uid, int $pi, string $key, int $value): array {
    return bp_state(true,function(&$s)use($uid,$pi,$key,$value){
        if(!isset(bp_price_keys()[$key]))throw new RuntimeException('ستون قیمت نامعتبر است');if(!isset($s['products'][$pi]))throw new RuntimeException('مدل پیدا نشد');
        $p=&$s['products'][$pi];if(!isset($p['prices'])||!is_array($p['prices']))$p['prices']=[];$old=bp_product_price($p,$key);$p['prices'][$key]=max(0,$value);if($key==='panel_cash')$p['price']=max(0,$value);$p['price_updated_at']=bp_now();$p['price_updated_by']='bale:'.$uid;bp_audit($s,$uid,'price_update',['product'=>$p['name']??'','key'=>$key,'old'=>$old,'new'=>$value]);return ['product'=>$p['name']??'','old'=>$old,'new'=>$value,'key'=>$key];
    });
}

function bp_bulk_update_prices(int $uid, string $key, array $rows): array {
    return bp_state(true,function(&$s)use($uid,$key,$rows){
        if(!isset(bp_price_keys()[$key]))throw new RuntimeException('ستون قیمت نامعتبر است');$done=[];
        foreach($rows as $r){$pi=(int)$r['product_index'];$value=max(0,(int)$r['value']);if(!isset($s['products'][$pi]))continue;$p=&$s['products'][$pi];if(!isset($p['prices'])||!is_array($p['prices']))$p['prices']=[];$old=bp_product_price($p,$key);$p['prices'][$key]=$value;if($key==='panel_cash')$p['price']=$value;$p['price_updated_at']=bp_now();$p['price_updated_by']='bale:'.$uid;$done[]=['product'=>$p['name']??'','old'=>$old,'new'=>$value];}
        bp_audit($s,$uid,'bulk_price_update',['key'=>$key,'count'=>count($done)]);return $done;
    });
}

function bp_parse_update(array $u): array {
    $cb=is_array($u['callback_query']??null)?$u['callback_query']:null;
    if($cb){$from=$cb['from']??[];$msg=$cb['message']??[];return ['type'=>'callback','user_id'=>(int)($from['id']??0),'chat_id'=>$msg['chat']['id']??($from['id']??0),'text'=>'','data'=>(string)($cb['data']??''),'callback_id'=>(string)($cb['id']??'')];}
    $msg=is_array($u['message']??null)?$u['message']:null;
    if($msg){$from=$msg['from']??[];return ['type'=>'message','user_id'=>(int)($from['id']??0),'chat_id'=>$msg['chat']['id']??($from['id']??0),'text'=>trim((string)($msg['text']??'')),'data'=>'','callback_id'=>''];}
    return ['type'=>'unknown','user_id'=>0,'chat_id'=>0,'text'=>'','data'=>'','callback_id'=>''];
}
