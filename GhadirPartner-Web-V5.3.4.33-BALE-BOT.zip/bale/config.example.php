<?php
declare(strict_types=1);
return [
    'token' => '',
    'api_base' => 'https://tapi.bale.ai',
    'webhook_secret' => '',
    'pair_code' => '',
    'pair_expires_at' => 0,
];
