<?php
declare(strict_types=1);
require __DIR__.'/lib.php';

header('Content-Type: application/json; charset=utf-8');
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { http_response_code(405); echo '{"ok":false}'; exit; }

$cfg = bp_bot_config();
$secret = (string)($cfg['webhook_secret'] ?? '');
$given  = (string)($_GET['secret'] ?? '');
if ($secret === '' || $given === '' || !hash_equals($secret, $given)) { http_response_code(403); echo '{"ok":false}'; exit; }

$update = json_decode((string)file_get_contents('php://input'), true);
if (!is_array($update)) { echo '{"ok":true}'; exit; }
$e = bp_parse_update($update);
$uid = (int)$e['user_id'];
$chat = $e['chat_id'];
$text = (string)$e['text'];
$data = (string)$e['data'];
if ($uid < 1 || $chat === '') { echo '{"ok":true}'; exit; }

function bw_cart_text(array $s, array $draft): string {
    $key=(string)($draft['price_key']??'panel_cash');$sum=0;$lines=[];
    foreach($draft['items']??[] as $it){$p=$s['products'][(int)($it['product_index']??-1)]??null;if(!$p)continue;$q=(int)($it['qty']??0);$pr=bp_product_price($p,$key);$sum+=$pr*$q;$lines[]='• '.bp_short_product((string)$p['name']).' × '.$q.' = '.number_format($pr*$q);}
    return "🛒 <b>سبد سفارش</b>\n".($lines?implode("\n",$lines):'سبد خالی است.')."\n\nجمع: <b>".number_format($sum)." تومان</b>";
}
function bw_cart_keyboard(bool $hasItems): array {
    $rows=[[['text'=>'➕ افزودن کالا','callback_data'=>'oa'],['text'=>'🗑 حذف آخرین','callback_data'=>'od']]];
    if($hasItems)$rows[]=[['text'=>'✅ ثبت سفارش','callback_data'=>'or'],['text'=>'❌ لغو','callback_data'=>'ox']];
    else $rows[]=[['text'=>'❌ لغو','callback_data'=>'ox']];
    return $rows;
}
function bw_finish(): never { echo '{"ok":true}'; exit; }

try {
    if ($e['type'] === 'callback') bp_answer_callback((string)$e['callback_id']);

    // Public bootstrap commands before authorization.
    if ($e['type']==='message' && preg_match('/^\/claim\s+(.+)$/u',$text,$m)) {
        if (bp_claim_admin($uid, trim($m[1]))) bp_send($chat,"✅ دسترسی مدیر فعال شد.\nشناسه شما: <code>{$uid}</code>",bp_main_menu());
        else bp_send($chat,"❌ کد اتصال نامعتبر یا منقضی شده است.\nاز صفحه تنظیمات ربات در قدیر پارتنر کد جدید بسازید.");
        bw_finish();
    }
    if ($e['type']==='message' && in_array($text,['/id','id','شناسه'],true)) { bp_send($chat,"شناسه بله شما: <code>{$uid}</code>"); bw_finish(); }

    $state = bp_state(false, fn($s)=>$s);
    if (!bp_is_admin($state,$uid)) {
        if ($e['type']==='message' && str_starts_with($text,'/start')) bp_send($chat,"سلام 👋\nاین حساب هنوز مجاز نشده است.\n\nشناسه شما: <code>{$uid}</code>\nاز صفحه تنظیمات ربات کد اتصال بسازید و اینجا بفرستید:\n<code>/claim CODE</code>");
        else bp_send($chat,"⛔ این حساب اجازه استفاده از ربات مدیریتی قدیر پارتنر را ندارد.\nشناسه: <code>{$uid}</code>");
        bw_finish();
    }

    // Universal reset/menu commands.
    if ($e['type']==='message' && in_array($text,['/start','/menu','منو','خانه'],true)) {
        bp_state(true,function(&$s)use($uid){bp_session_clear($s,$uid);return true;});
        bp_send($chat,bp_home_text(),bp_main_menu()); bw_finish();
    }

    // Text input states.
    if ($e['type']==='message') {
        $sess=bp_state(false,fn($s)=>bp_session_get($s,$uid));
        $step=(string)($sess['step']??'');
        $sd=is_array($sess['data']??null)?$sess['data']:[];

        if ($step==='price_value') {
            $hasDigit=(bool)preg_match('/[0-9۰-۹٠-٩]/u',$text);$value=bp_num($text); if(!$hasDigit){bp_send($chat,'قیمت معتبر وارد کنید؛ مثال: <code>12400000</code> یا <code>0</code>');bw_finish();}
            $pi=(int)($sd['product_index']??-1);$key=(string)($sd['price_key']??'panel_cash');$s=bp_state(false,fn($x)=>$x);$p=$s['products'][$pi]??null;
            if(!$p){bp_send($chat,'مدل پیدا نشد.',bp_main_menu());bw_finish();}
            bp_state(true,function(&$s)use($uid,$pi,$key,$value){bp_session_set($s,$uid,'price_confirm',['product_index'=>$pi,'price_key'=>$key,'value'=>$value]);return true;});
            bp_send($chat,"تأیید تغییر قیمت\n\nمدل: <b>".bp_short_product((string)$p['name'])."</b>\nستون: ".(bp_price_keys()[$key]??$key)."\nقیمت فعلی: ".number_format(bp_product_price($p,$key))."\nقیمت جدید: <b>".number_format($value)." تومان</b>",[[['text'=>'✅ تأیید','callback_data'=>'pc'],['text'=>'❌ انصراف','callback_data'=>'px']]]);bw_finish();
        }

        if ($step==='bulk_lines') {
            $key=(string)($sd['price_key']??'panel_cash');$lines=preg_split('/\R+/u',$text)?:[];$s=bp_state(false,fn($x)=>$x);$rows=[];$errors=[];
            foreach($lines as $line){$line=trim($line);if($line==='')continue;if(!preg_match('/^(.*?)\s+([0-9۰-۹٠-٩,،\.]+)\s*(?:تومان)?$/u',$line,$m)){$errors[]=$line;continue;}$pi=bp_find_product_index($s,trim($m[1]));$v=bp_num($m[2]);if($pi<0){$errors[]=$line;continue;}$rows[$pi]=['product_index'=>$pi,'value'=>$v];}
            if(!$rows){bp_send($chat,"هیچ خط معتبری پیدا نشد.\nنمونه:\n<code>I90 12400000\nI80 10100000</code>");bw_finish();}
            $preview=[];foreach($rows as $r){$p=$s['products'][$r['product_index']];$preview[]='• '.bp_short_product((string)$p['name']).': '.number_format(bp_product_price($p,$key)).' ← <b>'.number_format((int)$r['value']).'</b>';}
            if($errors)$preview[]='⚠️ خطوط نامعتبر: '.count($errors);
            bp_state(true,function(&$s)use($uid,$key,$rows){bp_session_set($s,$uid,'bulk_confirm',['price_key'=>$key,'rows'=>array_values($rows)]);return true;});
            bp_send($chat,"پیش‌نمایش بروزرسانی گروهی — <b>".(bp_price_keys()[$key]??$key)."</b>\n\n".implode("\n",$preview),[[['text'=>'✅ ثبت همه','callback_data'=>'bc'],['text'=>'❌ انصراف','callback_data'=>'px']]]);bw_finish();
        }

        if ($step==='order_customer') {
            $s=bp_state(false,fn($x)=>$x);$matches=bp_find_customer_matches($s,$text);
            if(!$matches){bp_send($chat,'مشتری پیدا نشد. نام، کد مشتری یا شماره موبایل را دوباره بفرستید.');bw_finish();}
            $rows=[];foreach(array_slice($matches,0,8) as $c)$rows[]=[['text'=>(!bp_customer_active($c)?'⛔ ':'').bp_safe_sub((string)($c['name']??''),22).' · '.($c['code']??''),'callback_data'=>'oc:'.(int)$c['id']]];$rows[]=[['text'=>'❌ لغو','callback_data'=>'ox']];
            bp_send($chat,'مشتری را انتخاب کنید:',$rows);bw_finish();
        }

        if ($step==='order_qty') {
            $qty=bp_num($text);if($qty<1||$qty>10000){bp_send($chat,'تعداد معتبر وارد کنید.');bw_finish();}
            $pi=(int)($sd['product_index']??-1);
            bp_state(true,function(&$s)use($uid,$pi,$qty){$sess=bp_session_get($s,$uid);$d=$sess['data']??[];$draft=$d['draft']??[];if(!isset($draft['items'])||!is_array($draft['items']))$draft['items']=[];$found=false;foreach($draft['items'] as &$it)if((int)($it['product_index']??-1)===$pi){$it['qty']=(int)($it['qty']??0)+$qty;$found=true;break;}unset($it);if(!$found)$draft['items'][]=['product_index'=>$pi,'qty'=>$qty];bp_session_set($s,$uid,'order_cart',['draft'=>$draft]);return true;});
            $s=bp_state(false,fn($x)=>$x);$draft=bp_session_get($s,$uid)['data']['draft']??[];bp_send($chat,bw_cart_text($s,$draft),bw_cart_keyboard(!empty($draft['items'])));bw_finish();
        }

        if ($step==='track_query') {
            $q=bp_digits(trim($text));$s=bp_state(false,fn($x)=>$x);$target=null;$id=0;if(preg_match('/(\d{1,6})$/',$q,$m))$id=(int)$m[1];
            foreach($s['orders']??[] as $o)if((int)($o['id']??0)===$id||strcasecmp((string)($o['number']??''),$q)===0){$target=$o;break;}
            if(!$target){bp_send($chat,'سفارش پیدا نشد. شماره‌ای مثل <code>145</code> یا <code>GHP-000145</code> بفرستید.');bw_finish();}
            bp_state(true,function(&$s)use($uid){bp_session_clear($s,$uid);return true;});
            bp_send($chat,bp_order_summary($s,$target),[[['text'=>'🔄 بروزرسانی','callback_data'=>'tr:'.(int)$target['id']],['text'=>'🏠 منو','callback_data'=>'m:home']]]);bw_finish();
        }
    }

    // Inline callbacks.
    if ($e['type']==='callback') {
        if ($data==='m:home') {
            bp_state(true,function(&$s)use($uid){bp_session_clear($s,$uid);return true;});bp_send($chat,bp_home_text(),bp_main_menu());
        } elseif ($data==='m:prices') {
            bp_render_prices($chat,0);
        } elseif (preg_match('/^pp:(\d+)$/',$data,$m)) {
            bp_render_prices($chat,(int)$m[1]);
        } elseif ($data==='m:priceedit') {
            bp_render_price_edit_products($chat,0);
        } elseif (preg_match('/^peg:(\d+)$/',$data,$m)) {
            bp_render_price_edit_products($chat,(int)$m[1]);
        } elseif (preg_match('/^pe:(\d+)$/',$data,$m)) {
            bp_render_price_keys($chat,(int)$m[1]);
        } elseif (preg_match('/^pk:(\d+):([a-z0-9_]+)$/',$data,$m)) {
            $pi=(int)$m[1];$key=(string)$m[2];bp_state(true,function(&$s)use($uid,$pi,$key){bp_session_set($s,$uid,'price_value',['product_index'=>$pi,'price_key'=>$key]);return true;});$s=bp_state(false,fn($x)=>$x);$p=$s['products'][$pi]??[];bp_send($chat,'قیمت جدید <b>'.bp_short_product((string)($p['name']??'')).'</b> — '.(bp_price_keys()[$key]??$key)." را بفرستید.\nمثال: <code>12400000</code>");
        } elseif ($data==='pc') {
            $sess=bp_state(false,fn($s)=>bp_session_get($s,$uid));$d=$sess['data']??[];$r=bp_update_price($uid,(int)($d['product_index']??-1),(string)($d['price_key']??'panel_cash'),(int)($d['value']??0));bp_state(true,function(&$s)use($uid){bp_session_clear($s,$uid);return true;});bp_send($chat,'✅ قیمت <b>'.bp_short_product((string)$r['product']).'</b> از '.number_format((int)$r['old']).' به <b>'.number_format((int)$r['new']).' تومان</b> تغییر کرد.',bp_main_menu());
        } elseif ($data==='px') {
            bp_state(true,function(&$s)use($uid){bp_session_clear($s,$uid);return true;});bp_send($chat,'عملیات لغو شد.',bp_main_menu());
        } elseif ($data==='pb') {
            $rows=[];foreach(bp_price_keys() as $k=>$l)$rows[]=[['text'=>$l,'callback_data'=>'bk:'.$k]];$rows[]=[['text'=>'🏠 منو','callback_data'=>'m:home']];bp_send($chat,'برای بروزرسانی گروهی ابتدا ستون قیمت را انتخاب کنید:',$rows);
        } elseif (preg_match('/^bk:([a-z0-9_]+)$/',$data,$m)) {
            $key=(string)$m[1];bp_state(true,function(&$s)use($uid,$key){bp_session_set($s,$uid,'bulk_lines',['price_key'=>$key]);return true;});bp_send($chat,"هر مدل را در یک خط بفرستید؛ مثال:\n<code>I90 12400000\nI80 10100000\nMF919 11900000</code>");
        } elseif ($data==='bc') {
            $sess=bp_state(false,fn($s)=>bp_session_get($s,$uid));$d=$sess['data']??[];$done=bp_bulk_update_prices($uid,(string)($d['price_key']??'panel_cash'),is_array($d['rows']??null)?$d['rows']:[]);bp_state(true,function(&$s)use($uid){bp_session_clear($s,$uid);return true;});bp_send($chat,'✅ <b>'.count($done).'</b> قیمت با موفقیت بروزرسانی شد.',bp_main_menu());
        } elseif ($data==='m:order') {
            bp_state(true,function(&$s)use($uid){bp_session_set($s,$uid,'order_customer',['draft'=>['items'=>[]]]);return true;});bp_send($chat,"🛒 <b>ثبت سفارش</b>\nنام مشتری، کد مشتری یا شماره موبایل را بفرستید.");
        } elseif (preg_match('/^oc:(\d+)$/',$data,$m)) {
            $cid=(int)$m[1];$s=bp_state(false,fn($x)=>$x);$ci=bp_idx($s['customers']??[],$cid);$c=$ci>=0?$s['customers'][$ci]:null;
            if(!$c||!bp_customer_active($c)){bp_send($chat,'⛔ این مشتری غیرفعال است و سفارش برای او ثبت نمی‌شود.',bp_main_menu());}
            else{$rows=[];foreach(bp_price_keys() as $k=>$l)$rows[]=[['text'=>$l,'callback_data'=>'ot:'.$k]];$rows[]=[['text'=>'❌ لغو','callback_data'=>'ox']];bp_state(true,function(&$s)use($uid,$cid){bp_session_set($s,$uid,'order_price',['draft'=>['customer_id'=>$cid,'items'=>[]]]);return true;});bp_send($chat,'مشتری: <b>'.($c['name']??'').'</b> · '.($c['code']??'')."\nنوع قیمت سفارش را انتخاب کنید:",$rows);}
        } elseif (preg_match('/^ot:([a-z0-9_]+)$/',$data,$m)) {
            $key=(string)$m[1];bp_state(true,function(&$s)use($uid,$key){$sess=bp_session_get($s,$uid);$draft=$sess['data']['draft']??[];$draft['price_key']=$key;bp_session_set($s,$uid,'order_product',['draft'=>$draft]);return true;});$s=bp_state(false,fn($x)=>$x);bp_send($chat,'مدل را انتخاب کنید:',bp_keyboard_products($s,'op',0));
        } elseif (preg_match('/^opg:(\d+)$/',$data,$m)) {
            $s=bp_state(false,fn($x)=>$x);bp_send($chat,'مدل را انتخاب کنید:',bp_keyboard_products($s,'op',(int)$m[1]));
        } elseif (preg_match('/^op:(\d+)$/',$data,$m)) {
            $pi=(int)$m[1];$s=bp_state(false,fn($x)=>$x);$p=$s['products'][$pi]??null;
            if(!$p){bp_send($chat,'مدل پیدا نشد.');}
            else{$sess=bp_session_get($s,$uid);$draft=$sess['data']['draft']??[];bp_state(true,function(&$s)use($uid,$pi,$draft){bp_session_set($s,$uid,'order_qty',['draft'=>$draft,'product_index'=>$pi]);return true;});$key=(string)($draft['price_key']??'panel_cash');bp_send($chat,'مدل: <b>'.bp_short_product((string)$p['name'])."</b>\nقیمت: ".number_format(bp_product_price($p,$key))." تومان\nموجودی آزاد: ".bp_product_stock($s,(string)$p['name'])."\n\nتعداد موردنظر را بفرستید:");}
        } elseif ($data==='oa') {
            $s=bp_state(false,fn($x)=>$x);$draft=bp_session_get($s,$uid)['data']['draft']??[];bp_state(true,function(&$s)use($uid,$draft){bp_session_set($s,$uid,'order_product',['draft'=>$draft]);return true;});bp_send($chat,'مدل بعدی را انتخاب کنید:',bp_keyboard_products($s,'op',0));
        } elseif ($data==='od') {
            bp_state(true,function(&$s)use($uid){$sess=bp_session_get($s,$uid);$draft=$sess['data']['draft']??[];if(!empty($draft['items']))array_pop($draft['items']);bp_session_set($s,$uid,'order_cart',['draft'=>$draft]);return true;});$s=bp_state(false,fn($x)=>$x);$draft=bp_session_get($s,$uid)['data']['draft']??[];bp_send($chat,bw_cart_text($s,$draft),bw_cart_keyboard(!empty($draft['items'])));
        } elseif ($data==='or') {
            $sess=bp_state(false,fn($s)=>bp_session_get($s,$uid));$draft=$sess['data']['draft']??[];$o=bp_create_order($uid,$draft);bp_state(true,function(&$s)use($uid){bp_session_clear($s,$uid);return true;});$s=bp_state(false,fn($x)=>$x);bp_send($chat,"✅ سفارش ثبت شد.\n\n".bp_order_summary($s,$o),[[['text'=>'🔎 مشاهده سفارش','callback_data'=>'tr:'.(int)$o['id']],['text'=>'🏠 منو','callback_data'=>'m:home']]]);
        } elseif ($data==='ox') {
            bp_state(true,function(&$s)use($uid){bp_session_clear($s,$uid);return true;});bp_send($chat,'ثبت سفارش لغو شد.',bp_main_menu());
        } elseif ($data==='m:track') {
            bp_state(true,function(&$s)use($uid){bp_session_set($s,$uid,'track_query');return true;});bp_send($chat,"🔎 شماره سفارش را بفرستید.\nمثال: <code>145</code> یا <code>GHP-000145</code>");
        } elseif (preg_match('/^tr:(\d+)$/',$data,$m)) {
            $id=(int)$m[1];$s=bp_state(false,fn($x)=>$x);$target=null;foreach($s['orders']??[] as $o)if((int)($o['id']??0)===$id){$target=$o;break;}if($target)bp_send($chat,bp_order_summary($s,$target),[[['text'=>'🔄 بروزرسانی','callback_data'=>'tr:'.$id],['text'=>'🏠 منو','callback_data'=>'m:home']]]);else bp_send($chat,'سفارش پیدا نشد.',bp_main_menu());
        } elseif ($data==='m:recent') {
            bp_render_recent($chat,false);
        } elseif ($data==='m:action') {
            bp_render_recent($chat,true);
        } else {
            bp_send($chat,'دستور شناخته نشد.',bp_main_menu());
        }
        bw_finish();
    }

    bp_send($chat,bp_home_text(),bp_main_menu());
} catch (Throwable $ex) {
    error_log('BALE BOT ERROR: '.$ex->getMessage());
    try { bp_send($chat,'خطای موقت در ربات رخ داد. دوباره تلاش کنید یا <code>/menu</code> را بفرستید.'); } catch (Throwable $ignore) {}
}

echo '{"ok":true}';
