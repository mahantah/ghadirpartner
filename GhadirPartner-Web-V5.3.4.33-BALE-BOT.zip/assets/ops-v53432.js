(()=>{
'use strict';
// V5.3.4.32 — compact allocation browser

const statusRows={
  'ثبت شده':'order-status-registered',
  'در حال آماده سازی':'order-status-prep',
  'آماده ارسال':'order-status-ready',
  'ارسال شد':'order-status-sent',
  'تحویل شد':'order-status-delivered',
  'لغو شد':'order-status-cancel'
};
const statusNames=new Set(Object.keys(statusRows));
function paintOrderRows(selector){
  document.querySelectorAll(selector+' tr').forEach(tr=>{
    Object.values(statusRows).forEach(c=>tr.classList.remove(c));
    const status=[...tr.querySelectorAll('.badge')].map(x=>x.textContent.trim()).find(x=>statusNames.has(x));
    if(status)tr.classList.add(statusRows[status]);
  });
}
const previousRenderOrders=window.renderOrders;
if(previousRenderOrders)window.renderOrders=function(){const r=previousRenderOrders.apply(this,arguments);paintOrderRows('#otbody');return r};
const previousRecent=window.renderDashboardRecentOrders;
if(previousRecent)window.renderDashboardRecentOrders=function(){const r=previousRecent.apply(this,arguments);paintOrderRows('#dashRecentBody');return r};
setTimeout(()=>{paintOrderRows('#otbody');paintOrderRows('#dashRecentBody')},450);

let activePrepOrderId=0;
const previousOpenPrep=window.openPrep;
if(previousOpenPrep)window.openPrep=function(id){activePrepOrderId=Number(id)||0;const r=previousOpenPrep.apply(this,arguments);return r};

function escHtml(v){return typeof esc==='function'?esc(v):String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function freeInventoryFor(data,product){return (data.inventory||[]).filter(x=>!x.order_id&&String(x.product||'')===String(product||''))}
function cartonRowsFor(data,product,freeRows){
  return (data.cartons||[]).filter(c=>String(c.product||'')===String(product||'')).map(c=>{
    const rows=freeRows.filter(x=>Number(x.carton_id||0)===Number(c.id||0)||String(x.carton_code||'')===String(c.code||''));
    return {id:c.id,code:c.code,capacity:Number(c.capacity||0),free:rows.length,serials:rows.map(x=>x.serial),levels:[...new Set(rows.map(x=>x.shelf_level).filter(Boolean))]};
  }).filter(c=>c.free>0).sort((a,b)=>String(a.code).localeCompare(String(b.code),'en'));
}
async function loadAllocationOptions(orderId,idx){
  const box=$('allocStock_'+idx);if(!box)return;
  const o=ORD.find(x=>Number(x.id)===Number(orderId)),it=o?.items?.[idx];if(!o||!it){box.innerHTML='<div class="alloc-empty">قلم سفارش پیدا نشد.</div>';return}
  const current=typeof orderItemSerials==='function'?orderItemSerials(o,it):(it.serials||[]),remaining=Math.max(0,Number(it.qty||0)-current.length);
  box.innerHTML='<div class="alloc-loading">در حال دریافت موجودی آزاد…</div>';
  try{
    const data=await req('/api/warehouse');
    const free=freeInventoryFor(data,it.product),cartons=cartonRowsFor(data,it.product,free);
    const serialRows=free.slice().sort((a,b)=>String(a.serial||'').localeCompare(String(b.serial||''),'en'));
    const cartonHtml=cartons.length?cartons.map(c=>{
      const can=c.free<=remaining&&remaining>0,level=c.levels.length?' · '+c.levels.join('، '):'';
      return `<button type="button" class="alloc-carton-chip ${can?'can-allocate':'cannot-allocate'}" ${can?'':'disabled'} onclick="quickAllocateStock(${orderId},${idx},'${encodeURIComponent(c.code||'')}')" title="${can?'تخصیص کل کارتن':'تعداد سریال آزاد این کارتن از باقی‌مانده سفارش بیشتر است'}"><b>${escHtml(c.code)}</b><small>${c.free.toLocaleString('fa-IR')} آزاد${level}</small></button>`
    }).join(''):'<div class="alloc-empty compact">کارتن آزاد ندارد.</div>';
    const serialHtml=serialRows.length?serialRows.map(x=>{
      const meta=x.carton_code?'کارتن '+escHtml(x.carton_code):x.shelf_level?'قفسه '+escHtml(x.shelf_level):'آزاد';
      return `<button type="button" class="alloc-serial-btn" data-alloc-search="${escHtml(String(x.serial||'')+' '+String(x.carton_code||'')+' '+String(x.shelf_level||''))}" onclick="quickAllocateStock(${orderId},${idx},'${encodeURIComponent(x.serial||'')}')"><span>${escHtml(x.serial||'')}</span><small>${meta}</small></button>`
    }).join(''):'<div class="alloc-empty compact">سریال آزاد ندارد.</div>';
    const firstTab=cartons.length?'cartons':'serials';
    box.innerHTML=`<div class="alloc-stock-head compact">
      <div class="alloc-head-main"><b>${escHtml(it.product)}</b><span class="alloc-remaining">مانده: ${remaining.toLocaleString('fa-IR')}</span></div>
      <button type="button" class="alloc-collapse-btn" onclick="toggleAllocationCompact(${idx})" title="جمع/باز کردن">⌃</button>
    </div>
    <div class="alloc-compact-body">
      <div class="alloc-tabs">
        <button type="button" class="alloc-tab ${firstTab==='cartons'?'active':''}" data-tab="cartons" onclick="switchAllocationTab(${idx},'cartons',this)">📦 کارتن <em>${cartons.length.toLocaleString('fa-IR')}</em></button>
        <button type="button" class="alloc-tab ${firstTab==='serials'?'active':''}" data-tab="serials" onclick="switchAllocationTab(${idx},'serials',this)">🔢 سریال <em>${free.length.toLocaleString('fa-IR')}</em></button>
        <span class="alloc-mini-summary">${current.length.toLocaleString('fa-IR')}/${Number(it.qty||0).toLocaleString('fa-IR')} تخصیص</span>
      </div>
      <div class="alloc-tab-panel ${firstTab==='cartons'?'':'hidden'}" data-panel="cartons"><div class="alloc-carton-list compact">${cartonHtml}</div></div>
      <div class="alloc-tab-panel ${firstTab==='serials'?'':'hidden'}" data-panel="serials">
        <div class="alloc-search-row"><input type="search" placeholder="جستجوی سریال یا کارتن…" oninput="filterAllocationSerials(${idx},this.value)"></div>
        <div class="alloc-serials compact">${serialHtml}</div>
      </div>
    </div>`;
  }catch(e){box.innerHTML='<div class="alloc-empty compact">دریافت موجودی انبار انجام نشد: '+escHtml(e.message||e)+'</div>'}
}

window.switchAllocationTab=function(idx,name,btn){
  const box=$('allocStock_'+idx);if(!box)return;
  box.querySelectorAll('.alloc-tab').forEach(x=>x.classList.toggle('active',x===btn));
  box.querySelectorAll('.alloc-tab-panel').forEach(x=>x.classList.toggle('hidden',x.dataset.panel!==name));
};
window.toggleAllocationCompact=function(idx){
  const box=$('allocStock_'+idx);if(!box)return;
  const body=box.querySelector('.alloc-compact-body'),btn=box.querySelector('.alloc-collapse-btn');if(!body)return;
  const collapsed=body.classList.toggle('hidden');
  if(btn)btn.textContent=collapsed?'⌄':'⌃';
  box.classList.toggle('is-collapsed',collapsed);
};
window.filterAllocationSerials=function(idx,value){
  const box=$('allocStock_'+idx);if(!box)return;
  const q=String(value||'').trim().toLowerCase();
  box.querySelectorAll('.alloc-serial-btn').forEach(x=>{
    const hay=String(x.dataset.allocSearch||x.textContent||'').toLowerCase();
    x.classList.toggle('hidden',q!==''&&!hay.includes(q));
  });
};

window.loadAllocationOptions=loadAllocationOptions;

const previousToggle=window.toggleSerialPanel;
if(previousToggle)window.toggleSerialPanel=function(idx){
  previousToggle.apply(this,arguments);
  const panel=$('serialPanel_'+idx);if(!panel||panel.classList.contains('hidden'))return;
  let box=$('allocStock_'+idx);
  if(!box){box=document.createElement('div');box.id='allocStock_'+idx;box.className='alloc-stock-browser';const anchor=panel.querySelector('.mutedbox');if(anchor)anchor.insertAdjacentElement('afterend',box);else panel.prepend(box)}
  if(activePrepOrderId)loadAllocationOptions(activePrepOrderId,idx);
};

window.quickAllocateStock=async function(orderId,idx,encodedCode){
  const code=decodeURIComponent(encodedCode||''),input=$('alloc_'+idx);if(input)input.value=code;
  return window.allocateWarehouseCode(orderId,idx);
};

window.allocateWarehouseCode=async function(orderId,idx){
  let o=ORD.find(x=>Number(x.id)===Number(orderId)),it=o&&o.items&&o.items[idx],input=$('alloc_'+idx);
  try{
    if(!it||!input)throw new Error('قلم سفارش پیدا نشد');
    let code=input.value.trim().toUpperCase();if(!code)throw new Error('شماره کارتن یا سریال را انتخاب کنید');
    let x=await req('/api/order/allocate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:orderId,product:it.product,code})});
    toast(`${x.assigned} سریال از ${x.label} تخصیص یافت؛ مرحله سفارش تغییر نکرد`);
    await refresh();
    if(typeof loadInventory==='function')await loadInventory();
    closeModal();openPrep(orderId);toggleSerialPanel(idx);
  }catch(e){alert(e.message||e)}
};
})();
