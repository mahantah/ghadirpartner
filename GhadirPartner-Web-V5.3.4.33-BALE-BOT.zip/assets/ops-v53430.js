(()=>{
'use strict';

const statusRows={
  'ثبت شده':'order-status-registered',
  'در حال آماده سازی':'order-status-prep',
  'آماده ارسال':'order-status-ready',
  'ارسال شد':'order-status-sent',
  'تحویل شد':'order-status-delivered',
  'لغو شد':'order-status-cancel'
};
const statusNames=new Set(Object.keys(statusRows));
function paintOrderRows(selector){
  document.querySelectorAll(selector+' tr').forEach(tr=>{
    Object.values(statusRows).forEach(c=>tr.classList.remove(c));
    const status=[...tr.querySelectorAll('.badge')].map(x=>x.textContent.trim()).find(x=>statusNames.has(x));
    if(status)tr.classList.add(statusRows[status]);
  });
}
const previousRenderOrders=window.renderOrders;
if(previousRenderOrders)window.renderOrders=function(){const r=previousRenderOrders.apply(this,arguments);paintOrderRows('#otbody');return r};
const previousRecent=window.renderDashboardRecentOrders;
if(previousRecent)window.renderDashboardRecentOrders=function(){const r=previousRecent.apply(this,arguments);paintOrderRows('#dashRecentBody');return r};
setTimeout(()=>{paintOrderRows('#otbody');paintOrderRows('#dashRecentBody')},450);

let activePrepOrderId=0;
const previousOpenPrep=window.openPrep;
if(previousOpenPrep)window.openPrep=function(id){activePrepOrderId=Number(id)||0;const r=previousOpenPrep.apply(this,arguments);return r};

function escHtml(v){return typeof esc==='function'?esc(v):String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function freeInventoryFor(data,product){return (data.inventory||[]).filter(x=>!x.order_id&&String(x.product||'')===String(product||''))}
function cartonRowsFor(data,product,freeRows){
  return (data.cartons||[]).filter(c=>String(c.product||'')===String(product||'')).map(c=>{
    const rows=freeRows.filter(x=>Number(x.carton_id||0)===Number(c.id||0)||String(x.carton_code||'')===String(c.code||''));
    return {id:c.id,code:c.code,capacity:Number(c.capacity||0),free:rows.length,serials:rows.map(x=>x.serial),levels:[...new Set(rows.map(x=>x.shelf_level).filter(Boolean))]};
  }).filter(c=>c.free>0).sort((a,b)=>String(a.code).localeCompare(String(b.code),'en'));
}
async function loadAllocationOptions(orderId,idx){
  const box=$('allocStock_'+idx);if(!box)return;
  const o=ORD.find(x=>Number(x.id)===Number(orderId)),it=o?.items?.[idx];if(!o||!it){box.innerHTML='<div class="alloc-empty">قلم سفارش پیدا نشد.</div>';return}
  const current=typeof orderItemSerials==='function'?orderItemSerials(o,it):(it.serials||[]),remaining=Math.max(0,Number(it.qty||0)-current.length);
  box.innerHTML='<div class="alloc-loading">در حال دریافت موجودی آزاد این مدل…</div>';
  try{
    const data=await req('/api/warehouse');
    const free=freeInventoryFor(data,it.product),cartons=cartonRowsFor(data,it.product,free);
    const serialRows=free.slice().sort((a,b)=>String(a.serial||'').localeCompare(String(b.serial||''),'en'));
    const cartonHtml=cartons.length?cartons.map(c=>{
      const can=c.free<=remaining&&remaining>0,level=c.levels.length?' · قفسه '+c.levels.join('، '):'';
      return `<div class="alloc-carton"><div class="meta"><b>${escHtml(c.code)}</b><small>${c.free.toLocaleString('fa-IR')} سریال آزاد${level}</small></div><button type="button" class="${can?'btn2':'btnlight'}" ${can?'':'disabled'} onclick="quickAllocateStock(${orderId},${idx},'${encodeURIComponent(c.code||'')}')">${can?'تخصیص کارتن':'ظرفیت کافی نیست'}</button></div>`
    }).join(''):'<div class="alloc-empty">کارتن دارای سریال آزاد برای این مدل وجود ندارد.</div>';
    const serialHtml=serialRows.length?serialRows.map(x=>`<button type="button" class="alloc-serial-btn" onclick="quickAllocateStock(${orderId},${idx},'${encodeURIComponent(x.serial||'')}')">${escHtml(x.serial||'')}<small>${x.carton_code?'کارتن '+escHtml(x.carton_code):x.shelf_level?'قفسه '+escHtml(x.shelf_level):'آزاد'}</small></button>`).join(''):'<div class="alloc-empty">سریال آزاد برای این مدل وجود ندارد.</div>';
    box.innerHTML=`<div class="alloc-stock-head"><b>موجودی قابل تخصیص — ${escHtml(it.product)}</b><span class="alloc-stock-summary">باقی‌مانده سفارش: ${remaining.toLocaleString('fa-IR')} · سریال آزاد: ${free.length.toLocaleString('fa-IR')} · کارتن آزاد: ${cartons.length.toLocaleString('fa-IR')}</span></div><div class="alloc-stock-section"><div class="alloc-stock-title">کارتن‌های همین مدل</div><div class="alloc-carton-list">${cartonHtml}</div></div><div class="alloc-stock-section"><div class="alloc-stock-title">سریال‌های آزاد همین مدل — برای تخصیص روی سریال کلیک کنید</div><div class="alloc-serials">${serialHtml}</div></div>`;
  }catch(e){box.innerHTML='<div class="alloc-empty">دریافت موجودی انبار انجام نشد: '+escHtml(e.message||e)+'</div>'}
}
window.loadAllocationOptions=loadAllocationOptions;

const previousToggle=window.toggleSerialPanel;
if(previousToggle)window.toggleSerialPanel=function(idx){
  previousToggle.apply(this,arguments);
  const panel=$('serialPanel_'+idx);if(!panel||panel.classList.contains('hidden'))return;
  let box=$('allocStock_'+idx);
  if(!box){box=document.createElement('div');box.id='allocStock_'+idx;box.className='alloc-stock-browser';const anchor=panel.querySelector('.mutedbox');if(anchor)anchor.insertAdjacentElement('afterend',box);else panel.prepend(box)}
  if(activePrepOrderId)loadAllocationOptions(activePrepOrderId,idx);
};

window.quickAllocateStock=async function(orderId,idx,encodedCode){
  const code=decodeURIComponent(encodedCode||''),input=$('alloc_'+idx);if(input)input.value=code;
  return window.allocateWarehouseCode(orderId,idx);
};

window.allocateWarehouseCode=async function(orderId,idx){
  let o=ORD.find(x=>Number(x.id)===Number(orderId)),it=o&&o.items&&o.items[idx],input=$('alloc_'+idx);
  try{
    if(!it||!input)throw new Error('قلم سفارش پیدا نشد');
    let code=input.value.trim().toUpperCase();if(!code)throw new Error('شماره کارتن یا سریال را انتخاب کنید');
    let x=await req('/api/order/allocate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:orderId,product:it.product,code})});
    toast(`${x.assigned} سریال از ${x.label} تخصیص یافت؛ مرحله سفارش تغییر نکرد`);
    await refresh();
    if(typeof loadInventory==='function')await loadInventory();
    closeModal();openPrep(orderId);toggleSerialPanel(idx);
  }catch(e){alert(e.message||e)}
};
})();
