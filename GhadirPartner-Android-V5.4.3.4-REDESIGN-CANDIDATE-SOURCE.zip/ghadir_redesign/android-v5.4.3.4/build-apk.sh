#!/usr/bin/env bash
set -euo pipefail
gradle --no-daemon clean assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk GhadirPartner-Android-V5.4.3.4-REDESIGN-CANDIDATE.apk
sha256sum GhadirPartner-Android-V5.4.3.4-REDESIGN-CANDIDATE.apk
