(function(){
 if(window.__gp5434)return;window.__gp5434=true;document.body.classList.add('gp-native-redesign');
 const labels={dashboard:['پیشخوان','⌂'],orders:['سفارش‌ها','▤'],newOrder:['ثبت سفارش','＋'],catalog:['قیمت‌ها','▣'],profilePage:['حساب','♙']};
 document.querySelectorAll('#nav [data-page]').forEach(b=>{let x=labels[b.dataset.page];if(!x)return;let spans=b.querySelectorAll('span');if(spans[0])spans[0].textContent=x[1];if(spans[1])spans[1].textContent=x[0];});
 function current(){return [...document.querySelectorAll('.page')].find(p=>!p.classList.contains('hidden'))?.id||'dashboard'}
 function title(){let id=current(),x=labels[id]||['قدیر پارتنر',''];let b=document.querySelector('header .brand b');if(b)b.textContent=x[0];let s=document.querySelector('header .brand small');if(s)s.textContent='قدیر پارتنر'}
 function enhanceDashboard(){let d=document.getElementById('dashboard');if(!d||d.dataset.gp)return;d.dataset.gp=1;let g=document.createElement('div');g.className='gp-greeting';let name=(window.me&&me.customer&&me.customer.name)||'';g.innerHTML='<h2>سلام'+(name?'، '+name:'')+'</h2><p>خلاصه حساب شما</p>';let hero=d.querySelector('.hero');if(hero)hero.after(g)}
 function enhanceCatalog(){let p=document.getElementById('catalog');if(!p||p.dataset.gp)return;p.dataset.gp=1;let w=document.createElement('div');w.className='gp-mobile-search';w.innerHTML='<input type="search" placeholder="جستجوی مدل یا شرکت سازنده">';p.prepend(w);let i=w.querySelector('input');i.addEventListener('input',()=>{let q=i.value.trim().toLowerCase();document.querySelectorAll('#catalog .price-table tbody tr').forEach(r=>r.style.display=!q||r.textContent.toLowerCase().includes(q)?'block':'none')})}
 function sync(){title();enhanceDashboard();enhanceCatalog()}
 sync();new MutationObserver(sync).observe(document.getElementById('app')||document.body,{subtree:true,attributes:true,attributeFilter:['class']});
 document.addEventListener('click',e=>{if(e.target.closest('[data-page]'))setTimeout(sync,0)},true);window.gpRedesignVersion='5.4.3.4';
})();
