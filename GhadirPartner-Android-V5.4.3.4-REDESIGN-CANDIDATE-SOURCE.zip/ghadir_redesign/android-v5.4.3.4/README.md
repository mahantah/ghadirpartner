# Android V5.4.3.4 — Redesign Candidate

اپ آزمایشی WebView برای پورتال مشتری/همکار است. UI نهایی صفحه `06 — Redesign / Android` به‌صورت CSS/JS محلی روی `https://ghadirpartner.ir/partners/` اعمال می‌شود؛ بنابراین منطق ورود، سفارش، قیمت، پروفایل، دانلود و API فعلی پورتال حفظ می‌شود.

## Build
نیازمندی: JDK 17 + Android SDK 35 + Gradle 8.9

```bash
gradle --no-daemon clean assembleDebug
```

APK در `app/build/outputs/apk/debug/app-debug.apk` ساخته می‌شود.

Version: `5.4.3.4-candidate` در Debug.
این Candidate برای تست است و جایگزین Production نیست.
