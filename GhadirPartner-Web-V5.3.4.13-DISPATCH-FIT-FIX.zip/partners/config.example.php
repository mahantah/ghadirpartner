<?php
return [
    'timezone' => 'Asia/Tehran',
    'warehouse_connected' => false,
    'storage' => dirname(__DIR__) . '/storage',

    // از V5.2.32.26 تنظیمات Homa از config.php ریشه پروژه خوانده می‌شود.
    // این فایل فقط برای تنظیمات اختصاصی پرتال نگه داشته شده است.
    'payment_endpoint' => '',
];
