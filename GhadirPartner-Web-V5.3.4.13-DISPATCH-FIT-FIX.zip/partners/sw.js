const CACHE = 'ghadir-partner-v5.3.3.0-batch';
const SHELL = ['./brand-v5311.png','./icon-192-v5311.png','./icon-512-v5311.png'];
self.addEventListener('install', event => { event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL))); self.skipWaiting(); });
self.addEventListener('activate', event => { event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key))))); self.clients.claim(); });
self.addEventListener('fetch', event => {
  const req = event.request; if (req.method !== 'GET') return; const url = new URL(req.url); if (url.pathname.includes('/api/')) return;
  const isFresh = req.mode === 'navigate' || url.pathname.endsWith('/') || url.pathname.endsWith('.html') || url.pathname.endsWith('/sw.js') || url.pathname.endsWith('.webmanifest');
  if (isFresh) { event.respondWith(fetch(req, {cache:'no-store'}).catch(() => caches.match(req))); return; }
  event.respondWith(caches.match(req).then(hit => hit || fetch(req).then(resp => { const copy=resp.clone(); caches.open(CACHE).then(c=>c.put(req,copy)); return resp; })));
});
