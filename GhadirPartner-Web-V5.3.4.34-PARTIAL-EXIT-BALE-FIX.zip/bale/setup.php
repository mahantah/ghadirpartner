<?php
declare(strict_types=1);
require __DIR__.'/lib.php';

ini_set('session.use_strict_mode','1');ini_set('session.cookie_httponly','1');ini_set('session.cookie_samesite','Lax');if(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')ini_set('session.cookie_secure','1');
session_name('ghadir_session');session_start();

function hs($v): string { return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function setup_admin_ok(): bool {
    $uid=(int)($_SESSION['uid']??0);if($uid<1)return false;
    try{return bp_state(false,function($s)use($uid){foreach($s['users']??[] as $u)if((int)($u['id']??0)===$uid)return !empty($u['active'])&&in_array('admin',$u['roles']??[],true);return false;});}catch(Throwable $e){return false;}
}
if(!setup_admin_ok()){http_response_code(403);echo '<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><body style="font-family:Tahoma;background:#f5f7fb;padding:30px"><div style="max-width:720px;margin:auto;background:#fff;padding:24px;border-radius:16px"><h2>دسترسی مدیر لازم است</h2><p>ابتدا در قدیر پارتنر با حساب مدیر وارد شوید و سپس این صفحه را دوباره باز کنید.</p><a href="/">بازگشت به سامانه</a></div></body></html>';exit;}
if(empty($_SESSION['bale_setup_csrf']))$_SESSION['bale_setup_csrf']=bin2hex(random_bytes(16));
$csrf=$_SESSION['bale_setup_csrf'];$msg='';$err='';$details=[];$cfg=bp_bot_config();
$scheme=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http';$host=(string)($_SERVER['HTTP_HOST']??'ghadirpartner.ir');$baseUrl=$scheme.'://'.$host;

if(($_SERVER['REQUEST_METHOD']??'')==='POST'){
    if(!hash_equals($csrf,(string)($_POST['csrf']??''))){$err='درخواست نامعتبر است.';}else{
        $action=(string)($_POST['action']??'save');
        try{
            if($action==='save'){
                $token=trim((string)($_POST['token']??''));if($token===''&&!empty($cfg['token']))$token=(string)$cfg['token'];
                if(!preg_match('/^\d+:[A-Za-z0-9_-]{20,}$/',$token))throw new RuntimeException('فرمت Token ربات معتبر نیست.');
                $secret=bin2hex(random_bytes(20));$pair=(string)random_int(10000000,99999999);
                $next=['token'=>$token,'api_base'=>'https://tapi.bale.ai','webhook_secret'=>$secret,'pair_code'=>$pair,'pair_expires_at'=>time()+1800,'installed_at'=>bp_now()];
                bp_write_bot_config($next);$cfg=$next;
                $me=bp_api('getMe',[]);$details['getMe']=$me;
                if(empty($me['ok']))throw new RuntimeException('ارتباط با Bot API بله برقرار نشد. نتیجه getMe پایین صفحه نمایش داده می‌شود؛ Token، DNS/فایروال هاست و دسترسی به tapi.bale.ai را بررسی کنید.');
                $webhook=$baseUrl.'/bale/webhook.php?secret='.rawurlencode($secret);$wh=bp_api('setWebhook',['url'=>$webhook]);$details['setWebhook']=$wh;
                if(empty($wh['ok']))throw new RuntimeException('Token ذخیره شد ولی ثبت Webhook در بله موفق نبود. پاسخ پایین صفحه را بررسی کنید.');
                $msg='اتصال ربات و Webhook ثبت شد. حالا کد اتصال را در بله ارسال کنید: /claim '.$pair;
            }elseif($action==='pair'){
                if(empty($cfg['token']))throw new RuntimeException('ابتدا Token را ذخیره کنید.');$cfg['pair_code']=(string)random_int(10000000,99999999);$cfg['pair_expires_at']=time()+1800;bp_write_bot_config($cfg);$msg='کد اتصال جدید ساخته شد: /claim '.$cfg['pair_code'];
            }elseif($action==='test'){
                $details['getMe']=bp_api('getMe',[]);$details['webhook']=bp_api('getWebhookInfo',[]);$msg='تست انجام شد؛ نتیجه پایین صفحه نمایش داده شده است.';
            }elseif($action==='setwebhook'){
                if(empty($cfg['token'])||empty($cfg['webhook_secret']))throw new RuntimeException('تنظیمات ربات کامل نیست.');$webhook=$baseUrl.'/bale/webhook.php?secret='.rawurlencode((string)$cfg['webhook_secret']);$details['setWebhook']=bp_api('setWebhook',['url'=>$webhook]);$msg='درخواست ثبت Webhook ارسال شد.';
            }
        }catch(Throwable $e){$err=$e->getMessage();$cfg=bp_bot_config();}
    }
}
$admins=[];try{$admins=bp_state(false,fn($s)=>array_values(array_map('intval',$s['bale_bot']['admin_ids']??[])));}catch(Throwable $e){}
$pairActive=!empty($cfg['pair_code'])&&(int)($cfg['pair_expires_at']??0)>=time();
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>تنظیم ربات بله | قدیر پارتنر</title><style>
body{font-family:Tahoma,Arial;background:#f4f7fb;color:#17324e;margin:0;padding:24px}.wrap{max-width:900px;margin:auto}.card{background:#fff;border:1px solid #dbe4ee;border-radius:18px;padding:22px;margin-bottom:14px;box-shadow:0 8px 25px rgba(28,62,94,.06)}h1{font-size:22px;margin:0 0 8px}.muted{color:#708497;font-size:13px;line-height:1.9}.ok,.err{padding:12px 14px;border-radius:12px;margin:12px 0}.ok{background:#ecf9f0;border:1px solid #b9e2c5;color:#176b37}.err{background:#fff0f0;border:1px solid #e7b9b9;color:#9b2d2d}label{display:block;font-weight:800;font-size:13px;margin:12px 0 6px}input{width:100%;box-sizing:border-box;padding:11px 12px;border:1px solid #ccd9e5;border-radius:10px;font-size:14px}button,.btn{display:inline-block;border:0;border-radius:10px;padding:10px 14px;background:#153f69;color:#fff;font-weight:800;cursor:pointer;text-decoration:none;margin:5px 0 5px 5px}.secondary{background:#eef3f8;color:#254765;border:1px solid #d5e0ea}.code{font-family:Consolas,monospace;direction:ltr;text-align:left;background:#0f2440;color:#eaf4ff;padding:12px;border-radius:10px;overflow:auto}.pill{display:inline-block;background:#edf5fd;border:1px solid #cfe0ef;padding:5px 8px;border-radius:999px;margin:3px;font-size:12px}pre{white-space:pre-wrap;word-break:break-word;background:#f6f8fa;border-radius:10px;padding:12px;font-size:11px;direction:ltr;text-align:left}</style></head><body><div class="wrap">
<div class="card"><h1>🤖 ربات بله قدیر پارتنر</h1><div class="muted">اتصال امن ربات برای بروزرسانی قیمت، ثبت سفارش و پیگیری سفارش. Token در فایل خصوصی <code>storage/bale-bot-config.php</code> ذخیره می‌شود و داخل ZIP/GitHub قرار نمی‌گیرد.</div><?php if($msg):?><div class="ok"><?=hs($msg)?></div><?php endif;?><?php if($err):?><div class="err"><?=hs($err)?></div><?php endif;?></div>
<div class="card"><h3>۱) اتصال Bot API</h3><form method="post"><input type="hidden" name="csrf" value="<?=hs($csrf)?>"><input type="hidden" name="action" value="save"><label>Bot Token</label><input name="token" type="password" autocomplete="off" placeholder="توکن BotFather بله — اگر قبلاً ذخیره شده خالی بگذارید"><p class="muted">Webhook: <span class="code"><?=hs($baseUrl.'/bale/webhook.php')?></span></p><button type="submit">ذخیره و ثبت Webhook</button></form></div>
<div class="card"><h3>۲) اتصال حساب مدیر بله</h3><?php if($pairActive):?><p>در چت ربات این دستور را بفرستید:</p><div class="code">/claim <?=hs($cfg['pair_code'])?></div><p class="muted">کد تا حدود ۳۰ دقیقه معتبر است و پس از اولین استفاده باطل می‌شود.</p><?php else:?><p class="muted">کد اتصال فعال وجود ندارد.</p><?php endif;?><form method="post" style="display:inline"><input type="hidden" name="csrf" value="<?=hs($csrf)?>"><input type="hidden" name="action" value="pair"><button class="secondary">ساخت کد اتصال جدید</button></form><div style="margin-top:12px"><b>مدیران متصل:</b> <?php if($admins): foreach($admins as $a):?><span class="pill"><?=hs($a)?></span><?php endforeach; else:?><span class="muted">هنوز مدیری متصل نشده است.</span><?php endif;?></div></div>
<div class="card"><h3>۳) تست اتصال</h3><p class="muted">اگر ربات در منوی سامانه دیده نمی‌شود، همین صفحه را مستقیم باز کنید. این تست وضعیت getMe و Webhook را از خود سرور هاست بررسی می‌کند.</p><form method="post" style="display:inline"><input type="hidden" name="csrf" value="<?=hs($csrf)?>"><input type="hidden" name="action" value="test"><button class="secondary">getMe + Webhook Info</button></form><form method="post" style="display:inline"><input type="hidden" name="csrf" value="<?=hs($csrf)?>"><input type="hidden" name="action" value="setwebhook"><button class="secondary">ثبت مجدد Webhook</button></form><?php if($details):?><pre><?=hs(json_encode($details,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT))?></pre><?php endif;?></div>
<div class="card"><a class="btn secondary" href="/">بازگشت به قدیر پارتنر</a></div>
</div></body></html>
