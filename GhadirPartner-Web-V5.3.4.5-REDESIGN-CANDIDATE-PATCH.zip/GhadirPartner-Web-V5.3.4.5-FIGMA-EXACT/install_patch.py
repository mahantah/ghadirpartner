#!/usr/bin/env python3
from pathlib import Path
import re, shutil, sys
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('.').resolve()
app=root/'app.html'; portal=root/'partners'/'portal.html'
if not app.exists(): raise SystemExit('app.html not found: '+str(app))
if not portal.exists(): raise SystemExit('partners/portal.html not found: '+str(portal))
here=Path(__file__).resolve().parent
# Copy exact assets
for src,dst in [(here/'figma-exact.css',root/'figma-exact.css'),(here/'figma-exact.js',root/'figma-exact.js'),(here/'figma-android.css',root/'partners'/'figma-android.css'),(here/'figma-android.js',root/'partners'/'figma-android.js')]:
    shutil.copy2(src,dst)
# Remove previous redesign candidate hooks to avoid style conflicts.
s=app.read_text(encoding='utf-8')
s=re.sub(r'<link[^>]+(?:redesign|figma-exact)\.css[^>]*>','',s,flags=re.I)
s=re.sub(r'<script[^>]+(?:redesign|figma-exact)\.js[^>]*>\s*</script>','',s,flags=re.I)
link='<link rel="stylesheet" href="/figma-exact.css?v=5.3.4.5">'
script='<script src="/figma-exact.js?v=5.3.4.5"></script>'
s=s.replace('</head>',link+'</head>',1).replace('</body>',script+'</body>',1)
app.write_text(s,encoding='utf-8')
p=portal.read_text(encoding='utf-8')
p=re.sub(r'<link[^>]+figma-android\.css[^>]*>','',p,flags=re.I)
p=re.sub(r'<script[^>]+figma-android\.js[^>]*>\s*</script>','',p,flags=re.I)
p=p.replace('</head>','<link rel="stylesheet" href="figma-android.css?v=5.4.3.5"></head>',1).replace('</body>','<script src="figma-android.js?v=5.4.3.5"></script></body>',1)
portal.write_text(p,encoding='utf-8')
(root/'VERSION.txt').write_text('V5.3.4.5-FIGMA-EXACT\n',encoding='utf-8')
print('Installed FIGMA exact web V5.3.4.5 + partner/mobile skin V5.4.3.5')
