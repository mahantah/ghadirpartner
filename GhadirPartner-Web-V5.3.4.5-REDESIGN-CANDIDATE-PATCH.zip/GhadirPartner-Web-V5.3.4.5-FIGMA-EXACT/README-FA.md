# GhadirPartner Web V5.3.4.5 — FIGMA EXACT

این Patch جایگزین Candidate قبلی است. طراحی مستقیماً از فریم‌های Figma زیر پیاده‌سازی شده است:
- Web Dashboard: `16:2`
- Web Warehouse: `16:83`
- Web Price List: `16:142`
- Web Offers: `16:229`
- Android/Profile: `6:2`
- Android/Order Detail: `6:30`

Installer همچنین CSS/JS نسخه قبلی `redesign.css/redesign.js` را حذف می‌کند تا تداخل ظاهری ایجاد نشود.
