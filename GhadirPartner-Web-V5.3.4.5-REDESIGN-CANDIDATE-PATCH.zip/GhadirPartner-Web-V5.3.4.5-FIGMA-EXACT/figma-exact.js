/* GhadirPartner Web V5.3.4.5 — Figma exact behavior */
(function(){
  'use strict';
  if(window.__GP_FIGMA_EXACT_5345__) return; window.__GP_FIGMA_EXACT_5345__=true;
  document.body.classList.add('gp-figma-exact');
  const q=(s,r=document)=>r.querySelector(s), qa=(s,r=document)=>[...r.querySelectorAll(s)];
  const fa=n=>Number(n||0).toLocaleString('fa-IR');
  const money=n=>fa(Math.round(Number(n||0)))+' تومان';
  const esc2=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const titleMap={dashboard:'پیشخوان',orders:'سفارشات',neworder:'ثبت سفارش',customers:'مشتریان',warehouse:'انبار',inventory:'سریال‌های مشتریان',portalAdmin:'لیست قیمت و موجودی',users:'کاربران قدیرپارتنر',products:'محصولات',reports:'گزارش‌ها',settings:'تنظیمات'};

  function setupHeader(){
    const h=q('#app>header'); if(!h) return;
    let t=q('.gp-page-title',h); if(!t){t=document.createElement('div');t.className='gp-page-title';t.textContent='پیشخوان';h.prepend(t)}
    let n=q('.gp-page-note',h);if(!n){n=document.createElement('div');n.className='gp-page-note';n.textContent='پشتیبانی روی گزینه‌های منو Hover';t.after(n)}
  }
  function setupNav(){
    const nav=q('.topnav'); if(!nav) return;
    qa('.gp-sidebar-brand',nav).forEach(x=>x.remove());
    const brand=document.createElement('div');brand.className='gp-sidebar-brand';brand.innerHTML='<b>قدیر پارتنر</b><span>اتوماسیون فروش و انبار</span>';nav.prepend(brand);
    const labels={dashboard:'پیشخوان',orders:'سفارشات',neworder:'ثبت سفارش',warehouse:'انبار',inventory:'سریال‌های مشتریان',portalAdmin:'لیست قیمت و موجودی',users:'کاربران قدیرپارتنر',reports:'گزارش‌ها',settings:'تنظیمات'};
    qa('button[data-tab]',nav).forEach(b=>{let k=b.dataset.tab;if(labels[k]){b.textContent=labels[k];b.classList.remove('gp-secondary')}else{b.textContent=b.textContent.replace(/^[^\u0600-\u06FF\w]+/,'');b.classList.add('gp-secondary')}});
    let p=q('[data-tab="portalAdmin"]',nav); if(p) p.textContent='لیست قیمت و موجودی';
    if(!q('[data-gp="offers"]',nav)){
      const o=document.createElement('button');o.type='button';o.dataset.gp='offers';o.textContent='طرح‌ها و آفرها';o.onclick=()=>{if(typeof show==='function')show('portalAdmin');setPortalMode('offers');setActive('offers')};
      const users=q('[data-tab="users"]',nav);nav.insertBefore(o,users||null);
    }
    if(!q('[data-gp="sms"]',nav)){
      const s=document.createElement('button');s.type='button';s.dataset.gp='sms';s.textContent='پیامک‌ها';s.onclick=()=>{if(typeof show==='function')show('portalAdmin');setPortalMode('sms');setActive('sms')};
      const settings=q('[data-tab="settings"]',nav);nav.insertBefore(s,settings||null);
    }
    // Put primary items in Figma order.
    const keys=['dashboard','orders','neworder','warehouse','inventory','portalAdmin','users'];
    keys.forEach(k=>{const el=q('[data-tab="'+k+'"]',nav);if(el)nav.appendChild(el)});
    const off=q('[data-gp="offers"]',nav); if(off)nav.appendChild(off);
    const rep=q('[data-tab="reports"]',nav);if(rep)nav.appendChild(rep);
    const sms=q('[data-gp="sms"]',nav);if(sms)nav.appendChild(sms);
    const set=q('[data-tab="settings"]',nav);if(set)nav.appendChild(set);
    ['customers','products'].forEach(k=>{const el=q('[data-tab="'+k+'"]',nav);if(el){el.classList.add('gp-secondary');nav.appendChild(el)}});
  }
  function setActive(key){
    const nav=q('.topnav');if(!nav)return;qa('button',nav).forEach(x=>x.classList.remove('gp-active','gp-glass'));
    let el=key==='offers'?q('[data-gp="offers"]',nav):key==='sms'?q('[data-gp="sms"]',nav):q('[data-tab="'+key+'"]',nav);if(el)el.classList.add('gp-active');
    const title=q('.gp-page-title');if(title)title.textContent=key==='offers'?'طرح‌ها و آفرها':key==='sms'?'پیامک‌ها':(titleMap[key]||'قدیر پارتنر');
  }

  function buildDashboard(){
    const s=q('#dashboard');if(!s||q('.gp-dashboard',s))return;
    s.innerHTML=`<div class="gp-dashboard">
      <article class="gp-metric-card"><div class="label">فروش امروز</div><div id="gpSalesToday" class="value">۰ تومان</div><span class="pill gp-pill-green">امروز</span></article>
      <article class="gp-metric-card"><div class="label">سفارش جدید</div><div id="gpNewOrders" class="value">۰</div><span class="pill gp-pill-blue">امروز</span></article>
      <article class="gp-metric-card"><div class="label">آماده ارسال</div><div id="gpReady" class="value">۰</div><span class="pill gp-pill-orange">امروز</span></article>
      <article class="gp-metric-card"><div class="label">لغوشده</div><div id="gpCanceled" class="value">۰</div><span class="pill gp-pill-red">امروز</span></article>
      <article class="gp-sales-card"><h3 class="gp-card-title">روند فروش ۳۰ روز اخیر</h3><div id="gpSalesBars" class="gp-sales-bars"></div></article>
      <article class="gp-status-card"><h3 class="gp-card-title">وضعیت سفارش‌ها</h3><div id="gpStatusList" class="gp-status-list"></div></article>
      <article class="gp-recent-card"><h3 class="gp-card-title">سفارش‌های اخیر</h3><div class="gp-recent-head"><span>وضعیت</span><span>مبلغ</span><span>شرکت</span><span>مشتری</span><span>شماره سفارش</span></div><div id="gpRecentRows" class="gp-recent-rows"></div></article>
      <span class="hidden" id="dall"></span><span class="hidden" id="dprep"></span><span class="hidden" id="dready"></span><span class="hidden" id="dsent"></span><div class="hidden" id="statusBars"></div><div class="hidden" id="sentDeviceList"></div><button class="hidden" id="dashNewOrder"></button>
    </div>`;
  }
  function dateKey(s){return String(s||'').slice(0,10)}
  function renderDashboardExact(){
    if(typeof ORD==='undefined')return;buildDashboard();const orders=ORD||[];
    const today=new Date().toISOString().slice(0,10);const todays=orders.filter(o=>dateKey(o.created_at)===today);
    const sale=todays.reduce((a,o)=>a+(+o.approved_total||+o.estimated_total||0),0);
    q('#gpSalesToday').textContent=sale?money(sale):'۰ تومان';q('#gpNewOrders').textContent=fa(todays.length);q('#gpReady').textContent=fa(orders.filter(o=>o.status==='آماده ارسال').length);q('#gpCanceled').textContent=fa(todays.filter(o=>String(o.status).includes('لغو')).length);
    const bars=q('#gpSalesBars');let vals=[];for(let i=11;i>=0;i--){let d=new Date();d.setDate(d.getDate()-i*2);let k=d.toISOString().slice(0,10);vals.push(orders.filter(o=>dateKey(o.created_at)>=k).slice(-12).reduce((a,o)=>a+(+o.approved_total||+o.estimated_total||1),0))}let mx=Math.max(1,...vals);bars.innerHTML=vals.map((v,i)=>`<i style="height:${35+Math.round((v/mx)*120)}px" title="${money(v)}"></i>`).join('');
    const counts={wait:orders.filter(o=>['ثبت شده','در انتظار','در انتظار تأیید'].some(x=>String(o.status||o.approval_status).includes(x))).length,ready:orders.filter(o=>o.status==='آماده ارسال').length,sent:orders.filter(o=>o.status==='ارسال شد').length,done:orders.filter(o=>o.status==='تحویل شد').length,cancel:orders.filter(o=>String(o.status).includes('لغو')).length};
    q('#gpStatusList').innerHTML=`<div class="gp-status-line"><span>در انتظار</span><b class="gp-status-count wait">${fa(counts.wait)}</b></div><div class="gp-status-line"><span>آماده ارسال</span><b class="gp-status-count ready">${fa(counts.ready)}</b></div><div class="gp-status-line"><span>ارسال شد</span><b class="gp-status-count sent">${fa(counts.sent)}</b></div><div class="gp-status-line"><span>تحویل شد</span><b class="gp-status-count done">${fa(counts.done)}</b></div><div class="gp-status-line"><span>لغو شد</span><b class="gp-status-count cancel">${fa(counts.cancel)}</b></div>`;
    q('#gpRecentRows').innerHTML=orders.slice().reverse().slice(0,5).map(o=>{let c=(typeof CUST!=='undefined'?CUST:[]).find(x=>+x.id===+o.customer_id)||{};let amt=+o.approved_total||+o.estimated_total||0;return `<div class="gp-recent-row"><span><em class="gp-status-badge">${esc2(o.status||'-')}</em></span><span>${amt?money(amt):'—'}</span><span>${esc2(c.company||'-')}</span><span>${esc2(o.customer_name||c.name||'-')}</span><b dir="ltr">${esc2(o.number||'-')}</b></div>`}).join('')||'<div style="padding:35px;text-align:center;color:#98A2B3">هنوز سفارشی ثبت نشده است.</div>';
  }

  function warehouseCounts(){
    const inv=(typeof WH!=='undefined'&&WH.inventory)||[];const cartons=(typeof WH!=='undefined'&&WH.cartons)||[];const orders=(typeof ORD!=='undefined'?ORD:[]);
    return {physical:inv.filter(x=>!x.order_id&&!x.assigned_order_id).length||inv.length,reserved:inv.filter(x=>x.order_id||x.assigned_order_id).length,cartons:cartons.filter(c=>(c.serials||[]).length>=+(c.capacity||0)).length,out:orders.filter(o=>['ارسال شد','تحویل شد'].includes(o.status)).length};
  }
  function buildWarehouse(){
    const s=q('#warehouse');if(!s||q('.gp-wh-summary',s))return;
    const originals=[...s.children];const detail=document.createElement('details');detail.className='gp-legacy-tools';detail.innerHTML='<summary>ابزارهای عملیاتی و فرم‌های کامل انبار</summary>';const inner=document.createElement('div');detail.appendChild(inner);originals.forEach(x=>inner.appendChild(x));
    const top=document.createElement('div');top.innerHTML=`<div class="gp-wh-summary"><article class="gp-metric-card"><div class="label">موجودی فیزیکی</div><div id="gpWhPhysical" class="value">۰</div></article><article class="gp-metric-card reserve"><div class="label">رزرو آماده ارسال</div><div id="gpWhReserved" class="value">۰</div></article><article class="gp-metric-card"><div class="label">کارتن کامل</div><div id="gpWhCartons" class="value">۰</div></article><article class="gp-metric-card"><div class="label">خروج امروز</div><div id="gpWhOut" class="value">۰</div></article></div>
    <section class="gp-wh-panel"><h3 class="gp-card-title">مدیریت مخزن انبار</h3><div class="gp-wh-tools"><div class="gp-wh-tool"><b>ورود سریال</b><span>ثبت و حذف گروهی</span><button data-gp-wh-open>ورود</button></div><div class="gp-wh-tool primary"><b>مخزن کارتن</b><span>کارتن‌های ۲۰/۲۵/۳۰</span><button data-gp-wh-open>ورود</button></div><div class="gp-wh-tool"><b>گزارش خروج</b><span>خروج بر اساس سفارش</span><button data-gp-report>ورود</button></div><div class="gp-wh-tool"><b>لیبل مخزن</b><span>PDF یکجا A4</span><button data-gp-wh-open>ورود</button></div></div></section>
    <section class="gp-wh-exits"><div class="gp-wh-exits-head"><h3 class="gp-card-title">آخرین خروجی‌های انبار</h3><span>نام مشتری و نام شرکت در خروجی الزامی است</span></div><div class="gp-wh-placeholder">خروجی‌ها از اطلاعات واقعی سفارش و انبار خوانده می‌شوند.</div></section>`;
    while(top.firstChild)s.insertBefore(top.firstChild,detail);s.appendChild(detail);
    qa('[data-gp-wh-open]',s).forEach(b=>b.onclick=()=>{detail.open=true;setTimeout(()=>detail.scrollIntoView({behavior:'smooth',block:'start'}),30)});q('[data-gp-report]',s).onclick=()=>typeof show==='function'&&show('reports');
  }
  function renderWarehouseExact(){buildWarehouse();const c=warehouseCounts();[['gpWhPhysical',c.physical],['gpWhReserved',c.reserved],['gpWhCartons',c.cartons],['gpWhOut',c.out]].forEach(([id,v])=>{const e=q('#'+id);if(e)e.textContent=fa(v)})}

  function modelInfo(name){let s=String(name||'');let model=s,brand='';const pairs=[[/I90/i,'i90','SZZT'],[/I80/i,'i80','SZZT'],[/M3P.*4G|4G.*M3P/i,'M3P 4G','Topwise'],[/M3P/i,'M3P','Topwise'],[/H9 PRO/i,'H9 Pro','Morefun'],[/MF919/i,'MF919','Morefun'],[/T3/i,'T3','Trendit'],[/V77/i,'V77','Bayamax'],[/Z-?990/i,'Z990','Kaila'],[/Q60/i,'Q60','Pax'],[/D600/i,'D600','Techno']];for(const [r,m,b] of pairs){if(r.test(s)){model=m;brand=b;break}}return {model,brand}}
  function priceView(){
    let section=q('#portalAdmin');if(!section)return null;let box=q('.gp-price-exact',section);if(box)return box;box=document.createElement('div');box.className='gp-price-exact hidden';box.innerHTML=`<section class="gp-price-filter"><div class="gp-price-filter-label">جستجوی مدل یا سازنده</div><div class="gp-price-filter-row"><input id="gpPriceSearch" class="gp-price-search" placeholder="مثلاً i90 یا SZZT"><button class="gp-filter-btn" data-f="all">همه مدل‌ها</button><button class="gp-filter-btn" data-f="brand">همه سازنده‌ها</button><button class="gp-filter-btn" data-f="ok">موجود</button><button class="gp-filter-btn" data-f="off">ناموجود</button></div></section><div id="gpPriceCards" class="gp-price-cards"></div><section class="gp-price-table-card"><h3>نمای جدول فشرده برای لیست‌های بلند</h3><div class="gp-price-table-head"><span>وضعیت</span><span>عامل فروش</span><span>ثبت در پنل</span><span>سریال آزاد</span><span>سازنده</span><span>مدل</span></div></section><div class="gp-admin-editor-toggle"><button id="gpOpenPriceEditor">ویرایش مدیریتی قیمت‌ها و موجودی</button></div>`;section.prepend(box);q('#gpPriceSearch',box).oninput=renderPriceExact;q('#gpOpenPriceEditor',box).onclick=()=>showLegacyPortalCard('price');return box;
  }
  function renderPriceExact(){
    const box=priceView();if(!box)return;let data=(typeof PORTAL_CATALOG!=='undefined'&&PORTAL_CATALOG.length?PORTAL_CATALOG:[]);let term=(q('#gpPriceSearch',box)?.value||'').trim().toLowerCase();if(term)data=data.filter(p=>{let i=modelInfo(p.name);return (p.name+' '+i.model+' '+i.brand).toLowerCase().includes(term)});let cards=data.slice(0,3).map(p=>{let x=p.prices||{},i=modelInfo(p.name),stock=+p.stock||0,free=x.serial_1_50||p.price||0,panel=x.panel_cash||p.price||0,agent=x.sales_agent||0;return `<article class="gp-product-card"><div class="gp-product-head"><div class="gp-product-title"><b>${esc2(i.model)}</b><small>${esc2(i.brand||'')}</small></div><span class="gp-stock-pill ${stock?'ok':'off'}">${stock?'موجود':'ناموجود'}</span></div><div class="gp-price-box free"><small>سریال آزاد</small><b>${money(free)}</b></div><div class="gp-price-box panel"><small>ثبت در پنل</small><b>${money(panel)}</b></div><div class="gp-price-box agent"><small>عامل فروش</small><b>${agent?money(agent):'—'}</b></div><div class="gp-stock-note">موجودی فیزیکی / رزرو آماده ارسال</div></article>`}).join('');q('#gpPriceCards',box).innerHTML=cards||'<div class="card">هنوز قیمت قابل نمایش ثبت نشده است.</div>';
  }
  function hidePortalChildren(except){const s=q('#portalAdmin');if(!s)return;[...s.children].forEach(c=>c.classList.toggle('hidden',c!==except))}
  function showLegacyPortalCard(kind){const s=q('#portalAdmin');if(!s)return;[...s.children].forEach(c=>c.classList.remove('hidden'));const exact=q('.gp-price-exact',s);if(exact)exact.classList.add('hidden');setTimeout(()=>{let target=[...s.querySelectorAll('.card')].find(c=>{let t=c.textContent||'';return kind==='price'?t.includes('قیمت')&&t.includes('موجودی'):t.includes('طرح‌ها')});target?.scrollIntoView({behavior:'smooth',block:'start'})},30)}
  function offersView(){let s=q('#portalAdmin');if(!s)return null;let box=q('.gp-offers-exact',s);if(box)return box;box=document.createElement('div');box.className='gp-offers-exact hidden';box.innerHTML='<div class="gp-offers-title"><div><h2>مدیریت طرح‌ها و آفرها</h2><p>درصدی یا مبلغ ثابت، با محدودیت یک‌بار مصرف برای هر مشتری</p></div></div><div id="gpOffersRows"></div><button class="gp-create-offer" id="gpCreateOfferBtn">ساخت آفر جدید</button>';s.prepend(box);q('#gpCreateOfferBtn',box).onclick=()=>showLegacyPortalCard('offers');return box}
  function renderOffersExact(){let box=offersView();if(!box)return;let arr=(typeof PORTAL_OFFERS!=='undefined'?PORTAL_OFFERS:[]);q('#gpOffersRows',box).innerHTML=(arr.length?arr.slice(0,5):[{title:'۵٪ تخفیف پاییزی',badge:'درصدی',active:true,uses:120},{title:'۳۰۰ هزار تومان اعتبار',badge:'مبلغ ثابت',active:true,uses:84},{title:'ارسال رایگان شهریور',badge:'قانونی',active:false,uses:21}]).map((o,i)=>`<article class="gp-offer-row"><div class="gp-offer-name">${esc2(o.title||'آفر')}</div><span class="gp-offer-pill gp-offer-type">${esc2(o.badge||o.type||'درصدی')}</span><span class="gp-offer-pill ${o.active===false?'gp-offer-off':'gp-offer-active'}">${o.active===false?'غیرفعال':'فعال'}</span><span class="gp-offer-usage">${fa(o.uses||o.usage_count||0)} استفاده</span><button class="gp-offer-detail" onclick="window.__gpShowOfferEditor&&window.__gpShowOfferEditor()">جزئیات</button></article>`).join('');window.__gpShowOfferEditor=()=>showLegacyPortalCard('offers')}
  function smsView(){const s=q('#portalAdmin');if(!s)return null;let v=q('.gp-sms-exact',s);if(v)return v;v=document.createElement('div');v.className='gp-sms-exact card hidden';v.innerHTML='<h2 style="margin-top:0;color:#0B1F3A">پیامک‌ها</h2><p class="small">قالب‌ها، OTP و آخرین پیام‌های وضعیت از پنل فعلی مدیریت می‌شوند.</p><button class="btn2" id="gpOpenSms">باز کردن مدیریت پیامک‌ها</button>';s.prepend(v);q('#gpOpenSms',v).onclick=()=>showLegacyPortalCard('sms');return v}
  function setPortalMode(mode){const s=q('#portalAdmin');if(!s)return;if(mode==='price'){let v=priceView();hidePortalChildren(v);v.classList.remove('hidden');renderPriceExact()}else if(mode==='offers'){let v=offersView();hidePortalChildren(v);v.classList.remove('hidden');renderOffersExact()}else{let v=smsView();hidePortalChildren(v);v.classList.remove('hidden')}}
  window.setPortalMode=setPortalMode;

  setupHeader();setupNav();buildDashboard();buildWarehouse();priceView();offersView();smsView();setActive('dashboard');
  const oldShow=(typeof show==='function'?show:null);if(oldShow){show=function(t){oldShow(t);setActive(t);if(t==='dashboard')setTimeout(renderDashboardExact,0);if(t==='warehouse')setTimeout(renderWarehouseExact,0);if(t==='portalAdmin'){setPortalMode('price');setTimeout(renderPriceExact,0)}}}
  const oldDash=(typeof renderDash==='function'?renderDash:null);if(oldDash){renderDash=function(){try{oldDash()}finally{renderDashboardExact()}}}
  const oldWh=(typeof loadWarehouse==='function'?loadWarehouse:null);if(oldWh){loadWarehouse=async function(){let r=await oldWh();renderWarehouseExact();return r}}
  const oldPortal=(typeof loadPortalAdmin==='function'?loadPortalAdmin:null);if(oldPortal){loadPortalAdmin=async function(){let r=await oldPortal();renderPriceExact();renderOffersExact();return r}}
  const oldOffers=(typeof loadPortalOffers==='function'?loadPortalOffers:null);if(oldOffers){loadPortalOffers=async function(){let r=await oldOffers();renderOffersExact();return r}}
  qa('.topnav button[data-tab]').forEach(b=>b.addEventListener('click',()=>setActive(b.dataset.tab)));
  setTimeout(()=>{renderDashboardExact();renderWarehouseExact()},100);
})();
