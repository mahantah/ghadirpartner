# API Matrix — Native V5.4.0.0

## مشترک
- POST `/api/login`
- GET `/api/me`
- GET `/api/logout`

## پرتال
- POST `/api/password-reset/request`
- POST `/api/password-reset/confirm`
- GET `/api/catalog`
- GET `/api/orders`
- POST `/api/orders/add`
- GET `/api/reports/customer-summary`

## اتوماسیون
- POST `/api/staff-password-reset/request`
- POST `/api/staff-password-reset/confirm`
- GET `/api/orders`
- POST `/api/status`
- POST `/api/payment`
- GET `/api/customers`
- GET `/api/inventory`
- GET `/api/reports/sales?period=...`
