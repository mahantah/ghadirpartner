package ir.ghadirpartner.nativeapp

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val portalNav = listOf(
    NavItem("home", "پیشخوان", Icons.Default.Home),
    NavItem("orders", "سفارش‌ها", Icons.Default.ReceiptLong),
    NavItem("new", "سفارش جدید", Icons.Default.AddCircle),
    NavItem("catalog", "لیست قیمت", Icons.Default.LocalOffer),
    NavItem("profile", "پروفایل", Icons.Default.AccountCircle)
)

@Composable
fun PortalApp(api: ApiClient, me: JSONObject, onLogout: () -> Unit) {
    var screen by remember { mutableStateOf("home") }
    Scaffold(
        containerColor = Canvas,
        topBar = { BrandHeader("قدیر پارتنر", me.obj("customer").s("name").ifBlank { me.s("username") }) },
        bottomBar = { BottomBar(portalNav, screen) { screen = it } }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            Crossfade(targetState = screen, label = "portal-nav") { target ->
                when (target) {
                    "home" -> PortalHome(api) { screen = it }
                    "orders" -> PortalOrders(api)
                    "new" -> PortalNewOrder(api) { screen = "orders" }
                    "catalog" -> PortalCatalog(api)
                    else -> PortalProfile(api, me, onLogout)
                }
            }
        }
    }
}

@Composable
private fun PortalHome(api: ApiClient, navigate: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var orders by remember { mutableStateOf(emptyList<JSONObject>()) }
    var stats by remember { mutableStateOf(JSONObject()) }

    fun refresh() {
        scope.launch {
            loading = true; error = ""
            try {
                orders = (api.get("/api/orders") as JSONArray).objects().sortedByDescending { it.i("id") }
                stats = api.get("/api/reports/customer-summary") as JSONObject
            } catch (e: Exception) { error = e.message ?: "خطا در دریافت اطلاعات" }
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }
    if (loading) { LoadingPane(); return }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ErrorBanner(error) { error = "" } }
        item {
            HeroCard(
                "خرید ۳۰ روز اخیر",
                "${formatMoney(stats.obj("month").l("amount"))} تومان",
                "${stats.obj("month").i("orders")} سفارش • ${stats.obj("month").i("qty")} قلم",
                Icons.Default.TrendingUp,
                emphasis = true
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniAction("سفارش جدید", Icons.Default.AddShoppingCart, Modifier.weight(1f)) { navigate("new") }
                MiniAction("لیست قیمت", Icons.Default.LocalOffer, Modifier.weight(1f)) { navigate("catalog") }
                MiniAction("سفارش‌ها", Icons.Default.ReceiptLong, Modifier.weight(1f)) { navigate("orders") }
            }
        }
        item { SectionTitle("آخرین سفارش‌ها", "مشاهده همه") { navigate("orders") } }
        if (orders.isEmpty()) item { EmptyState("هنوز سفارشی ندارید", "از بخش سفارش جدید، اولین سفارش را ثبت کنید.") }
        items(orders.take(4), key = { it.i("id") }) { o ->
            OrderCard(
                number = o.s("number"),
                customer = "",
                status = o.s("status"),
                payment = o.s("payment_status"),
                amount = (if (o.l("approved_total") > 0) o.l("approved_total") else o.l("estimated_total")),
                date = o.s("created_at")
            ) { navigate("orders") }
        }
        item {
            SectionTitle("گزارش سریع")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("۷ روز", stats.obj("week").i("orders").toString(), "سفارش", Modifier.weight(1f))
                StatTile("۳۰ روز", stats.obj("month").i("orders").toString(), "سفارش", Modifier.weight(1f))
                StatTile("۹۰ روز", stats.obj("three_months").i("orders").toString(), "سفارش", Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun MiniAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(vertical = 16.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Orange, modifier = Modifier.size(28.dp))
            Spacer(Modifier.height(7.dp))
            Text(title, color = NavyDeep, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
private fun StatTile(title: String, value: String, caption: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Muted, fontSize = 10.sp)
            Text(value, color = NavyDeep, fontSize = 21.sp, fontWeight = FontWeight.Black)
            Text(caption, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun PortalOrders(api: ApiClient) {
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var orders by remember { mutableStateOf(emptyList<JSONObject>()) }
    var selected by remember { mutableStateOf<JSONObject?>(null) }

    fun refresh() {
        scope.launch {
            loading = true; error = ""
            try { orders = (api.get("/api/orders") as JSONArray).objects().sortedByDescending { it.i("id") } }
            catch (e: Exception) { error = e.message ?: "خطا" }
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }
    if (loading) { LoadingPane(); return }

    val filtered = orders.filter {
        query.isBlank() || listOf(it.s("number"), it.s("status"), it.s("payment_status")).any { v -> v.contains(query, true) }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        SearchBox(query, { query = it }, "جستجو در شماره یا وضعیت سفارش")
        Spacer(Modifier.height(10.dp))
        ErrorBanner(error) { error = "" }
        Spacer(Modifier.height(6.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (filtered.isEmpty()) item { EmptyState("سفارشی پیدا نشد", "فیلتر یا عبارت جستجو را تغییر دهید.") }
            items(filtered, key = { it.i("id") }) { o ->
                OrderCard(
                    o.s("number"), "", o.s("status"), o.s("payment_status"),
                    if (o.l("approved_total") > 0) o.l("approved_total") else o.l("estimated_total"), o.s("created_at")
                ) { selected = o }
            }
        }
    }
    selected?.let { PortalOrderDialog(it, onDismiss = { selected = null }) }
}

@Composable
private fun PortalOrderDialog(order: JSONObject, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن", color = Orange) } },
        title = { Text("سفارش ${order.s("number")}", color = NavyDeep, fontWeight = FontWeight.Black) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.heightIn(max = 520.dp)) {
                item {
                    Row(Modifier.fillMaxWidth()) {
                        StatusPill(order.s("payment_status")); Spacer(Modifier.weight(1f)); StatusPill(order.s("status"))
                    }
                }
                item {
                    Text("روش پرداخت درخواستی: ${order.s("requested_payment_method_label").ifBlank { "-" }}", color = NavySoft, fontSize = 12.sp)
                }
                items(order.arr("items").objects()) { it ->
                    Surface(shape = RoundedCornerShape(16.dp), color = Canvas) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.End) {
                            Text(shortProductName(it.s("product")), color = NavyDeep, fontWeight = FontWeight.Bold)
                            Text("تعداد: ${it.i("qty")} • ${it.s("price_label")}", color = Muted, fontSize = 11.sp)
                            if (it.l("line_total") > 0) Text("${formatMoney(it.l("line_total"))} تومان", color = Orange, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (order.s("tracking_code").isNotBlank()) item {
                    Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFFEAF2FF)) {
                        Text("${order.s("shipping_type")}: ${order.s("tracking_code")}", color = Color(0xFF2457A6), modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.End)
                    }
                }
                if (order.s("status") == "تحویل شد") item {
                    Text("پس از تحویل، فایل سریال‌های سفارش از نسخه وب پرتال نیز قابل دریافت است.", color = Success, fontSize = 11.sp)
                }
            }
        },
        shape = RoundedCornerShape(28.dp), containerColor = Color.White
    )
}

private data class CartLine(val product: String, val qty: Int, val priceKey: String, val priceLabel: String, val unit: Long)

@Composable
private fun PortalNewOrder(api: ApiClient, onSuccess: () -> Unit) {
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(true) }
    var submitting by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var products by remember { mutableStateOf(emptyList<JSONObject>()) }
    var selected by remember { mutableStateOf<JSONObject?>(null) }
    var qtyText by remember { mutableStateOf("1") }
    var priceKey by remember { mutableStateOf("panel_cash") }
    var invoiceType by remember { mutableStateOf("غیررسمی") }
    var payment by remember { mutableStateOf("bank_transfer") }
    var notes by remember { mutableStateOf("") }
    var cart by remember { mutableStateOf(emptyList<CartLine>()) }

    LaunchedEffect(Unit) {
        try {
            products = (api.get("/api/catalog") as JSONArray).objects().filter { it.b("available") }
            selected = products.firstOrNull { it.i("stock") > 0 }
        } catch (e: Exception) { error = e.message ?: "خطا در لیست کالا" }
        loading = false
    }
    if (loading) { LoadingPane(); return }

    val priceLabels = listOf(
        "panel_cash" to "نقد",
        "panel_7d" to "هفت‌روزه",
        "panel_1m" to "یک‌ماهه",
        "serial_1_50" to "سریال آزاد ۱ تا ۵۰",
        "serial_51_200" to "سریال آزاد ۵۱ تا ۲۰۰",
        "sales_agent" to "عامل فروش"
    )
    val selectedPrices = selected?.obj("prices") ?: JSONObject()
    val activePriceLabels = priceLabels.filter { selectedPrices.optLong(it.first, 0) > 0 }
    if (activePriceLabels.none { it.first == priceKey }) priceKey = activePriceLabels.firstOrNull()?.first ?: "panel_cash"

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("ثبت سفارش جدید", color = NavyDeep, fontSize = 22.sp, fontWeight = FontWeight.Black, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
            Text("کالاها را اضافه کنید و روش پرداخت را همان ابتدا مشخص کنید.", color = Muted, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
        }
        item { ErrorBanner(error) { error = "" } }
        item {
            DropdownField(
                title = "انتخاب محصول",
                value = selected?.let { "${shortProductName(it.s("name"))} — موجودی ${it.i("stock")}" } ?: "انتخاب کنید",
                options = products.filter { it.i("stock") > 0 }.map { it.s("name") },
                display = { name -> products.firstOrNull { it.s("name") == name }?.let { "${shortProductName(name)} — موجودی ${it.i("stock")}" } ?: name },
                onSelect = { name -> selected = products.firstOrNull { it.s("name") == name } }
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = qtyText,
                    onValueChange = { qtyText = it.filter(Char::isDigit).take(3) },
                    modifier = Modifier.weight(0.35f),
                    singleLine = true,
                    label = { Text("تعداد") },
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, unfocusedBorderColor = Border)
                )
                Box(Modifier.weight(0.65f)) {
                    DropdownField(
                        title = "نوع قیمت",
                        value = activePriceLabels.firstOrNull { it.first == priceKey }?.second ?: "انتخاب",
                        options = activePriceLabels.map { it.first },
                        display = { k -> activePriceLabels.firstOrNull { it.first == k }?.second ?: k },
                        onSelect = { priceKey = it }
                    )
                }
            }
        }
        item {
            GhadirButton("افزودن به سفارش", secondary = true, onClick = {
                val p = selected ?: return@GhadirButton
                val q = qtyText.toIntOrNull() ?: 0
                if (q < 1 || q > p.i("stock")) { error = "تعداد انتخاب‌شده با موجودی سازگار نیست"; return@GhadirButton }
                if (cart.any { it.product == p.s("name") }) { error = "این مدل قبلاً به سفارش اضافه شده است"; return@GhadirButton }
                val label = activePriceLabels.firstOrNull { it.first == priceKey }?.second ?: priceKey
                val unit = p.obj("prices").optLong(priceKey, 0)
                cart = cart + CartLine(p.s("name"), q, priceKey, label, unit)
            })
        }
        if (cart.isNotEmpty()) {
            item { SectionTitle("اقلام سفارش") }
            items(cart, key = { it.product }) { line ->
                Surface(shape = RoundedCornerShape(18.dp), color = Color.White) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { cart = cart.filterNot { it.product == line.product } }) { Icon(Icons.Default.DeleteOutline, null, tint = Danger) }
                        Text("${formatMoney(line.unit * line.qty)} تومان", color = Orange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Column(horizontalAlignment = Alignment.End) {
                            Text(shortProductName(line.product), color = NavyDeep, fontWeight = FontWeight.Bold)
                            Text("${line.qty} عدد • ${line.priceLabel}", color = Muted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
        item {
            DropdownField("نوع فاکتور", invoiceType, listOf("غیررسمی", "رسمی"), { it }) { invoiceType = it }
        }
        item {
            DropdownField(
                "روش پرداخت",
                when(payment) { "bank_transfer" -> "واریز بانکی / کارت‌به‌کارت"; "credit" -> "خرید اعتباری"; "check" -> "پرداخت با چک"; "installment" -> "پرداخت اقساطی"; else -> "انتخاب" },
                listOf("bank_transfer", "credit", "check", "installment"),
                { k -> when(k) { "bank_transfer" -> "واریز بانکی / کارت‌به‌کارت"; "credit" -> "خرید اعتباری"; "check" -> "پرداخت با چک"; else -> "پرداخت اقساطی" } },
                { payment = it }
            )
        }
        item {
            Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFFF1F3F6)) {
                Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LockClock, null, tint = Muted)
                    Spacer(Modifier.width(8.dp))
                    Text("پرداخت آنلاین فعلاً تا اتصال API درگاه غیرفعال است.", color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                }
            }
        }
        item {
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it.take(500) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                label = { Text("توضیحات سفارش – اختیاری") },
                shape = RoundedCornerShape(18.dp),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, unfocusedBorderColor = Border)
            )
        }
        item {
            val total = cart.sumOf { it.unit * it.qty }
            HeroCard("جمع تقریبی سفارش", "${formatMoney(total)} تومان", "مبلغ نهایی پس از بررسی واحد فروش تأیید می‌شود", Icons.Default.AccountBalanceWallet)
        }
        item {
            GhadirButton(
                if (submitting) "در حال ثبت..." else "ثبت نهایی سفارش",
                enabled = cart.isNotEmpty() && !submitting,
                onClick = {
                    scope.launch {
                        submitting = true; error = ""
                        try {
                            val itemsJson = JSONArray()
                            cart.forEach { line -> itemsJson.put(JSONObject().put("product", line.product).put("qty", line.qty).put("price_key", line.priceKey)) }
                            val body = JSONObject()
                                .put("invoice_type", invoiceType)
                                .put("requested_payment_method", payment)
                                .put("notes", notes)
                                .put("items", itemsJson)
                            api.post("/api/orders/add", body)
                            cart = emptyList()
                            onSuccess()
                        } catch (e: Exception) { error = e.message ?: "ثبت سفارش ناموفق بود" }
                        finally { submitting = false }
                    }
                }
            )
        }
    }
}

@Composable
private fun PortalCatalog(api: ApiClient) {
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var products by remember { mutableStateOf(emptyList<JSONObject>()) }
    LaunchedEffect(Unit) {
        try { products = (api.get("/api/catalog") as JSONArray).objects() }
        catch (e: Exception) { error = e.message ?: "خطا" }
        loading = false
    }
    if (loading) { LoadingPane(); return }
    val filtered = products.filter { query.isBlank() || it.s("name").contains(query, true) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        SearchBox(query, { query = it }, "جستجوی مدل دستگاه")
        Spacer(Modifier.height(10.dp)); ErrorBanner(error) { error = "" }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(filtered, key = { it.s("name") }) { p -> CatalogCard(p) }
        }
    }
}

@Composable
private fun CatalogCard(p: JSONObject) {
    val prices = p.obj("prices")
    val cash = prices.optLong("panel_cash", p.l("price"))
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(15.dp), horizontalAlignment = Alignment.End) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                StatusPill(if (p.b("available") && p.i("stock") > 0) "موجود ${p.i("stock")}" else "ناموجود")
                Spacer(Modifier.weight(1f))
                Text(shortProductName(p.s("name")), color = NavyDeep, fontSize = 16.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.End, modifier = Modifier.weight(2.2f))
            }
            Spacer(Modifier.height(8.dp))
            if (cash > 0) Text("نقد: ${formatMoney(cash)} تومان", color = Orange, fontWeight = FontWeight.ExtraBold)
            Text("آخرین بروزرسانی: ${p.s("price_updated_at").ifBlank { "ثبت نشده" }}", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun PortalProfile(api: ApiClient, me: JSONObject, onLogout: () -> Unit) {
    val c = me.obj("customer")
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            HeroCard("حساب کاربری", c.s("name").ifBlank { me.s("username") }, c.s("company").ifBlank { "مشتری قدیر پارتنر" }, Icons.Default.VerifiedUser, emphasis = true)
        }
        item {
            ProfileRow("موبایل ورود", me.s("username"), Icons.Default.PhoneAndroid)
            ProfileRow("شهر", listOf(c.s("province"), c.s("city")).filter { it.isNotBlank() }.joinToString(" - ").ifBlank { "ثبت نشده" }, Icons.Default.LocationCity)
            ProfileRow("کد مشتری", c.s("code").ifBlank { "-" }, Icons.Default.Badge)
        }
        item { GhadirButton("خروج از حساب", onLogout, secondary = true) }
        item { Text("نسخه Native Beta ${BuildConfig.VERSION_NAME}", color = Muted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
    }
}

@Composable
private fun ProfileRow(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(shape = RoundedCornerShape(18.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Orange)
            Spacer(Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.End) { Text(title, color = Muted, fontSize = 10.sp); Text(value, color = NavyDeep, fontWeight = FontWeight.Bold) }
        }
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun <T> DropdownField(title: String, value: String, options: List<T>, display: (T) -> String, onSelect: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            modifier = Modifier.fillMaxWidth().clickable { open = true },
            readOnly = true,
            singleLine = true,
            label = { Text(title) },
            trailingIcon = { Icon(Icons.Default.KeyboardArrowDown, null) },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, unfocusedBorderColor = Border)
        )
        Box(Modifier.matchParentSize().clickable { open = true })
        DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.fillMaxWidth(0.86f)) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(display(option), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End) },
                    onClick = { onSelect(option); open = false }
                )
            }
        }
    }
}
