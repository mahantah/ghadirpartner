package ir.ghadirpartner.nativeapp

import org.json.JSONArray
import org.json.JSONObject
import java.text.DecimalFormat

fun JSONArray.objects(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }
fun JSONArray.strings(): List<String> = (0 until length()).map { optString(it) }
fun JSONObject.s(key: String): String = optString(key, "")
fun JSONObject.i(key: String): Int = optInt(key, 0)
fun JSONObject.l(key: String): Long = optLong(key, 0L)
fun JSONObject.b(key: String): Boolean = optBoolean(key, false)
fun JSONObject.arr(key: String): JSONArray = optJSONArray(key) ?: JSONArray()
fun JSONObject.obj(key: String): JSONObject = optJSONObject(key) ?: JSONObject()
fun formatMoney(value: Long): String = DecimalFormat("#,###").format(value)
fun shortProductName(raw: String): String {
    return raw
        .replace("دستگاه كارتخوان ", "")
        .replace("دستگاه کارتخوان ", "")
        .replace("دستگاه كش لس ", "")
        .replace("دستگاه کش لس ", "")
        .trim()
}
