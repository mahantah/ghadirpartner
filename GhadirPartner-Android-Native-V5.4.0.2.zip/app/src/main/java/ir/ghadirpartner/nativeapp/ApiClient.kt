package ir.ghadirpartner.nativeapp

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ApiException(val status: Int, override val message: String) : Exception(message)

private class PersistentCookieJar(context: Context) : CookieJar {
    private val prefs = context.getSharedPreferences("ghadir_native_cookies", Context.MODE_PRIVATE)
    private val key = "cookies_${BuildConfig.APP_MODE}"
    private val cache = mutableMapOf<String, Cookie>()

    init {
        val root = HttpUrl.Builder().scheme("https").host("ghadirpartner.ir").build()
        prefs.getStringSet(key, emptySet())?.forEach { raw ->
            Cookie.parse(root, raw)?.let { cache[it.name + "|" + it.path] = it }
        }
        cleanup()
    }

    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        cookies.forEach { cookie -> cache[cookie.name + "|" + cookie.path] = cookie }
        cleanup()
        persist()
    }

    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        cleanup()
        return cache.values.filter { it.matches(url) }
    }

    fun clear() {
        cache.clear()
        prefs.edit().remove(key).apply()
    }

    private fun cleanup() {
        val now = System.currentTimeMillis()
        val expired = cache.filterValues { it.expiresAt < now }.keys
        expired.forEach(cache::remove)
    }

    private fun persist() {
        prefs.edit().putStringSet(key, cache.values.map { it.toString() }.toSet()).apply()
    }
}

class ApiClient(context: Context) {
    private val cookieJar = PersistentCookieJar(context.applicationContext)
    private val client = OkHttpClient.Builder()
        .cookieJar(cookieJar)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    val isPortal: Boolean get() = BuildConfig.APP_MODE == "portal"
    val base: String get() = BuildConfig.API_BASE.trimEnd('/')

    suspend fun get(path: String): Any = request("GET", path, null)
    suspend fun post(path: String, body: JSONObject = JSONObject()): Any = request("POST", path, body)

    suspend fun request(method: String, path: String, body: JSONObject?): Any = withContext(Dispatchers.IO) {
        val url = if (path.startsWith("http")) path else base + if (path.startsWith('/')) path else "/$path"
        val builder = Request.Builder()
            .url(url)
            .header("Accept", "application/json, text/plain;q=0.9")
            .header("User-Agent", "GhadirPartnerNative/${BuildConfig.VERSION_NAME} Android")
        if (method == "POST") {
            val payload = (body ?: JSONObject()).toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            builder.post(payload)
        } else builder.get()

        client.newCall(builder.build()).execute().use { response ->
            val text = response.body?.string().orEmpty().trim()
            if (!response.isSuccessful) {
                throw ApiException(response.code, text.ifBlank { "خطای ارتباط با سرور (${response.code})" })
            }
            if (text.isBlank()) return@use JSONObject()
            when {
                text.startsWith("{") -> JSONObject(text)
                text.startsWith("[") -> JSONArray(text)
                else -> text
            }
        }
    }

    suspend fun login(identity: String, password: String) {
        val body = JSONObject().put("Username", identity.trim()).put("Password", password)
        post("/api/login", body)
    }

    suspend fun logout() {
        try { get("/api/logout") } catch (_: Exception) {}
        cookieJar.clear()
    }

    suspend fun me(): JSONObject = get("/api/me") as JSONObject
}
