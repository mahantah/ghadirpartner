package ir.ghadirpartner.nativeapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GhadirTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    NativeAppRoot()
                }
            }
        }
    }
}

@Composable
private fun NativeAppRoot() {
    val context = LocalContext.current
    val api = remember { ApiClient(context) }
    var checking by remember { mutableStateOf(true) }
    var me by remember { mutableStateOf<JSONObject?>(null) }
    var authNonce by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(authNonce) {
        checking = true
        me = try { api.me() } catch (_: Exception) { null }
        checking = false
    }

    when {
        checking -> SplashScreen()
        me == null -> LoginScreen(
            api = api,
            onLoggedIn = { authNonce++ }
        )
        api.isPortal -> PortalApp(
            api = api,
            me = me!!,
            onLogout = {
                scope.launch {
                    api.logout()
                    me = null
                    authNonce++
                }
            }
        )
        else -> AutomationApp(
            api = api,
            me = me!!,
            onLogout = {
                scope.launch {
                    api.logout()
                    me = null
                    authNonce++
                }
            }
        )
    }
}
