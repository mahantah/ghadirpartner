package ir.ghadirpartner.nativeapp

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0B2347)
val NavyDeep = Color(0xFF071A36)
val NavySoft = Color(0xFF173B68)
val Orange = Color(0xFFFF7A1A)
val OrangeSoft = Color(0xFFFFA15D)
val Canvas = Color(0xFFF5F7FB)
val CardWhite = Color(0xFFFFFFFF)
val Muted = Color(0xFF77869B)
val Border = Color(0xFFDCE5F0)
val Success = Color(0xFF198754)
val Danger = Color(0xFFC43E4D)
val Warning = Color(0xFFB7791F)

private val GhadirLight = lightColorScheme(
    primary = Orange,
    onPrimary = Color.White,
    secondary = Navy,
    onSecondary = Color.White,
    background = Canvas,
    onBackground = NavyDeep,
    surface = CardWhite,
    onSurface = NavyDeep,
    outline = Border,
    error = Danger
)

@Composable
fun GhadirTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = GhadirLight,
        typography = MaterialTheme.typography,
        content = content
    )
}
