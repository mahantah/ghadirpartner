/* GhadirPartner Web V5.3.4.6 — compact unified print center */
(function(){
  'use strict';
  if(window.__GP_TSC_5346__) return;
  window.__GP_TSC_5346__=true;

  const $id=(id)=>document.getElementById(id);
  const num=(id,d)=>{const el=$id(id);const v=el?Number(el.value):NaN;return Number.isFinite(v)?v:d};
  const setv=(id,v)=>{const el=$id(id);if(el)el.value=v??''};

  function ensureCenter(){
    const settings=$id('settings');
    if(!settings || $id('gpPrintCenter')) return;
    const card=document.createElement('div');
    card.id='gpPrintCenter';
    card.className='card';
    card.innerHTML=`
      <div class="gp-print-card">
        <div class="gp-print-top">
          <div>
            <h3 style="margin:0">تنظیمات چاپ</h3>
            <div class="small">یک تنظیم واحد برای PDF و چاپ مستقیم TSC</div>
          </div>
          <span class="gp-print-badge">TSC TTP-244 Pro · 203dpi</span>
        </div>

        <div class="gp-row-title">تنظیم واحد چاپ لیبل</div>
        <div class="gp-grid">
          <label>عرض لیبل (mm)<input id="gp_label_w" type="number" min="25" max="108" step="0.1" value="70"></label>
          <label>ارتفاع لیبل (mm)<input id="gp_label_h" type="number" min="20" max="300" step="0.1" value="50"></label>
          <label>Gap (mm)<input id="gp_label_gap" type="number" min="0" max="15" step="0.1" value="3"></label>
          <label>چیدمان چاپ<select id="gp_layout"><option value="portrait">Portrait</option><option value="landscape">Landscape</option></select></label>
          <label>Offset X (mm)<input id="gp_label_x" type="number" min="-10" max="10" step="0.1" value="0"></label>
          <label>Offset Y (mm)<input id="gp_label_y" type="number" min="-10" max="10" step="0.1" value="0"></label>
          <label>چاپ مخزن گروهی<select id="gp_wh_batch_mode"><option value="continuous">پشت سر هم (Continuous)</option><option value="pdf">PDF گروهی</option></select></label>
          <label>پیش‌فرض چاپ سفارش<select id="gp_order_mode"><option value="pdf">PDF جزئیات سفارش A4</option><option value="label">چاپ مستقیم لیبل TSC</option></select></label>
        </div>

        <div class="gp-actions">
          <button class="btn2" type="button" onclick="gpSaveUnifiedPrintSettings()">ذخیره تنظیمات چاپ</button>
          <button class="btnlight" type="button" onclick="gpPrintTestUnified()">چاپ تست لیبل</button>
          <span id="gpPrintMsg" class="small"></span>
        </div>

        <div class="gp-note">
          <b>راهنما:</b> همه لیبل‌های مخزن انبار با همین تنظیم واحد چاپ می‌شوند. در چاپ گروهی مخزن، لیبل‌ها پشت‌سرهم
          در یک خروجی واحد تولید می‌شوند و نسخه PDF گروهی هم در دسترس است.
          برای TSC: Scale=100% ، Margin=0 ، Paper Size دقیقاً برابر این تنظیم، و بعد از تعویض رول Calibration انجام شود.
        </div>
      </div>
    `;
    const first=settings.querySelector('.card');
    if(first) first.after(card); else settings.appendChild(card);
  }

  window.gpLoadUnifiedPrintSettings = async function(){
    ensureCenter();
    if(typeof req!=='function') return;
    try{
      const x=await req('/api/settings');
      setv('gp_label_w',x.print_label_w??70);
      setv('gp_label_h',x.print_label_h??50);
      setv('gp_label_gap',x.print_label_gap??3);
      setv('gp_label_x',x.print_label_x??0);
      setv('gp_label_y',x.print_label_y??0);
      setv('gp_layout',x.print_label_layout??'portrait');
      setv('gp_wh_batch_mode',x.print_warehouse_batch_mode??'continuous');
      setv('gp_order_mode',x.print_order_mode??'pdf');
    }catch(e){
      const m=$id('gpPrintMsg'); if(m)m.textContent=e.message||String(e);
    }
  };

  window.gpSaveUnifiedPrintSettings = async function(){
    if(typeof req!=='function') return;
    const body = {
      print_printer:'TSC TTP-244 Pro',
      print_dpi:203,
      print_label_w:num('gp_label_w',70),
      print_label_h:num('gp_label_h',50),
      print_label_gap:num('gp_label_gap',3),
      print_label_x:num('gp_label_x',0),
      print_label_y:num('gp_label_y',0),
      print_label_layout:($id('gp_layout')||{}).value||'portrait',
      print_warehouse_batch_mode:($id('gp_wh_batch_mode')||{}).value||'continuous',
      print_order_mode:($id('gp_order_mode')||{}).value||'pdf'
    };
    const m=$id('gpPrintMsg');
    try{
      await req('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
      if(m){m.className='ok';m.textContent='تنظیمات چاپ ذخیره شد.'}
    }catch(e){
      if(m){m.className='msg';m.textContent=e.message||String(e)}
    }
  };

  window.gpPrintTestUnified = function(){
    window.open('/print/tsc-test?profile=label','_blank');
  };

  function bindSettingsOpen(){
    document.addEventListener('click',(ev)=>{
      const t=ev.target.closest&&ev.target.closest('[data-tab="settings"]');
      if(t)setTimeout(()=>window.gpLoadUnifiedPrintSettings(),80);
    },true);
  }

  bindSettingsOpen();
  ensureCenter();
})();
