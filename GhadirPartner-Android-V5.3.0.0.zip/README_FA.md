# اپلیکیشن Android قدیر پارتنر — V5.3.0.0

این پروژه دو APK از یک کد تولید می‌کند:
- `portalDebug`: اپ مشتریان، شروع از `https://ghadirpartner.ir/partners/`
- `automationDebug`: اپ داخلی اتوماسیون، شروع از `https://ghadirpartner.ir/`

ویژگی‌های امنیتی:
- فقط HTTPS و بدون Cleartext
- Mixed Content مسدود
- لینک‌های خارج از ghadirpartner.ir در مرورگر سیستم باز می‌شوند
- File/Content access در WebView خاموش
- Third-party cookie خاموش
- Safe Browsing روشن
- دانلود PDF/Excel با Session/Cookie کاربر
- File chooser برای رسید و فایل‌ها
- دسترسی دوربین فقط برای دامنه قدیر پارتنر

برای تست، GitHub Actions فایل‌های APK Debug را می‌سازد. برای انتشار عمومی/Play Store باید Signing Key اختصاصی شرکت ساخته و در Secrets نگهداری شود.
