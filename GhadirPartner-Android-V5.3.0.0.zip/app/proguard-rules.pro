# Ghadir Partner Android wrapper - no custom keep rules required yet.
