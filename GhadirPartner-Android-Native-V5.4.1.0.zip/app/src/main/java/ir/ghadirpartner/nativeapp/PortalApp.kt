package ir.ghadirpartner.nativeapp

import android.widget.Toast
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val portalNav = listOf(
    NavItem("home", "پیشخوان", Icons.Default.Home),
    NavItem("orders", "سفارش‌ها", Icons.Default.ReceiptLong),
    NavItem("new", "سفارش جدید", Icons.Default.AddCircle),
    NavItem("catalog", "لیست قیمت", Icons.Default.LocalOffer),
    NavItem("profile", "پروفایل", Icons.Default.AccountCircle)
)

@Composable
fun PortalApp(api: ApiClient, me: JSONObject, onLogout: () -> Unit) {
    var screen by remember { mutableStateOf("home") }
    var selectedOrder by remember { mutableStateOf<JSONObject?>(null) }
    var currentMe by remember { mutableStateOf(JSONObject(me.toString())) }
    val customerName = currentMe.obj("customer").s("name").ifBlank { currentMe.s("username") }

    Scaffold(
        containerColor = Canvas,
        topBar = { BrandHeader("قدیر پارتنر", customerName) },
        bottomBar = {
            if (screen != "order-detail") {
                BottomBar(portalNav, screen) {
                    selectedOrder = null
                    screen = it
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            Crossfade(targetState = screen, label = "portal-nav") { target ->
                when (target) {
                    "home" -> PortalHome(
                        api,
                        navigate = { screen = it },
                        openOrder = { selectedOrder = it; screen = "order-detail" }
                    )
                    "orders" -> PortalOrders(api) { selectedOrder = it; screen = "order-detail" }
                    "new" -> PortalNewOrder(api) { screen = "orders" }
                    "catalog" -> PortalCatalog(api)
                    "order-detail" -> selectedOrder?.let { order ->
                        PortalOrderDetails(api, order, onBack = { screen = "orders" })
                    } ?: PortalOrders(api) { selectedOrder = it; screen = "order-detail" }
                    else -> PortalProfile(
                        api = api,
                        me = currentMe,
                        onUpdated = { result ->
                            val next = JSONObject(currentMe.toString())
                            next.put("customer", result.obj("customer"))
                            next.put("alternate_mobile", result.s("alternate_mobile"))
                            currentMe = next
                        },
                        onLogout = onLogout
                    )
                }
            }
        }
    }
}

@Composable
private fun PortalHome(api: ApiClient, navigate: (String) -> Unit, openOrder: (JSONObject) -> Unit) {
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var orders by remember { mutableStateOf(emptyList<JSONObject>()) }
    var stats by remember { mutableStateOf(JSONObject()) }

    fun refresh() {
        scope.launch {
            loading = true; error = ""
            try {
                orders = (api.get("/api/orders") as JSONArray).objects().sortedByDescending { it.i("id") }
                stats = api.get("/api/reports/customer-summary") as JSONObject
            } catch (e: Exception) { error = e.message ?: "خطا در دریافت اطلاعات" }
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }
    if (loading) { LoadingPane(); return }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 15.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 26.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        item { ErrorBanner(error) { error = "" } }
        item {
            PortalSummaryHero(
                amount = stats.obj("month").l("amount"),
                orders = stats.obj("month").i("orders"),
                qty = stats.obj("month").i("qty")
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                MiniAction("سفارش جدید", Icons.Default.AddShoppingCart, Modifier.weight(1f)) { navigate("new") }
                MiniAction("لیست قیمت", Icons.Default.LocalOffer, Modifier.weight(1f)) { navigate("catalog") }
                MiniAction("سفارش‌ها", Icons.Default.ReceiptLong, Modifier.weight(1f)) { navigate("orders") }
            }
        }
        item { SectionTitle("آخرین سفارش‌ها", "مشاهده همه") { navigate("orders") } }
        if (orders.isEmpty()) item { EmptyState("هنوز سفارشی ندارید", "از بخش سفارش جدید، اولین سفارش را ثبت کنید.") }
        items(orders.take(4), key = { it.i("id") }) { o ->
            OrderCard(
                number = o.s("number"), customer = "", status = o.s("status"), payment = o.s("payment_status"),
                amount = if (o.l("approved_total") > 0) o.l("approved_total") else o.l("estimated_total"),
                date = o.s("created_at")
            ) { openOrder(o) }
        }
        item { SectionTitle("گزارش خرید") }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                StatTile("۷ روز", faNumber(stats.obj("week").i("orders")), "سفارش", Modifier.weight(1f))
                StatTile("۳۰ روز", faNumber(stats.obj("month").i("orders")), "سفارش", Modifier.weight(1f))
                StatTile("۹۰ روز", faNumber(stats.obj("three_months").i("orders")), "سفارش", Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun PortalSummaryHero(amount: Long, orders: Int, qty: Int) {
    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent), modifier = Modifier.fillMaxWidth()) {
        Box(
            Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(NavyDeep, Navy, Color(0xFF173F70)))).padding(20.dp)
        ) {
            Box(
                Modifier.size(120.dp).align(Alignment.BottomStart).offset(x = (-28).dp, y = 46.dp)
                    .clip(CircleShape).background(Color(0x33FF7A1A))
            )
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0x33FF7A1A)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.TrendingUp, null, tint = Orange)
                    }
                    Spacer(Modifier.weight(1f))
                    Column(horizontalAlignment = Alignment.End) {
                        Text("خرید ۳۰ روز اخیر", color = Color(0xFFC7D7EA), fontSize = 12.sp)
                        Text("${formatMoney(amount)} تومان", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    StatusPill("${faNumber(qty)} قلم")
                    Spacer(Modifier.width(8.dp))
                    StatusPill("${faNumber(orders)} سفارش")
                }
            }
        }
    }
}

@Composable
private fun MiniAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier = modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 15.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFFFE7D5)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Orange, modifier = Modifier.size(23.dp))
            }
            Spacer(Modifier.height(7.dp))
            Text(title, color = NavyDeep, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        }
    }
}

@Composable
private fun StatTile(title: String, value: String, caption: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Muted, fontSize = 10.sp)
            Text(value, color = NavyDeep, fontSize = 21.sp, fontWeight = FontWeight.Black)
            Text(caption, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun PortalOrders(api: ApiClient, onOpen: (JSONObject) -> Unit) {
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var orders by remember { mutableStateOf(emptyList<JSONObject>()) }

    fun refresh() {
        scope.launch {
            loading = true; error = ""
            try { orders = (api.get("/api/orders") as JSONArray).objects().sortedByDescending { it.i("id") } }
            catch (e: Exception) { error = e.message ?: "خطا" }
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }
    if (loading) { LoadingPane(); return }

    val filtered = orders.filter {
        query.isBlank() || listOf(it.s("number"), it.s("status"), it.s("payment_status")).any { v -> v.contains(query, true) }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        SearchBox(query, { query = it }, "جستجو در شماره یا وضعیت سفارش")
        Spacer(Modifier.height(9.dp)); ErrorBanner(error) { error = "" }
        Text("${faNumber(filtered.size)} سفارش", color = Muted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
        Spacer(Modifier.height(5.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (filtered.isEmpty()) item { EmptyState("سفارشی پیدا نشد", "فیلتر یا عبارت جستجو را تغییر دهید.") }
            items(filtered, key = { it.i("id") }) { o ->
                OrderCard(
                    o.s("number"), "", o.s("status"), o.s("payment_status"),
                    if (o.l("approved_total") > 0) o.l("approved_total") else o.l("estimated_total"), o.s("created_at")
                ) { onOpen(o) }
            }
        }
    }
}

@Composable
private fun PortalOrderDetails(api: ApiClient, order: JSONObject, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var downloading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val total = if (order.l("approved_total") > 0) order.l("approved_total") else order.l("estimated_total")

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowForward, "بازگشت", tint = NavyDeep) }
                Spacer(Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End) {
                    Text("جزئیات سفارش", color = NavyDeep, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Text(faDigits(order.s("number")), color = Muted, fontSize = 12.sp)
                }
            }
        }
        item { ErrorBanner(error) { error = "" } }
        item {
            Surface(shape = RoundedCornerShape(22.dp), color = Color.White) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    DetailLine("وضعیت سفارش", order.s("status").ifBlank { "-" })
                    DetailLine("وضعیت تسویه", order.s("payment_status").ifBlank { "-" })
                    DetailLine("روش پرداخت درخواستی", order.s("requested_payment_method_label").ifBlank { "-" })
                    DetailLine("نوع فاکتور", order.s("invoice_type").ifBlank { "-" })
                    DetailLine("تاریخ ثبت", formatDateFa(order.s("created_at")))
                    if (order.s("updated_at").isNotBlank()) DetailLine("آخرین تغییر", formatDateFa(order.s("updated_at")))
                    if (total > 0) DetailLine("مبلغ سفارش", "${formatMoney(total)} تومان", highlight = true)
                }
            }
        }
        if (order.s("shipping_type").isNotBlank() || order.s("tracking_code").isNotBlank()) item {
            Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFEAF2FF)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.End) {
                    Text("اطلاعات ارسال", color = NavyDeep, fontWeight = FontWeight.Black)
                    if (order.s("shipping_type").isNotBlank()) Text("روش ارسال: ${order.s("shipping_type")}", color = NavySoft, fontSize = 12.sp)
                    if (order.s("tracking_code").isNotBlank()) Text("کد مرسوله: ${order.s("tracking_code")}", color = Color(0xFF2457A6), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item { SectionTitle("اقلام سفارش") }
        items(order.arr("items").objects(), key = { it.s("product") }) { item ->
            Surface(shape = RoundedCornerShape(19.dp), color = Color.White) {
                Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.End) {
                    Text(shortProductName(item.s("product")), color = NavyDeep, fontWeight = FontWeight.Black, fontSize = 15.sp)
                    Spacer(Modifier.height(5.dp))
                    Text("تعداد: ${faNumber(item.i("qty"))} • ${item.s("price_label").ifBlank { "قیمت ثبت نشده" }}", color = Muted, fontSize = 11.sp)
                    if (item.l("unit_price") > 0) Text("قیمت واحد: ${formatMoney(item.l("unit_price"))} تومان", color = NavySoft, fontSize = 11.sp)
                    if (item.l("line_total") > 0) Text("جمع: ${formatMoney(item.l("line_total"))} تومان", color = Orange, fontWeight = FontWeight.ExtraBold)
                    if (order.s("status") == "تحویل شد") {
                        Text("سریال ثبت‌شده: ${faNumber(item.arr("serials").length())}", color = Success, fontSize = 11.sp)
                    }
                }
            }
        }
        if (order.s("notes").isNotBlank()) item {
            Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFFFFF6EE)) {
                Column(Modifier.fillMaxWidth().padding(13.dp), horizontalAlignment = Alignment.End) {
                    Text("توضیحات", color = NavyDeep, fontWeight = FontWeight.Bold)
                    Text(order.s("notes"), color = NavySoft, fontSize = 12.sp, textAlign = TextAlign.End)
                }
            }
        }
        if (order.s("status") == "تحویل شد") item {
            GhadirButton(
                text = if (downloading) "در حال دانلود..." else "دانلود لیست سریال‌ها",
                enabled = !downloading,
                onClick = {
                    scope.launch {
                        downloading = true; error = ""
                        try {
                            val name = "serials-${order.s("number")}.xlsx"
                            val where = api.downloadFile(
                                "/export/order-serials.xlsx?id=${order.i("id")}",
                                name,
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            )
                            Toast.makeText(context, "فایل سریال ذخیره شد: $where", Toast.LENGTH_LONG).show()
                        } catch (e: Exception) { error = e.message ?: "دانلود سریال ناموفق بود" }
                        finally { downloading = false }
                    }
                }
            )
        }
        if (order.arr("history").length() > 0) {
            item { SectionTitle("آخرین تغییرات سفارش") }
            items(order.arr("history").objects().takeLast(8).reversed()) { h ->
                Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.End) {
                        Text(h.s("action"), color = NavyDeep, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
                        Text("${formatDateFa(h.s("at"))} • ${h.s("by")}", color = Muted, fontSize = 9.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailLine(title: String, value: String, highlight: Boolean = false) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(value, color = if (highlight) Orange else NavyDeep, fontWeight = if (highlight) FontWeight.Black else FontWeight.Bold, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        Text(title, color = Muted, fontSize = 11.sp)
    }
}

private data class CartLine(val product: String, val qty: Int, val priceKey: String, val priceLabel: String, val unit: Long)

@Composable
private fun PortalNewOrder(api: ApiClient, onSuccess: () -> Unit) {
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(true) }
    var submitting by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var products by remember { mutableStateOf(emptyList<JSONObject>()) }
    var selected by remember { mutableStateOf<JSONObject?>(null) }
    var qtyText by remember { mutableStateOf("1") }
    var priceKey by remember { mutableStateOf("panel_cash") }
    var invoiceType by remember { mutableStateOf("غیررسمی") }
    var payment by remember { mutableStateOf("bank_transfer") }
    var notes by remember { mutableStateOf("") }
    var cart by remember { mutableStateOf(emptyList<CartLine>()) }

    LaunchedEffect(Unit) {
        try {
            products = (api.get("/api/catalog") as JSONArray).objects().filter { it.b("available") }
            selected = products.firstOrNull { it.i("stock") > 0 }
        } catch (e: Exception) { error = e.message ?: "خطا در لیست کالا" }
        loading = false
    }
    if (loading) { LoadingPane(); return }

    val priceLabels = listOf(
        "panel_cash" to "نقد", "panel_7d" to "هفت‌روزه", "panel_1m" to "یک‌ماهه",
        "serial_1_50" to "سریال آزاد ۱ تا ۵۰", "serial_51_200" to "سریال آزاد ۵۱ تا ۲۰۰", "sales_agent" to "عامل فروش"
    )
    val selectedPrices = selected?.obj("prices") ?: JSONObject()
    val activePriceLabels = priceLabels.filter { selectedPrices.optLong(it.first, 0) > 0 }
    if (activePriceLabels.none { it.first == priceKey }) priceKey = activePriceLabels.firstOrNull()?.first ?: "panel_cash"

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("ثبت سفارش جدید", color = NavyDeep, fontSize = 22.sp, fontWeight = FontWeight.Black, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
            Text("کالاها را اضافه کنید و روش پرداخت را همان ابتدا مشخص کنید.", color = Muted, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
        }
        item { ErrorBanner(error) { error = "" } }
        item {
            DropdownField(
                title = "انتخاب محصول",
                value = selected?.let { "${shortProductName(it.s("name"))} — موجودی ${faNumber(it.i("stock"))}" } ?: "انتخاب کنید",
                options = products.filter { it.i("stock") > 0 }.map { it.s("name") },
                display = { name -> products.firstOrNull { it.s("name") == name }?.let { "${shortProductName(name)} — موجودی ${faNumber(it.i("stock"))}" } ?: name },
                onSelect = { name -> selected = products.firstOrNull { it.s("name") == name } }
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = qtyText, onValueChange = { qtyText = it.filter(Char::isDigit).take(3) }, modifier = Modifier.weight(0.35f), singleLine = true,
                    label = { Text("تعداد") }, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, unfocusedBorderColor = Border)
                )
                Box(Modifier.weight(0.65f)) {
                    DropdownField("نوع قیمت", activePriceLabels.firstOrNull { it.first == priceKey }?.second ?: "انتخاب", activePriceLabels.map { it.first }, { k -> activePriceLabels.firstOrNull { it.first == k }?.second ?: k }) { priceKey = it }
                }
            }
        }
        item {
            GhadirButton("افزودن به سفارش", secondary = true, onClick = {
                val p = selected ?: return@GhadirButton
                val q = qtyText.toIntOrNull() ?: 0
                if (q < 1 || q > p.i("stock")) { error = "تعداد انتخاب‌شده با موجودی سازگار نیست"; return@GhadirButton }
                if (cart.any { it.product == p.s("name") }) { error = "این مدل قبلاً به سفارش اضافه شده است"; return@GhadirButton }
                val label = activePriceLabels.firstOrNull { it.first == priceKey }?.second ?: priceKey
                val unit = p.obj("prices").optLong(priceKey, 0)
                cart = cart + CartLine(p.s("name"), q, priceKey, label, unit)
            })
        }
        if (cart.isNotEmpty()) {
            item { SectionTitle("اقلام سفارش") }
            items(cart, key = { it.product }) { line ->
                Surface(shape = RoundedCornerShape(18.dp), color = Color.White) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { cart = cart.filterNot { it.product == line.product } }) { Icon(Icons.Default.DeleteOutline, null, tint = Danger) }
                        Text("${formatMoney(line.unit * line.qty)} تومان", color = Orange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Column(horizontalAlignment = Alignment.End) {
                            Text(shortProductName(line.product), color = NavyDeep, fontWeight = FontWeight.Bold)
                            Text("${faNumber(line.qty)} عدد • ${line.priceLabel}", color = Muted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
        item { DropdownField("نوع فاکتور", invoiceType, listOf("غیررسمی", "رسمی"), { it }) { invoiceType = it } }
        item {
            DropdownField(
                "روش پرداخت",
                when(payment) { "bank_transfer" -> "واریز بانکی / کارت‌به‌کارت"; "credit" -> "خرید اعتباری"; "check" -> "پرداخت با چک"; "installment" -> "پرداخت اقساطی"; else -> "انتخاب" },
                listOf("bank_transfer", "credit", "check", "installment"),
                { k -> when(k) { "bank_transfer" -> "واریز بانکی / کارت‌به‌کارت"; "credit" -> "خرید اعتباری"; "check" -> "پرداخت با چک"; else -> "پرداخت اقساطی" } },
                { payment = it }
            )
        }
        item {
            Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFFF1F3F6)) {
                Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LockClock, null, tint = Muted); Spacer(Modifier.width(8.dp))
                    Text("پرداخت آنلاین فعلاً تا اتصال API درگاه غیرفعال است.", color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                }
            }
        }
        item {
            OutlinedTextField(
                value = notes, onValueChange = { notes = it.take(500) }, modifier = Modifier.fillMaxWidth(), minLines = 3,
                label = { Text("توضیحات سفارش – اختیاری") }, shape = RoundedCornerShape(18.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, unfocusedBorderColor = Border)
            )
        }
        item {
            val total = cart.sumOf { it.unit * it.qty }
            HeroCard("جمع تقریبی سفارش", "${formatMoney(total)} تومان", "مبلغ نهایی پس از بررسی واحد فروش تأیید می‌شود", Icons.Default.AccountBalanceWallet)
        }
        item {
            GhadirButton(
                if (submitting) "در حال ثبت..." else "ثبت نهایی سفارش", enabled = cart.isNotEmpty() && !submitting,
                onClick = {
                    scope.launch {
                        submitting = true; error = ""
                        try {
                            val itemsJson = JSONArray()
                            cart.forEach { line -> itemsJson.put(JSONObject().put("product", line.product).put("qty", line.qty).put("price_key", line.priceKey)) }
                            val body = JSONObject().put("invoice_type", invoiceType).put("requested_payment_method", payment).put("notes", notes).put("items", itemsJson)
                            api.post("/api/orders/add", body); cart = emptyList(); onSuccess()
                        } catch (e: Exception) { error = e.message ?: "ثبت سفارش ناموفق بود" }
                        finally { submitting = false }
                    }
                }
            )
        }
    }
}

@Composable
private fun PortalCatalog(api: ApiClient) {
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var products by remember { mutableStateOf(emptyList<JSONObject>()) }
    var expanded by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        try { products = (api.get("/api/catalog") as JSONArray).objects() }
        catch (e: Exception) { error = e.message ?: "خطا" }
        loading = false
    }
    if (loading) { LoadingPane(); return }
    val filtered = products.filter { query.isBlank() || it.s("name").contains(query, true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 12.dp)) {
        SearchBox(query, { query = it }, "جستجوی مدل دستگاه")
        Spacer(Modifier.height(8.dp)); ErrorBanner(error) { error = "" }
        Surface(shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp), color = Color(0xFFE4E9F0)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("نام کالا", color = NavyDeep, fontWeight = FontWeight.Black, fontSize = 11.sp, modifier = Modifier.weight(1.8f), textAlign = TextAlign.End)
                Text("موجودی", color = NavyDeep, fontWeight = FontWeight.Black, fontSize = 11.sp, modifier = Modifier.weight(0.7f), textAlign = TextAlign.Center)
                Text("قیمت نقد", color = NavyDeep, fontWeight = FontWeight.Black, fontSize = 11.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
            }
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            items(filtered, key = { it.s("name") }) { p ->
                CatalogListRow(p, expanded == p.s("name")) { expanded = if (expanded == p.s("name")) "" else p.s("name") }
                HorizontalDivider(color = Border, thickness = 0.7.dp)
            }
        }
    }
}

@Composable
private fun CatalogListRow(p: JSONObject, expanded: Boolean, onToggle: () -> Unit) {
    val prices = p.obj("prices")
    val cash = prices.optLong("panel_cash", p.l("price"))
    val available = p.b("available") && p.i("stock") > 0
    Column(Modifier.fillMaxWidth().background(Color.White).clickable(onClick = onToggle).animateContentSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(modifier = Modifier.weight(1.8f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                Text(shortProductName(p.s("name")), color = NavyDeep, fontSize = 12.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.End, modifier = Modifier.weight(1f, fill = false))
                Spacer(Modifier.width(4.dp))
                Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = Muted, modifier = Modifier.size(18.dp))
            }
            Text(if (available) faNumber(p.i("stock")) else "ناموجود", color = if (available) Success else Danger, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.weight(0.7f), textAlign = TextAlign.Center)
            Text(if (cash > 0) formatMoney(cash) else "-", color = if (cash > 0) Orange else Muted, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
        }
        if (expanded) {
            val labels = listOf(
                "panel_cash" to "نقد", "panel_7d" to "هفت‌روزه", "panel_1m" to "یک‌ماهه",
                "serial_1_50" to "سریال آزاد ۱ تا ۵۰", "serial_51_200" to "سریال آزاد ۵۱ تا ۲۰۰", "sales_agent" to "عامل فروش"
            )
            Column(Modifier.fillMaxWidth().background(Color(0xFFF8FAFD)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                labels.filter { prices.optLong(it.first, 0) > 0 }.forEach { (key, label) ->
                    DetailLine(label, "${formatMoney(prices.optLong(key, 0))} تومان")
                }
                Text("آخرین بروزرسانی: ${formatDateFa(p.s("price_updated_at"))}", color = Muted, fontSize = 9.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
            }
        }
    }
}

@Composable
private fun PortalProfile(api: ApiClient, me: JSONObject, onUpdated: (JSONObject) -> Unit, onLogout: () -> Unit) {
    val initial = me.obj("customer")
    val scope = rememberCoroutineScope()
    var name by remember(me.toString()) { mutableStateOf(initial.s("name")) }
    var company by remember(me.toString()) { mutableStateOf(initial.s("company")) }
    var province by remember(me.toString()) { mutableStateOf(initial.s("province")) }
    var city by remember(me.toString()) { mutableStateOf(initial.s("city")) }
    var address by remember(me.toString()) { mutableStateOf(initial.s("address")) }
    var alternate by remember(me.toString()) { mutableStateOf(me.s("alternate_mobile")) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf("") }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        item { HeroCard("حساب کاربری", name.ifBlank { me.s("username") }, company.ifBlank { "مشتری قدیر پارتنر" }, Icons.Default.VerifiedUser, emphasis = true) }
        item { ErrorBanner(error) { error = "" } }
        if (saved.isNotBlank()) item { Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFFE6F7EE)) { Text(saved, color = Success, modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.End, fontWeight = FontWeight.Bold) } }
        item { ProfileEditField("نام و نام خانوادگی", name) { name = it } }
        item { ProfileEditField("شرکت / فروشگاه", company) { company = it } }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Box(Modifier.weight(1f)) { ProfileEditField("استان", province) { province = it } }
                Box(Modifier.weight(1f)) { ProfileEditField("شهر", city) { city = it } }
            }
        }
        item {
            OutlinedTextField(
                value = address, onValueChange = { address = it; saved = "" }, modifier = Modifier.fillMaxWidth(), minLines = 2,
                label = { Text("آدرس") }, shape = RoundedCornerShape(17.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, unfocusedBorderColor = Border, focusedContainerColor = Color.White, unfocusedContainerColor = Color.White)
            )
        }
        item {
            OutlinedTextField(
                value = me.s("username"), onValueChange = {}, modifier = Modifier.fillMaxWidth(), readOnly = true, singleLine = true,
                label = { Text("شماره ورود") }, shape = RoundedCornerShape(17.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Border, disabledBorderColor = Border)
            )
        }
        item { ProfileEditField("شماره جایگزین – اختیاری", alternate) { alternate = it.filter(Char::isDigit).take(11) } }
        item {
            GhadirButton(if (saving) "در حال ذخیره..." else "ذخیره تغییرات پروفایل", enabled = !saving && name.trim().length >= 3, onClick = {
                scope.launch {
                    saving = true; error = ""; saved = ""
                    try {
                        val body = JSONObject().put("name", name).put("company", company).put("province", province).put("city", city).put("address", address).put("alternate_mobile", alternate)
                        val result = api.post("/api/profile/update", body) as JSONObject
                        onUpdated(result); saved = "اطلاعات پروفایل با موفقیت بروزرسانی شد."
                    } catch (e: Exception) { error = e.message ?: "ذخیره پروفایل ناموفق بود" }
                    finally { saving = false }
                }
            })
        }
        item { GhadirButton("خروج از حساب", onLogout, secondary = true) }
        item { Text("نسخه Native ${BuildConfig.VERSION_NAME}", color = Muted, fontSize = 9.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
    }
}

@Composable
private fun ProfileEditField(title: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onValueChange, modifier = Modifier.fillMaxWidth(), singleLine = true,
        label = { Text(title) }, shape = RoundedCornerShape(17.dp),
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, unfocusedBorderColor = Border, focusedContainerColor = Color.White, unfocusedContainerColor = Color.White)
    )
}

@Composable
private fun <T> DropdownField(title: String, value: String, options: List<T>, display: (T) -> String, onSelect: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = value, onValueChange = {}, modifier = Modifier.fillMaxWidth().clickable { open = true }, readOnly = true, singleLine = true,
            label = { Text(title) }, trailingIcon = { Icon(Icons.Default.KeyboardArrowDown, null) }, shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, unfocusedBorderColor = Border, focusedContainerColor = Color.White, unfocusedContainerColor = Color.White)
        )
        Box(Modifier.matchParentSize().clickable { open = true })
        DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.fillMaxWidth(0.86f)) {
            options.forEach { option ->
                DropdownMenuItem(text = { Text(display(option), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End) }, onClick = { onSelect(option); open = false })
            }
        }
    }
}
