/* Ghadir Partner Web V5.3.4.4 — non-destructive UI adapter */
(()=>{
 'use strict';
 const TITLES={dashboard:'پیشخوان',orders:'سفارشات',neworder:'ثبت سفارش',customers:'کاربران قدیرپارتنر',inventory:'سریال‌های مشتریان',reports:'گزارش خروج',warehouse:'مخزن',products:'محصولات',portalAdmin:'طرح‌ها و آفرها',users:'کاربران قدیرپارتنر',settings:'تنظیمات',checks:'بررسی تسویه'};
 const CLEAN={dashboard:'پیشخوان',orders:'سفارشات',neworder:'ثبت سفارش',customers:'مشتریان',warehouse:'مخزن',inventory:'سریال‌های مشتریان',reports:'گزارش خروج',products:'محصولات',portalAdmin:'طرح‌ها و آفرها',users:'کاربران قدیرپارتنر',settings:'تنظیمات',checks:'بررسی تسویه'};
 const faDigits=s=>String(s).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[+d]);
 function faDate(){try{return new Intl.DateTimeFormat('fa-IR-u-ca-persian',{weekday:'long',year:'numeric',month:'long',day:'numeric'}).format(new Date())}catch(_){return faDigits(new Date().toLocaleDateString('fa-IR'))}}
 function activeTab(){return [...document.querySelectorAll('.tab')].find(x=>!x.classList.contains('hidden'))?.id||'dashboard'}
 function ensureBrand(){const nav=document.querySelector('.topnav');if(!nav)return;if(!nav.querySelector('.gp-sidebar-brand')){const d=document.createElement('div');d.className='gp-sidebar-brand';d.innerHTML='<strong>قدیر پارتنر</strong><span>فروش و مدیریت عملیات</span>';nav.prepend(d)}
  const brand=document.querySelector('header .brand b');if(brand)brand.textContent='اتوماسیون قدیر پارتنر';
  document.querySelectorAll('.topnav [data-tab]').forEach(b=>{const id=b.dataset.tab;if(CLEAN[id])b.textContent=CLEAN[id]});
 }
 function ensureHead(section){if(!section)return;let h=section.querySelector(':scope > .gp-page-head');if(!h){h=document.createElement('div');h.className='gp-page-head';h.innerHTML='<h1></h1><div class="gp-date"></div>';section.prepend(h)}h.querySelector('h1').textContent=TITLES[section.id]||'قدیر پارتنر';h.querySelector('.gp-date').textContent=faDate()}
 function sync(){const id=activeTab();document.querySelectorAll('.topnav [data-tab]').forEach(b=>b.classList.toggle('gp-active',b.dataset.tab===id));ensureHead(document.getElementById(id));}
 function init(){document.body.classList.add('gp-web-redesign');document.documentElement.setAttribute('dir','rtl');ensureBrand();sync();
  const wrap=document.querySelector('.wrap');if(wrap){new MutationObserver(sync).observe(wrap,{subtree:true,attributes:true,attributeFilter:['class']})}
  document.addEventListener('click',e=>{if(e.target.closest('[data-tab]'))requestAnimationFrame(()=>setTimeout(sync,0))},true);
  window.GhadirPartnerRedesign={version:'5.3.4.4',sync};
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
