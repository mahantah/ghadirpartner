# Web V5.3.4.4 — Redesign Candidate

این بسته یک لایه بازطراحی **غیرمخرب** برای Web V5.3.4.3 است و منطق فعلی API/سفارش/انبار/سریال/گزارش/نقش‌ها را تغییر نمی‌دهد.

## نصب روی یک کپی آزمایشی
1. از Web V5.3.4.3 یک کپی بگیرید.
2. این پوشه را کنار آن قرار دهید.
3. اجرا کنید: `python install_patch.py /path/to/copied-web-root`
4. فایل‌های `storage/` و `config.php` دست‌نخورده می‌مانند.

منبع طراحی: `07 — CURRENT / Web • Based on 06 Android`.
این Candidate برای تست است و نباید قبل از تأیید نهایی روی Production منتشر شود.
