#!/usr/bin/env python3
"""Install the V5.3.4.4 redesign adapter into a copy of Web V5.3.4.3.
Usage: python install_patch.py /path/to/web-root
The script never touches storage/ or config.php.
"""
from pathlib import Path
import shutil,sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
here=Path(__file__).resolve().parent
app=root/'app.html'
if not app.exists(): raise SystemExit(f'app.html not found under {root}')
text=app.read_text(encoding='utf-8')
css_tag='<link rel="stylesheet" href="/redesign.css?v=5.3.4.4">'
js_tag='<script defer src="/redesign.js?v=5.3.4.4"></script>'
if css_tag not in text:
    text=text.replace('</head>',css_tag+'\n</head>',1)
if js_tag not in text:
    text=text.replace('</body>',js_tag+'\n</body>',1)
app.write_text(text,encoding='utf-8')
shutil.copy2(here/'redesign.css',root/'redesign.css')
shutil.copy2(here/'redesign.js',root/'redesign.js')
(root/'VERSION.txt').write_text('V5.3.4.4-REDESIGN-CANDIDATE\n',encoding='utf-8')
print('Installed Web V5.3.4.4 redesign candidate into',root)
