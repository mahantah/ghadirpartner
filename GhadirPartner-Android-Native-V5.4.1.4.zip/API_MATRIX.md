# API Matrix V5.4.1.0

Portal:
- POST /api/login
- GET /api/me
- POST /api/password-reset/request
- POST /api/password-reset/confirm
- GET /api/orders
- POST /api/orders/add
- GET /api/catalog
- GET /api/reports/customer-summary
- POST /api/profile/update
- GET /export/order-serials.xlsx?id={orderId}

Automation:
- POST /api/login
- GET /api/me
- GET /api/orders
- GET /api/customers
- GET /api/inventory
- GET /api/reports/sales
- POST /api/payment
- POST /api/status
- POST /api/staff-password-reset/request
- POST /api/staff-password-reset/confirm
