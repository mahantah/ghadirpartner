package ir.ghadirpartner.nativeapp

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

class ApiException(val status: Int, override val message: String) : Exception(message)

private class PersistentCookieJar(context: Context) : CookieJar {
    private val prefs = context.getSharedPreferences("ghadir_native_cookies", Context.MODE_PRIVATE)
    private val key = "cookies_${BuildConfig.APP_MODE}"
    private val cache = mutableMapOf<String, Cookie>()

    init {
        val root = HttpUrl.Builder().scheme("https").host("ghadirpartner.ir").build()
        prefs.getStringSet(key, emptySet())?.forEach { raw ->
            Cookie.parse(root, raw)?.let { cache[it.name + "|" + it.path] = it }
        }
        cleanup()
    }

    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        cookies.forEach { cookie -> cache[cookie.name + "|" + cookie.path] = cookie }
        cleanup()
        persist()
    }

    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        cleanup()
        return cache.values.filter { it.matches(url) }
    }

    fun clear() {
        cache.clear()
        prefs.edit().remove(key).apply()
    }

    private fun cleanup() {
        val now = System.currentTimeMillis()
        val expired = cache.filterValues { it.expiresAt < now }.keys
        expired.forEach(cache::remove)
    }

    private fun persist() {
        prefs.edit().putStringSet(key, cache.values.map { it.toString() }.toSet()).apply()
    }
}

class ApiClient(private val context: Context) {
    private val cookieJar = PersistentCookieJar(context.applicationContext)
    private val client = OkHttpClient.Builder()
        .cookieJar(cookieJar)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    val isPortal: Boolean get() = BuildConfig.APP_MODE == "portal"
    val base: String get() = BuildConfig.API_BASE.trimEnd('/')

    suspend fun get(path: String): Any = request("GET", path, null)
    suspend fun post(path: String, body: JSONObject = JSONObject()): Any = request("POST", path, body)

    private fun urlFor(path: String): String = if (path.startsWith("http")) path else base + if (path.startsWith('/')) path else "/$path"

    private fun publicError(text: String, fallback: String): String {
        if (text.isBlank()) return fallback
        return try {
            val json = JSONObject(text)
            json.optString("message").ifBlank { json.optString("error") }.ifBlank { fallback }
        } catch (_: Exception) {
            text.take(300).ifBlank { fallback }
        }
    }

    suspend fun request(method: String, path: String, body: JSONObject?): Any = withContext(Dispatchers.IO) {
        val builder = Request.Builder()
            .url(urlFor(path))
            .header("Accept", "application/json, text/plain;q=0.9")
            .header("User-Agent", "GhadirPartnerNative/${BuildConfig.VERSION_NAME} Android")
        if (method == "POST") {
            val payload = (body ?: JSONObject()).toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            builder.post(payload)
        } else builder.get()

        client.newCall(builder.build()).execute().use { response ->
            val text = response.body?.string().orEmpty().trim()
            if (!response.isSuccessful) {
                throw ApiException(response.code, publicError(text, "خطای ارتباط با سرور (${response.code})"))
            }
            if (text.isBlank()) return@use JSONObject()
            when {
                text.startsWith("{") -> JSONObject(text)
                text.startsWith("[") -> JSONArray(text)
                else -> text
            }
        }
    }

    fun modeAllowed(me: JSONObject): Boolean {
        val roles = me.arr("roles").strings().toSet()
        return if (isPortal) {
            "customer" in roles
        } else {
            roles.any { it in setOf("admin", "sales", "finance", "prep", "viewer") }
        }
    }

    fun modeError(): String = if (isPortal) "این حساب برای پرتال مشتریان مجاز نیست." else "حساب مشتری اجازه ورود به اتوماسیون را ندارد."

    suspend fun login(identity: String, password: String) {
        val body = JSONObject()
            .put("Username", identity.trim())
            .put("Password", password)
            .put("app_mode", BuildConfig.APP_MODE)
        post("/api/login", body)
        val session = me()
        if (!modeAllowed(session)) {
            logout()
            throw ApiException(403, modeError())
        }
    }

    suspend fun logout() {
        try { get("/api/logout") } catch (_: Exception) {}
        cookieJar.clear()
    }

    suspend fun me(): JSONObject = get("/api/me") as JSONObject

    suspend fun downloadFile(path: String, fileName: String, mimeType: String): String = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(urlFor(path))
            .header("Accept", mimeType)
            .header("User-Agent", "GhadirPartnerNative/${BuildConfig.VERSION_NAME} Android")
            .get()
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val text = response.body?.string().orEmpty()
                throw ApiException(response.code, publicError(text, "دانلود فایل ناموفق بود (${response.code})"))
            }
            val body = response.body ?: throw ApiException(500, "فایل دریافتی خالی است")
            val safeName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "-")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                    put(MediaStore.Downloads.MIME_TYPE, mimeType)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/GhadirPartner")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw ApiException(500, "امکان ایجاد فایل دانلود وجود ندارد")
                try {
                    resolver.openOutputStream(uri)?.use { output -> body.byteStream().use { it.copyTo(output) } }
                        ?: throw ApiException(500, "امکان ذخیره فایل وجود ندارد")
                    values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    "Downloads/GhadirPartner/$safeName"
                } catch (e: Exception) {
                    resolver.delete(uri, null, null)
                    throw e
                }
            } else {
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, safeName)
                file.outputStream().use { output -> body.byteStream().use { it.copyTo(output) } }
                file.absolutePath
            }
        }
    }
}
