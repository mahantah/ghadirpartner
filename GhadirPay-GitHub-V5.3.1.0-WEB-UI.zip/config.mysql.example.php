<?php
return [
    'timezone' => 'Asia/Tehran',
    'warehouse_connected' => false,
    'storage' => __DIR__ . '/storage',

    // مرحله اول: تا وقتی دیتابیس را در cPanel نساخته‌اید روی json بماند.
    // بعد از ساخت DB/User و تکمیل مشخصات زیر، مقدار را mysql کنید.
    'storage_driver' => 'mysql',
    'mysql' => [
        'host' => 'localhost',
        'port' => 3306,
        'database' => 'CPANEL_DB_NAME',
        'username' => 'CPANEL_DB_USER',
        'password' => 'STRONG_DB_PASSWORD',
        'charset' => 'utf8mb4',
        'auto_migrate_from_json' => true,
    ],

    'homa_api_token' => '',
    'homa_api_endpoint' => 'https://www.homacrm.com/api/v1/external/messaging/send',
    'homa_legacy_fallback' => false,
    'homa_username' => '',
    'homa_password' => '',
    'homa_portal_code' => '',
    'homa_server_type' => '100',
    'homa_direct_endpoint' => 'https://api.homais.com/services/messaging/sms/api/sendMessage/direct/',
    'homa_otp_endpoint' => 'https://api.homais.com/services/messaging/sms/api/sendMessage/OTP/',
    'sms_endpoint' => '',
    'sms_token' => '',
    'online_payment_enabled' => false,
    'payment_demo_enabled' => false,
    'payment_endpoint' => '',
];
