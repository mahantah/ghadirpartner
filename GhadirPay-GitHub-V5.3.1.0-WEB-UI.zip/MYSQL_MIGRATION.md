# مهاجرت امن Ghadir Partner به MySQL

این نسخه ساختار فعلی V5.2.32.42 را بدون تغییر منطق سفارش و انبار به یک Storage تراکنشی MySQL منتقل می‌کند.

## روش راه‌اندازی
1. در cPanel > MySQL Database Wizard یک دیتابیس و یک کاربر بسازید و ALL PRIVILEGES بدهید.
2. `config.php` زنده را ویرایش کنید. ابتدا اطلاعات `mysql` را وارد کنید و `storage_driver` را فقط پس از اطمینان از صحت DB روی `mysql` بگذارید.
3. با اولین درخواست، اگر جدول MySQL خالی باشد، سیستم به صورت خودکار از `storage/ghadir_data.json` بکاپ می‌گیرد و همان داده را وارد MySQL می‌کند.
4. صحت مهاجرت با SHA-256 و تعداد کاربران، مشتریان، سفارش‌ها، سریال‌ها، کارتن‌ها و محصولات کنترل می‌شود. اگر تطبیق کامل نباشد Transaction Rollback می‌شود و JSON اصلی تغییر نمی‌کند.
5. بعد از موفقیت، فایل `storage/.mysql-migrated.json` ایجاد می‌شود و JSON قدیمی به عنوان بکاپ نگه داشته می‌شود.

## نکات امنیتی
- `config.php` و رمز MySQL هرگز در GitHub قرار نگیرد.
- بعد از مهاجرت موفق، Storage اصلی MySQL است. JSON را دستی ویرایش نکنید.
- بکاپ دستی سامانه در حالت MySQL هم Snapshot JSON از دیتای جاری ایجاد می‌کند.
- endpoint مدیریتی `GET /api/storage-info` وضعیت Driver، Revision و Checksum را برای Admin نمایش می‌دهد.
