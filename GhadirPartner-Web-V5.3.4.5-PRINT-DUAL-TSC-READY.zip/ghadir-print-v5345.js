/* GhadirPartner Web V5.3.4.5 — additive TSC Print Center */
(function(){
  'use strict';
  if(window.__GP_TSC_5345__) return;
  window.__GP_TSC_5345__=true;

  const $id=(id)=>document.getElementById(id);
  const num=(id,def)=>{const el=$id(id);const v=el?Number(el.value):NaN;return Number.isFinite(v)?v:def};
  const setv=(id,v)=>{const el=$id(id);if(el)el.value=v??''};

  const profiles=[
    ['order','جزئیات سفارش','100','150'],
    ['box','لیبل عمومی باکس','100','70'],
    ['roll12','باکس رول ۱۲ متری','100','70'],
    ['roll14','باکس رول ۱۴ متری','100','70'],
    ['roll16','باکس رول ۱۶ متری','100','70']
  ];

  function profileHtml(p,title,w,h){
    return `<div class="gp-print-profile">
      <h4>${title}</h4>
      <div class="gp-print-grid">
        <label>عرض (mm)<input id="gp_${p}_w" type="number" min="25" max="108" step="0.1" value="${w}"></label>
        <label>ارتفاع (mm)<input id="gp_${p}_h" type="number" min="20" max="300" step="0.1" value="${h}"></label>
        <label>Gap (mm)<input id="gp_${p}_gap" type="number" min="0" max="15" step="0.1" value="3"></label>
        <label>Offset X (mm)<input id="gp_${p}_x" type="number" min="-10" max="10" step="0.1" value="0"></label>
        <label>Offset Y (mm)<input id="gp_${p}_y" type="number" min="-10" max="10" step="0.1" value="0"></label>
      </div>
      <div class="gp-print-actions">
        <button class="btnlight" type="button" onclick="gpTscTest('${p}')">چاپ تست ${title}</button>
      </div>
    </div>`;
  }

  function ensureCard(){
    const settings=$id('settings');
    if(!settings || $id('gpPrintCenter')) return;
    const card=document.createElement('div');
    card.id='gpPrintCenter';
    card.className='card';
    card.innerHTML=`
      <div class="section-title">
        <div>
          <h3 style="margin:0">مرکز چاپ و لیبل TSC</h3>
          <div class="small">TSC TTP-244 Pro — 203 DPI — اندازه‌ها بر حسب میلی‌متر</div>
        </div>
        <span class="gp-printer-badge">TSC TTP-244 Pro · 203dpi</span>
      </div>
      <div class="mutedbox" style="margin-bottom:10px">
        حالت PDF و لیبل از هم جدا شده‌اند. برای TSC: Paper Size دقیقاً برابر پروفایل، Scale=100%، Margin=0 و Layout=Portrait باشد. بعد از تعویض سایز رول/لیبل Calibration انجام شود. چاپ لیبل از گوشه بالا-راست شروع می‌شود و دیگر Center نمی‌شود.
      </div>
      <div style="display:grid;gap:10px">${profiles.map(x=>profileHtml(...x)).join('')}</div>
      <div class="gp-print-actions" style="margin-top:12px">
        <button class="btn2" type="button" onclick="gpSavePrintSettings()">ذخیره تنظیمات چاپ</button>
        <span id="gpPrintMsg" class="small"></span>
      </div>`;
    const first=settings.querySelector('.card');
    if(first) first.after(card); else settings.appendChild(card);
  }

  window.gpLoadPrintSettings=async function(){
    ensureCard();
    if(typeof req!=='function') return;
    try{
      const x=await req('/api/settings');
      for(const [p,,dw,dh] of profiles){
        setv(`gp_${p}_w`,x[`print_${p}_w`]??dw);
        setv(`gp_${p}_h`,x[`print_${p}_h`]??dh);
        setv(`gp_${p}_gap`,x[`print_${p}_gap`]??3);
        setv(`gp_${p}_x`,x[`print_${p}_x`]??0);
        setv(`gp_${p}_y`,x[`print_${p}_y`]??0);
      }
    }catch(e){
      const m=$id('gpPrintMsg');
      if(m)m.textContent=e.message||String(e);
    }
  };

  window.gpSavePrintSettings=async function(){
    if(typeof req!=='function') return;
    const body={print_printer:'TSC TTP-244 Pro',print_dpi:203};
    for(const [p] of profiles){
      body[`print_${p}_w`]=num(`gp_${p}_w`,100);
      body[`print_${p}_h`]=num(`gp_${p}_h`,p==='order'?150:70);
      body[`print_${p}_gap`]=num(`gp_${p}_gap`,3);
      body[`print_${p}_x`]=num(`gp_${p}_x`,0);
      body[`print_${p}_y`]=num(`gp_${p}_y`,0);
    }
    const m=$id('gpPrintMsg');
    try{
      await req('/api/settings',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify(body)
      });
      if(m){m.className='ok';m.textContent='تنظیمات چاپ ذخیره شد.'}
    }catch(e){
      if(m){m.className='msg';m.textContent=e.message||String(e)}
    }
  };

  window.gpTscTest=(profile)=>window.open(`/print/tsc-test?profile=${encodeURIComponent(profile)}`,'_blank');

  function ensureOrderPrintButton(){
    const host=$id('orderDetailBody');
    if(!host || host.querySelector('[data-gp-tsc-order]')) return;
    const btn=[...host.querySelectorAll('button')].find(b=>(b.getAttribute('onclick')||'').includes('/pdf/order-details?id='));
    if(!btn) return;
    const m=(btn.getAttribute('onclick')||'').match(/order-details\?id=(\d+)/);
    if(!m) return;
    const b=document.createElement('button');
    b.type='button';
    b.className='btnlight';
    b.dataset.gpTscOrder='1';
    b.textContent='چاپ مستقیم لیبل TSC';
    b.onclick=()=>window.open(`/print/order-label?id=${m[1]}`,'_blank');
    btn.after(b);
  }

  document.addEventListener('click',(ev)=>{
    const t=ev.target.closest&&ev.target.closest('[data-tab="settings"]');
    if(t)setTimeout(()=>window.gpLoadPrintSettings(),80);
    setTimeout(ensureOrderPrintButton,0);
  },true);

  const detail=$id('orderDetailBody');
  if(detail&&window.MutationObserver){
    new MutationObserver(ensureOrderPrintButton).observe(detail,{childList:true,subtree:true});
  }
  ensureCard();
})();
