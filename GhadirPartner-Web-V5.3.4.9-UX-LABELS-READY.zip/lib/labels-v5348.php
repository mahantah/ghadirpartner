<?php
/* GhadirPartner V5.3.4.9 physical label renderer */

function gp_h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}

function gp_code128_svg($text){
 $patterns=['212222','222122','222221','121223','121322','131222','122213','122312','132212','221213','221312','231212','112232','122132','122231','113222','123122','123221','223211','221132','221231','213212','223112','312131','311222','321122','321221','312212','322112','322211','212123','212321','232121','111323','131123','131321','112313','132113','132311','211313','231113','231311','112133','112331','132131','113123','113321','133121','313121','211331','231131','213113','213311','213131','311123','311321','331121','312113','312311','332111','314111','221411','431111','111224','111422','121124','121421','141122','141221','112214','112412','122114','122411','142112','142211','241211','221114','413111','241112','134111','111242','121142','121241','114212','124112','124211','411212','421112','421211','212141','214121','412121','111143','111341','131141','114113','114311','411113','411311','113141','114131','311141','411131','211412','211214','211232','2331112'];
 $text=strtoupper(trim((string)$text));$codes=[104];
 for($i=0;$i<strlen($text);$i++){$n=ord($text[$i])-32;if($n<0||$n>94)$n=0;$codes[]=$n;}
 $sum=104;for($i=1;$i<count($codes);$i++)$sum+=$codes[$i]*$i;
 $codes[]=$sum%103;$codes[]=106;$x=8;$bars='';
 foreach($codes as $code){$pat=$patterns[$code];for($i=0;$i<strlen($pat);$i++){$w=(int)$pat[$i]*2;if($i%2===0)$bars.='<rect x="'.$x.'" y="1" width="'.$w.'" height="38"/>';$x+=$w;}}
 $width=$x+8;
 return '<svg class="barcode" viewBox="0 0 '.$width.' 40" preserveAspectRatio="none" aria-label="'.gp_h($text).'">'.$bars.'</svg>';
}

function gp_print_order_shipping_label($o,$c,$sender,$profile){
 $w=$profile['w'];$h=$profile['h'];$x=$profile['x'];$y=$profile['y'];
 $orderNo=(string)($o['number']??'');
 $host=(string)($_SERVER['HTTP_HOST']??'ghadirpartner.ir');
 $scheme=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'https';
 $qrUrl=$scheme.'://'.$host.'/?tab=orders&open_order='.(int)($o['id']??0);
 $senderLine=trim((string)($sender['sender_name']??''));$senderMobile=trim((string)($sender['sender_mobile']??''));
 if($senderMobile!=='')$senderLine.=($senderLine!==''?' — ':'').$senderMobile;
 $receiverLine=trim((string)($c['name']??$o['customer_name']??''));$company=trim((string)($c['company']??''));
 if($company!=='')$receiverLine.=($receiverLine!==''?' — ':'').$company;
 $receiverMobile=trim((string)($c['mobile']??''));
 $address=gp_customer_address($c);
 $items='';foreach($o['items']??[] as $it)$items.='<div class="item"><b>'.gp_h($it['product']??'').'</b><span>'.(int)($it['qty']??0).' عدد</span></div>';
 header('Content-Type:text/html; charset=utf-8');
 echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>لیبل ارسال '.gp_h($orderNo).'</title><style>
 @page{size:'.$w.'mm '.$h.'mm;margin:0}
 *{box-sizing:border-box}html,body{margin:0!important;padding:0!important;width:'.$w.'mm!important;height:'.$h.'mm!important;overflow:hidden!important;background:#fff;font-family:Tahoma,Arial;color:#0b1f3a;-webkit-print-color-adjust:exact;print-color-adjust:exact}
 .toolbar{position:fixed;z-index:50;left:2mm;top:2mm}.toolbar button{background:#0b1f3a;color:#fff;border:0;border-radius:7px;padding:8px 13px;font-family:inherit}
 .label{position:absolute;top:0;right:0;width:'.$w.'mm;height:'.$h.'mm;padding:5mm;transform:translate('.$x.'mm,'.$y.'mm);transform-origin:top right;background:#fff;overflow:hidden}
 .brand{display:flex;justify-content:space-between;align-items:center;border-bottom:1.3mm solid #f58220;padding-bottom:3mm}.brand img{width:17mm;height:17mm;object-fit:contain}.brand h1{font-size:20px;margin:0}.brand .ord{direction:ltr;font:900 17px Consolas,monospace;margin-top:1mm}
 .party{margin-top:4mm;border:.35mm solid #d5dee9;border-radius:3mm;padding:3mm;line-height:1.8;font-size:11px}.party h3{font-size:12px;margin:0 0 1mm;color:#f58220}.address{margin-top:1mm;color:#334e68}
 .items{margin-top:4mm;border-top:.3mm solid #d5dee9}.item{display:flex;justify-content:space-between;gap:4mm;padding:2mm 0;border-bottom:.2mm dashed #c9d4df;font-size:10.5px}
 .bottom{position:absolute;left:5mm;right:5mm;bottom:5mm;display:grid;grid-template-columns:28mm 1fr;gap:4mm;align-items:center}.qrbox{text-align:center}.qrbox .gp-local-qr{width:27mm;height:27mm;display:block;margin:auto}.qrbox small{display:block;font-size:7px;margin-top:1mm}.notice{border:.45mm solid #f58220;border-radius:3mm;padding:4mm;font-weight:900;text-align:center;color:#7a3600}.notice small{display:block;color:#53647b;font-weight:500;margin-top:2mm}
 @media print{.toolbar{display:none!important}}
 </style></head><body><div class="toolbar"><button onclick="window.print()">چاپ لیبل ارسال</button></div><main class="label"><div class="brand"><div><h1>قدیر پارتنر</h1><div class="ord">'.gp_h($orderNo).'</div></div><img src="/brand-v5311.png" alt="قدیر پارتنر"></div>
 <div class="party"><h3>فرستنده</h3><b>'.gp_h($senderLine).'</b><div class="address">'.gp_h($sender['sender_address']??'').'</div></div>
 <div class="party"><h3>گیرنده</h3><b>'.gp_h($receiverLine).'</b>'.($receiverMobile!==''?'<div>'.gp_h($receiverMobile).'</div>':'').'<div class="address">'.gp_h($address).'</div></div>
 <div class="items">'.$items.'</div>
 <div class="bottom"><div class="qrbox"><div id="orderQr" data-value="'.gp_h($qrUrl).'"></div><small>QR سفارش '.gp_h($orderNo).'</small></div><div class="notice">مرسوله شکستنی است — با احتیاط حمل شود<small>اسکن QR برای مشاهده همان سفارش در قدیر پارتنر</small></div></div></main><script src="/assets/qrcode-v5349.js"></script><script>(function(){var e=document.getElementById("orderQr");if(e&&window.GPQRCodeSvg)e.innerHTML=GPQRCodeSvg(e.dataset.value);})();</script></body></html>';
}

function gp_carton_ticket_html($c){
 $code=(string)($c['code']??'');$product=(string)($c['product']??'');$color=trim((string)($c['color']??''));
 $count=count($c['_serials']??[]);$cap=(int)($c['capacity']??0);
 $payload=$code; // scanner returns the carton code; warehouse search resolves the carton.
 return '<article class="ticket"><div class="t-head"><img src="/brand-v5311.png" alt=""><div><b>قدیر پارتنر</b><div class="code">'.gp_h($code).'</div></div></div><div class="product">'.gp_h($product).'</div><div class="meta"><span>تعداد: <b>'.$count.'</b>'.($cap?' / '.$cap:'').'</span>'.($color!==''?'<span>رنگ: <b>'.gp_h($color).'</b></span>':'').'</div>'.gp_code128_svg($payload).'<div class="scantext">اسکن بارکد = جستجو و بازیابی اطلاعات باکس در مخزن</div></article>';
}

function gp_print_carton_labels_three_up($cartons,$profile){
 $w=$profile['w'];$h=$profile['h'];$x=$profile['x'];$y=$profile['y'];
 $chunks=array_chunk(array_values($cartons),3);$pages='';
 foreach($chunks as $chunk){
   $tickets='';foreach($chunk as $c)$tickets.=gp_carton_ticket_html($c);
   while(count($chunk)<3){$tickets.='<article class="ticket empty"></article>'; $chunk[]=[];}
   $pages.='<section class="physical">'.$tickets.'</section>';
 }
 header('Content-Type:text/html; charset=utf-8');
 echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>لیبل مخزن — سه باکس در هر لیبل</title><style>
 @page{size:'.$w.'mm '.$h.'mm;margin:0}
 *{box-sizing:border-box}html,body{margin:0;padding:0;background:#eef2f7;font-family:Tahoma,Arial;color:#0b1f3a}
 .toolbar{position:sticky;top:0;z-index:50;padding:10px;text-align:center;background:#eef2f7}.toolbar button{background:#0b1f3a;color:#fff;border:0;border-radius:8px;padding:9px 16px;font-family:inherit}
 .physical{width:'.$w.'mm;height:'.$h.'mm;background:#fff;display:grid;grid-template-rows:repeat(3,1fr);margin:0;break-after:page;page-break-after:always;transform:translate('.$x.'mm,'.$y.'mm);transform-origin:top right;overflow:hidden}
 .physical:last-child{break-after:auto;page-break-after:auto}.ticket{position:relative;padding:4mm 5mm;border-bottom:.35mm dashed #8594a6;overflow:hidden}.ticket:last-child{border-bottom:0}.ticket.empty{background:#fff}
 .t-head{display:flex;justify-content:space-between;align-items:center;gap:3mm}.t-head img{width:11mm;height:11mm;object-fit:contain}.t-head>b{font-size:12px}.code{direction:ltr;font:900 13px Consolas,monospace;color:#0b1f3a}.product{font-size:13px;font-weight:900;margin:2mm 0 1.5mm;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.meta{display:flex;gap:7mm;font-size:9px;color:#53647b}.barcode{display:block;width:100%;height:14mm;fill:#000;margin-top:2mm}.scantext{text-align:center;font-size:7px;color:#53647b;margin-top:.8mm}
 @media print{body{background:#fff}.toolbar{display:none!important}.physical{margin:0}}
 </style></head><body><div class="toolbar"><button onclick="window.print()">چاپ پشت سر هم — ۳ باکس در هر لیبل</button></div>'.$pages.'</body></html>';
}
?>