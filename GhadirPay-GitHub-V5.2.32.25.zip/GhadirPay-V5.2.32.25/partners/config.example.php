<?php
return [
    'timezone' => 'Asia/Tehran',
    'warehouse_connected' => false,
    // پرتال و اتوماسیون اصلی یک Data مشترک دارند؛ نشست‌های ورود همچنان جدا و ایمن‌اند.
    'storage' => dirname(__DIR__) . '/storage',
    // برای اتصال واقعی، آدرس API و توکن پنل پیامک در این دو مقدار قرار می‌گیرد.
    // Homa CRM / HomaIS direct SMS REST
    'homa_endpoint' => 'https://api.homais.com/services/messaging/sms/api/sendMessage/direct/',
    'homa_username' => '',
    'homa_password' => '',
    'homa_portal_code' => '',
    'homa_server_type' => '100',

    'sms_endpoint' => '',
    'sms_token' => '',
    // خالی بودن این مقدار، درگاه آزمایشی داخلی را فعال نگه می‌دارد.
    'payment_endpoint' => '',
];
