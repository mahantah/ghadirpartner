<?php
return [
    'timezone' => 'Asia/Tehran',
    'warehouse_connected' => false,
    'storage' => __DIR__ . '/storage',
    // Homa CRM / HomaIS direct SMS REST
    'homa_endpoint' => 'https://api.homais.com/services/messaging/sms/api/sendMessage/direct/',
    'homa_username' => '',
    'homa_password' => '',
    'homa_portal_code' => '',
    'homa_server_type' => '100',

    'sms_endpoint' => '',
    'sms_token' => '',
    'payment_endpoint' => '',
];
