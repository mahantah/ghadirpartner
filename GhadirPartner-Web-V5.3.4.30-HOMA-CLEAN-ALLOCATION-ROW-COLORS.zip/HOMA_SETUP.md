# Homa CRM — V5.3.4.30

این نسخه بر اساس مستندات ارائه‌شده از Homa، فقط از API جدید توکن‌محور استفاده می‌کند.

## تنظیمات لازم در `public_html/config.php`

```php
'homa_api_token' => 'YOUR_REAL_TOKEN',
'homa_api_endpoint' => 'https://www.homacrm.com/api/v1/external/messaging/send',
```

## رفتار ارسال

- احراز هویت: `Authorization: Bearer <TOKEN>`
- Payload فقط شامل `recipient` و `message` است.
- فیلد `from` / `sender` ارسال نمی‌شود تا خط پیش‌فرض پرتال Homa استفاده شود.
- fallback قدیمی `api.homais.com` در مسیر ارسال استفاده نمی‌شود.
- برای هر پیام فقط یک درخواست ارسال می‌شود تا خطر ارسال تکراری وجود نداشته باشد.
- Timeout برابر ۳۰ ثانیه و Connect Timeout برابر ۸ ثانیه است.
- OTP و پیامک عادی هر دو از همین درگاه جدید استفاده می‌کنند.

نمونه Payload:

```json
{
  "recipient": "09xxxxxxxxx",
  "message": "متن پیام"
}
```

توکن واقعی فقط روی `config.php` سرور نگهداری شود و داخل ZIP/GitHub قرار نگیرد.
