<?php
return [
    'timezone' => 'Asia/Tehran',
    'warehouse_connected' => false,
    'storage' => __DIR__ . '/storage',

    // این نسخه فقط از دیتابیس MySQL فعلی استفاده می‌کند.
    // فایل config.php عملیاتی هاست را با این نمونه جایگزین نکنید.
    'storage_driver' => 'mysql',
    'mysql' => [
        'host' => 'localhost',
        'port' => 3306,
        'database' => 'CPANEL_DB_NAME',
        'username' => 'CPANEL_DB_USER',
        'password' => 'STRONG_DB_PASSWORD',
        'charset' => 'utf8mb4',
        'auto_migrate_from_json' => false,
    ],

    'homa_api_token' => '',
    'homa_api_endpoint' => 'https://www.homacrm.com/api/v1/external/messaging/send',
    // در API جدید sender/from ارسال نمی‌شود؛ خط پیش‌فرض پرتال Homa استفاده می‌شود.
    // زمان انتظار درخواست در کد ۳۰ ثانیه است.
    'sms_endpoint' => '',
    'sms_token' => '',
    'online_payment_enabled' => false,
    'payment_demo_enabled' => false,
    'payment_endpoint' => '',
];
