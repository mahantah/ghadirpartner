package ir.ghadirpartner.nativeapp

import android.widget.Toast
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val portalNav = listOf(
    NavItem("home", "پیشخوان", Icons.Default.Home),
    NavItem("orders", "سفارش‌ها", Icons.Default.ReceiptLong),
    NavItem("new", "سفارش جدید", Icons.Default.AddCircle),
    NavItem("catalog", "فهرست قیمت", Icons.Default.LocalOffer),
    NavItem("profile", "پروفایل", Icons.Default.AccountCircle)
)

@Composable
fun PortalApp(api: ApiClient, me: JSONObject, onLogout: () -> Unit) {
    var screen by remember { mutableStateOf("home") }
    var draftProduct by remember { mutableStateOf("") }
    var draftPromo by remember { mutableStateOf("") }
    var selectedOrder by remember { mutableStateOf<JSONObject?>(null) }
    var currentMe by remember { mutableStateOf(JSONObject(me.toString())) }
    val customerName = currentMe.obj("customer").s("name").ifBlank { currentMe.s("username") }

    Scaffold(
        containerColor = Canvas,
        topBar = { BrandHeader("قدیر پارتنر", customerName) },
        bottomBar = {
            if (screen != "order-detail") {
                BottomBar(portalNav, screen) {
                    selectedOrder = null
                    screen = it
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            Crossfade(targetState = screen, label = "portal-nav") { target ->
                when (target) {
                    "home" -> PortalHome(
                        api, currentMe,
                        onOffer = { o -> draftProduct=o.s("product");draftPromo=o.s("promo_code");screen="new" },
                        navigate = { screen = it },
                        openOrder = { selectedOrder = it; screen = "order-detail" }
                    )
                    "orders" -> PortalOrders(api) { selectedOrder = it; screen = "order-detail" }
                    "new" -> PortalNewOrder(api, draftProduct, draftPromo) { draftProduct="";draftPromo="";screen = "orders" }
                    "catalog" -> PortalCatalog(api) { product -> draftProduct=product;draftPromo="";screen="new" }
                    "order-detail" -> selectedOrder?.let { order ->
                        PortalOrderDetails(api, order, onBack = { screen = "orders" })
                    } ?: PortalOrders(api) { selectedOrder = it; screen = "order-detail" }
                    else -> PortalProfile(
                        api = api,
                        me = currentMe,
                        onUpdated = { result ->
                            val next = JSONObject(currentMe.toString())
                            next.put("customer", result.obj("customer"))
                            next.put("alternate_mobile", result.s("alternate_mobile"))
                            currentMe = next
                        },
                        onLogout = onLogout
                    )
                }
            }
        }
    }
}


private fun promoNorm(v: String): String = v.replace(Regex("\\s+"), "").trim().uppercase()

private fun offerDiscountTextNative(o: JSONObject): String {
    val type = o.s("discount_type")
    val value = o.l("discount_value")
    return when {
        type == "percent" && value > 0 -> "${faNumber(value)}٪ تخفیف"
        type == "amount" && value > 0 -> "${formatMoney(value)} تومان تخفیف"
        else -> "پیشنهاد ویژه"
    }
}

@Composable
private fun PortalHome(api: ApiClient, me: JSONObject, onOffer: (JSONObject) -> Unit, navigate: (String) -> Unit, openOrder: (JSONObject) -> Unit) {
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var orders by remember { mutableStateOf(emptyList<JSONObject>()) }
    var offers by remember { mutableStateOf(emptyList<JSONObject>()) }
    var stats by remember { mutableStateOf(JSONObject()) }

    fun refresh() {
        scope.launch {
            loading = true; error = ""
            try {
                orders = (api.get("/api/orders") as JSONArray).objects().sortedByDescending { it.i("id") }
                offers = (api.get("/api/offers") as JSONArray).objects().filter { !it.b("used_by_customer") }
                stats = api.get("/api/reports/customer-summary") as JSONObject
            } catch (e: Exception) { error = e.message ?: "خطا در دریافت اطلاعات" }
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }
    if (loading) { LoadingPane(); return }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 15.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 26.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        item { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ProfileAvatar(me.obj("customer").s("profile_photo"), me.obj("customer").s("name"))
            Text(me.obj("customer").s("name") + "، خوش آمدید", color = NavyDeep, fontWeight = FontWeight.Bold)
        } }
        if (offers.isNotEmpty()) {
            item { SectionTitle("طرح‌ها و آفرهای فعال") }
            items(offers, key = { "offer-" + it.i("id") }) { o ->
                Surface(shape = RoundedCornerShape(19.dp), color = Color(0xFFFFF1E3), border = BorderStroke(2.dp, Orange)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.End) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            if (o.s("promo_code").isNotBlank()) {
                                Surface(shape = RoundedCornerShape(999.dp), color = Color(0xFFEEF4FB)) {
                                    Text(
                                        o.s("promo_code"),
                                        color = NavySoft,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                                    )
                                }
                            }
                            Spacer(Modifier.weight(1f))
                            Column(horizontalAlignment = Alignment.End) {
                                Text(o.s("title"), color = NavyDeep, fontWeight = FontWeight.Black, fontSize = 19.sp)
                                Text(offerDiscountTextNative(o), color = Orange, fontWeight = FontWeight.ExtraBold, fontSize = 23.sp)
                            }
                        }
                        GhadirButton("استفاده از این پیشنهاد", onClick = { onOffer(o) })
                        if (o.s("description").isNotBlank()) {
                            Spacer(Modifier.height(5.dp))
                            Text(o.s("description"), color = Muted, fontSize = 10.sp, textAlign = TextAlign.End)
                        }
                        if (o.s("end_date").isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text("اعتبار تا ${formatDateFa(o.s("end_date"))}", color = Muted, fontSize = 9.sp)
                        }
                    }
                }
            }
        }
        item { ErrorBanner(error) { error = "" } }
        item {
            PortalSummaryHero(
                amount = stats.obj("month").l("amount"),
                orders = stats.obj("month").i("orders"),
                qty = stats.obj("month").i("qty")
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                MiniAction("سفارش جدید", Icons.Default.AddShoppingCart, Modifier.weight(1f)) { navigate("new") }
                MiniAction("فهرست قیمت", Icons.Default.LocalOffer, Modifier.weight(1f)) { navigate("catalog") }
                MiniAction("سفارش‌ها", Icons.Default.ReceiptLong, Modifier.weight(1f)) { navigate("orders") }
            }
        }
        item { SectionTitle("آخرین سفارش‌ها", "مشاهده همه") { navigate("orders") } }
        if (orders.isEmpty()) item { EmptyState("هنوز سفارشی ندارید", "از بخش سفارش جدید، اولین سفارش را ثبت کنید.") }
        items(orders.take(4), key = { it.i("id") }) { o ->
            OrderCard(
                number = o.s("number"), customer = "", status = o.s("status"), payment = o.s("payment_status"),
                amount = if (o.l("approved_total") > 0) o.l("approved_total") else o.l("estimated_total"),
                date = o.s("created_at")
            ) { openOrder(o) }
        }
        item { SectionTitle("گزارش خرید") }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                StatTile("۷ روز", faNumber(stats.obj("week").i("orders")), "سفارش", Modifier.weight(1f))
                StatTile("۳۰ روز", faNumber(stats.obj("month").i("orders")), "سفارش", Modifier.weight(1f))
                StatTile("۹۰ روز", faNumber(stats.obj("three_months").i("orders")), "سفارش", Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun PortalSummaryHero(amount: Long, orders: Int, qty: Int) {
    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent), modifier = Modifier.fillMaxWidth()) {
        Box(
            Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(NavyDeep, Navy, Color(0xFF173F70)))).padding(20.dp)
        ) {
            Box(
                Modifier.size(120.dp).align(Alignment.BottomStart).offset(x = (-28).dp, y = 46.dp)
                    .clip(CircleShape).background(Color(0x33FF7A1A))
            )
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0x33FF7A1A)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.TrendingUp, null, tint = Orange)
                    }
                    Spacer(Modifier.weight(1f))
                    Column(horizontalAlignment = Alignment.End) {
                        Text("خرید ۳۰ روز اخیر", color = Color(0xFFC7D7EA), fontSize = 12.sp)
                        Text("${formatMoney(amount)} تومان", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    StatusPill("${faNumber(qty)} قلم")
                    Spacer(Modifier.width(8.dp))
                    StatusPill("${faNumber(orders)} سفارش")
                }
            }
        }
    }
}

@Composable
private fun MiniAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier = modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 15.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFFFE7D5)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Orange, modifier = Modifier.size(23.dp))
            }
            Spacer(Modifier.height(7.dp))
            Text(title, color = NavyDeep, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        }
    }
}

@Composable
private fun StatTile(title: String, value: String, caption: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Muted, fontSize = 10.sp)
            Text(value, color = NavyDeep, fontSize = 21.sp, fontWeight = FontWeight.Black)
            Text(caption, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun PortalOrders(api: ApiClient, onOpen: (JSONObject) -> Unit) {
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var orders by remember { mutableStateOf(emptyList<JSONObject>()) }

    fun refresh() {
        scope.launch {
            loading = true; error = ""
            try { orders = (api.get("/api/orders") as JSONArray).objects().sortedByDescending { it.i("id") } }
            catch (e: Exception) { error = e.message ?: "خطا" }
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }
    if (loading) { LoadingPane(); return }

    val filtered = orders.filter {
        query.isBlank() || listOf(it.s("number"), it.s("status"), it.s("payment_status")).any { v -> v.contains(query, true) }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        SearchBox(query, { query = it }, "جستجو در شماره یا وضعیت سفارش")
        Spacer(Modifier.height(9.dp)); ErrorBanner(error) { error = "" }
        Text("${faNumber(filtered.size)} سفارش", color = Muted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
        Spacer(Modifier.height(5.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (filtered.isEmpty()) item { EmptyState("سفارشی پیدا نشد", "فیلتر یا عبارت جستجو را تغییر دهید.") }
            items(filtered, key = { it.i("id") }) { o ->
                OrderCard(
                    o.s("number"), "", o.s("status"), o.s("payment_status"),
                    if (o.l("approved_total") > 0) o.l("approved_total") else o.l("estimated_total"), o.s("created_at")
                ) { onOpen(o) }
            }
        }
    }
}

@Composable
private fun PortalOrderDetails(api: ApiClient, order: JSONObject, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var downloading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val total = if (order.l("approved_total") > 0) order.l("approved_total") else order.l("estimated_total")

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowForward, "بازگشت", tint = NavyDeep) }
                Spacer(Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End) {
                    Text("جزئیات سفارش", color = NavyDeep, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Text(faDigits(order.s("number")), color = Muted, fontSize = 12.sp)
                }
            }
        }
        item { ErrorBanner(error) { error = "" } }
        item {
            Surface(shape = RoundedCornerShape(22.dp), color = Color.White) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    DetailLine("وضعیت سفارش", order.s("status").ifBlank { "-" })
                    DetailLine("وضعیت تسویه", order.s("payment_status").ifBlank { "-" })
                    DetailLine("روش پرداخت درخواستی", order.s("requested_payment_method_label").ifBlank { "-" })
                    DetailLine("نوع فاکتور", order.s("invoice_type").ifBlank { "-" })
                    DetailLine("تاریخ ثبت", formatDateFa(order.s("created_at")))
                    if (order.s("updated_at").isNotBlank()) DetailLine("آخرین تغییر", formatDateFa(order.s("updated_at")))
                    if (total > 0) DetailLine("مبلغ سفارش", "${formatMoney(total)} تومان", highlight = true)
                }
            }
        }
        if (order.s("shipping_type").isNotBlank() || order.s("tracking_code").isNotBlank()) item {
            Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFEAF2FF)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.End) {
                    Text("اطلاعات ارسال", color = NavyDeep, fontWeight = FontWeight.Black)
                    if (order.s("shipping_type").isNotBlank()) Text("روش ارسال: ${order.s("shipping_type")}", color = NavySoft, fontSize = 12.sp)
                    if (order.s("tracking_code").isNotBlank()) Text("کد مرسوله: ${order.s("tracking_code")}", color = Color(0xFF2457A6), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item { SectionTitle("اقلام سفارش") }
        items(order.arr("items").objects(), key = { it.s("product") }) { item ->
            Surface(shape = RoundedCornerShape(19.dp), color = Color.White) {
                Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.End) {
                    Text(shortProductName(item.s("product")), color = NavyDeep, fontWeight = FontWeight.Black, fontSize = 15.sp)
                    Spacer(Modifier.height(5.dp))
                    Text("تعداد: ${faNumber(item.i("qty"))} • ${item.s("price_label").ifBlank { "قیمت ثبت نشده" }}", color = Muted, fontSize = 11.sp)
                    if (item.l("unit_price") > 0) Text("قیمت واحد: ${formatMoney(item.l("unit_price"))} تومان", color = NavySoft, fontSize = 11.sp)
                    if (item.l("line_total") > 0) Text("جمع: ${formatMoney(item.l("line_total"))} تومان", color = Orange, fontWeight = FontWeight.ExtraBold)
                    if (order.s("status") == "تحویل شد") {
                        Text("سریال ثبت‌شده: ${faNumber(item.arr("serials").length())}", color = Success, fontSize = 11.sp)
                    }
                }
            }
        }
        if (order.s("notes").isNotBlank()) item {
            Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFFFFF6EE)) {
                Column(Modifier.fillMaxWidth().padding(13.dp), horizontalAlignment = Alignment.End) {
                    Text("توضیحات", color = NavyDeep, fontWeight = FontWeight.Bold)
                    Text(order.s("notes"), color = NavySoft, fontSize = 12.sp, textAlign = TextAlign.End)
                }
            }
        }
        if (order.s("status") == "تحویل شد") item {
            GhadirButton(
                text = if (downloading) "در حال دانلود..." else "دانلود لیست سریال‌ها",
                enabled = !downloading,
                onClick = {
                    scope.launch {
                        downloading = true; error = ""
                        try {
                            val name = "serials-${order.s("number")}.xlsx"
                            val where = api.downloadFile(
                                "/export/order-serials.xlsx?id=${order.i("id")}",
                                name,
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            )
                            Toast.makeText(context, "فایل سریال ذخیره شد: $where", Toast.LENGTH_LONG).show()
                        } catch (e: Exception) { error = e.message ?: "دانلود سریال ناموفق بود" }
                        finally { downloading = false }
                    }
                }
            )
        }
        if (order.arr("history").length() > 0) {
            item { SectionTitle("آخرین تغییرات سفارش") }
            items(order.arr("history").objects().takeLast(8).reversed()) { h ->
                Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.End) {
                        Text(h.s("action"), color = NavyDeep, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
                        Text("${formatDateFa(h.s("at"))} • ${h.s("by")}", color = Muted, fontSize = 9.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailLine(title: String, value: String, highlight: Boolean = false) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(value, color = if (highlight) Orange else NavyDeep, fontWeight = if (highlight) FontWeight.Black else FontWeight.Bold, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        Text(title, color = Muted, fontSize = 11.sp)
    }
}

private data class CartLine(val product: String, val qty: Int, val priceKey: String, val priceLabel: String, val unit: Long)

private fun discountForOfferNative(offer: JSONObject?, cart: List<CartLine>): Long {
    if (offer == null) return 0L
    val product = offer.s("product")
    val eligible = cart.filter { product.isBlank() || it.product == product }.sumOf { it.unit * it.qty }
    if (eligible <= 0L) return 0L
    val value = offer.l("discount_value").coerceAtLeast(0L)
    return when (offer.s("discount_type")) {
        "percent" -> minOf(eligible, eligible * minOf(100L, value) / 100L)
        "amount" -> minOf(eligible, value)
        else -> 0L
    }
}


@Composable
private fun PortalNewOrder(api: ApiClient, initialProduct: String, initialPromo: String, onSuccess: () -> Unit) {
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(true) }
    var submitting by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var products by remember { mutableStateOf(emptyList<JSONObject>()) }
    var offers by remember { mutableStateOf(emptyList<JSONObject>()) }
    var selected by remember { mutableStateOf<JSONObject?>(null) }
    var qtyText by remember { mutableStateOf("1") }
    var priceKey by remember { mutableStateOf("panel_cash") }
    var invoiceType by remember { mutableStateOf("غیررسمی") }
    var payment by remember { mutableStateOf("bank_transfer") }
    var notes by remember { mutableStateOf("") }
    var promoCode by remember { mutableStateOf(initialPromo) }
    var promoMessage by remember { mutableStateOf("") }
    var appliedOffer by remember { mutableStateOf<JSONObject?>(null) }
    var cart by remember { mutableStateOf(emptyList<CartLine>()) }

    LaunchedEffect(Unit) {
        try {
            products = (api.get("/api/catalog") as JSONArray).objects().filter { it.b("available") }
            offers = (api.get("/api/offers") as JSONArray).objects().filter { !it.b("used_by_customer") }
            selected = products.firstOrNull { it.s("name")==initialProduct && it.i("stock")>0 } ?: products.firstOrNull { it.i("stock") > 0 }
        } catch (e: Exception) { error = e.message ?: "خطا در لیست کالا" }
        loading = false
    }
    if (loading) { LoadingPane(); return }

    val priceLabels = listOf(
        "serial_1_50" to "سریال آزاد ۱ تا ۵۰", "serial_51_200" to "سریال آزاد ۵۱ تا ۲۰۰", "sales_agent" to "عامل فروش",
        "panel_cash" to "ثبت در پنل نقد", "panel_7d" to "ثبت در پنل هفت‌روزه", "panel_1m" to "ثبت در پنل یک‌ماهه"
    )
    val selectedPrices = selected?.obj("prices") ?: JSONObject()
    val activePriceLabels = priceLabels.filter { selectedPrices.optLong(it.first, 0) > 0 }
    LaunchedEffect(selected?.s("name")) {
        val p = selected
        if (p != null) {
            val prices = p.obj("prices")
            priceKey = priceLabels.firstOrNull { prices.optLong(it.first, 0) > 0 }?.first ?: "panel_cash"
        }
    }
    val selectedUnitPrice = selectedPrices.optLong(priceKey, 0)
    val selectedQty = qtyText.toIntOrNull()?.coerceAtLeast(0) ?: 0
    val selectedLineTotal = selectedUnitPrice * selectedQty
    val priceDisplay: (String) -> String = { k ->
        val label = activePriceLabels.firstOrNull { it.first == k }?.second ?: k
        val amount = selectedPrices.optLong(k, 0)
        if (amount > 0) "$label — ${formatMoney(amount)} تومان" else label
    }
    val cartSubtotal = cart.sumOf { it.unit * it.qty }
    val promoDiscount = discountForOfferNative(appliedOffer, cart)
    val cartFinal = (cartSubtotal - promoDiscount).coerceAtLeast(0L)

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("ثبت سفارش جدید", color = NavyDeep, fontSize = 22.sp, fontWeight = FontWeight.Black, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
            Text("کالاها را اضافه کنید و روش پرداخت را همان ابتدا مشخص کنید.", color = Muted, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
        }
        item { ErrorBanner(error) { error = "" } }
        item {
            DropdownField(
                title = "انتخاب محصول",
                value = selected?.let { shortProductName(it.s("name")) } ?: "انتخاب کنید",
                options = products.filter { it.i("stock") > 0 }.map { it.s("name") },
                display = { name -> shortProductName(name) },
                onSelect = { name -> selected = products.firstOrNull { it.s("name") == name } }
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = qtyText, onValueChange = { qtyText = it.filter(Char::isDigit).take(3) }, modifier = Modifier.weight(0.35f), singleLine = true,
                    label = { Text("تعداد") }, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, unfocusedBorderColor = Border)
                )
                Box(Modifier.weight(0.65f)) {
                    DropdownField(
                        "نوع قیمت",
                        if (activePriceLabels.isEmpty()) "قیمت فعالی ثبت نشده" else priceDisplay(priceKey),
                        activePriceLabels.map { it.first },
                        { k -> priceDisplay(k) }
                    ) { priceKey = it }
                }
            }
        }
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (selectedUnitPrice > 0) Color(0xFFFFF5E9) else Color(0xFFF5F7FA),
                border = BorderStroke(1.dp, if (selectedUnitPrice > 0) Color(0xFFFFD2A8) else Border)
            ) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (selectedUnitPrice > 0) "${formatMoney(selectedUnitPrice)} تومان" else "—",
                            color = if (selectedUnitPrice > 0) Orange else Muted,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp
                        )
                        Spacer(Modifier.weight(1f))
                        Column(horizontalAlignment = Alignment.End) {
                            Text("قیمت واحد انتخابی", color = NavySoft, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text("دریافت زنده از اتوماسیون", color = Muted, fontSize = 8.sp)
                        }
                    }
                    if (selectedUnitPrice > 0 && selectedQty > 0) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("${formatMoney(selectedLineTotal)} تومان", color = NavyDeep, fontWeight = FontWeight.Black, fontSize = 13.sp)
                            Spacer(Modifier.weight(1f))
                            Text("جمع این قلم برای ${faNumber(selectedQty)} عدد", color = Muted, fontSize = 10.sp)
                        }
                    }
                    if (activePriceLabels.isEmpty()) {
                        Text("برای این محصول هنوز قیمت فعالی در اتوماسیون ثبت نشده است.", color = Danger, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
                    }
                }
            }
        }
        item {
            GhadirButton("افزودن به سفارش", secondary = true, enabled = activePriceLabels.isNotEmpty(), onClick = {
                val p = selected ?: return@GhadirButton
                val q = qtyText.toIntOrNull() ?: 0
                if (q < 1 || q > p.i("stock")) { error = "تعداد انتخاب‌شده در حال حاضر قابل سفارش نیست"; return@GhadirButton }
                if (cart.any { it.product == p.s("name") }) { error = "این مدل قبلاً به سفارش اضافه شده است"; return@GhadirButton }
                val label = activePriceLabels.firstOrNull { it.first == priceKey }?.second ?: priceKey
                val unit = p.obj("prices").optLong(priceKey, 0)
                if (unit <= 0) { error = "برای نوع قیمت انتخاب‌شده مبلغ معتبری ثبت نشده است"; return@GhadirButton }
                cart = cart + CartLine(p.s("name"), q, priceKey, label, unit)
            })
        }
        if (cart.isNotEmpty()) {
            item { SectionTitle("اقلام سفارش") }
            items(cart, key = { it.product }) { line ->
                Surface(shape = RoundedCornerShape(18.dp), color = Color.White) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { cart = cart.filterNot { it.product == line.product }; promoMessage = if (appliedOffer != null) "مبلغ تخفیف با اقلام جدید دوباره محاسبه شد." else promoMessage }) { Icon(Icons.Default.DeleteOutline, null, tint = Danger) }
                        Text("${formatMoney(line.unit * line.qty)} تومان", color = Orange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Column(horizontalAlignment = Alignment.End) {
                            Text(shortProductName(line.product), color = NavyDeep, fontWeight = FontWeight.Bold)
                            Text("${faNumber(line.qty)} عدد • ${line.priceLabel}", color = Muted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
        item { SectionTitle("کد تخفیف") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = {
                            val code = promoNorm(promoCode)
                            val match = offers.firstOrNull {
                                promoNorm(it.s("promo_code")) == code &&
                                    it.s("discount_type") in listOf("percent", "amount") &&
                                    it.l("discount_value") > 0
                            }
                            if (code.isBlank()) {
                                appliedOffer = null
                                promoMessage = "کد تخفیف را وارد کنید."
                            } else if (match == null) {
                                appliedOffer = null
                                promoMessage = "این کد برای حساب شما معتبر یا فعال نیست."
                            } else {
                                val d = discountForOfferNative(match, cart)
                                if (d <= 0) {
                                    appliedOffer = null
                                    promoMessage = "این کد برای کالاهای فعلی سفارش قابل استفاده نیست."
                                } else {
                                    appliedOffer = match
                                    promoCode = promoNorm(match.s("promo_code"))
                                    promoMessage = "${offerDiscountTextNative(match)} با موفقیت اعمال شد."
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Orange),
                        shape = RoundedCornerShape(15.dp),
                        modifier = Modifier.height(54.dp)
                    ) { Text("اعمال", fontWeight = FontWeight.Black) }
                    OutlinedTextField(
                        value = promoCode,
                        onValueChange = {
                            promoCode = promoNorm(it).take(24)
                            appliedOffer = null
                            promoMessage = ""
                        },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        label = { Text("کد تخفیف") },
                        placeholder = { Text("GHADIR10") },
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, unfocusedBorderColor = Border)
                    )
                }
                if (promoMessage.isNotBlank()) {
                    Text(
                        promoMessage,
                        color = if (appliedOffer != null) Success else Danger,
                        fontSize = 10.sp,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.End
                    )
                }
                val visibleCodes = offers.filter {
                    it.s("promo_code").isNotBlank() &&
                        it.s("discount_type") in listOf("percent", "amount") &&
                        it.l("discount_value") > 0
                }.take(4)
                if (visibleCodes.isNotEmpty()) {
                    Text("کدهای فعال شما", color = Muted, fontSize = 9.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
                    visibleCodes.forEach { o ->
                        Surface(
                            shape = RoundedCornerShape(13.dp),
                            color = Color(0xFFF6F9FC),
                            modifier = Modifier.fillMaxWidth().clickable {
                                promoCode = promoNorm(o.s("promo_code"))
                                val d = discountForOfferNative(o, cart)
                                if (d > 0) {
                                    appliedOffer = o
                                    promoMessage = "${offerDiscountTextNative(o)} با موفقیت اعمال شد."
                                } else {
                                    appliedOffer = null
                                    promoMessage = "ابتدا کالای مشمول این طرح را به سفارش اضافه کنید."
                                }
                            }
                        ) {
                            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(o.s("promo_code"), color = NavySoft, fontWeight = FontWeight.Black, fontSize = 10.sp)
                                Spacer(Modifier.weight(1f))
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(o.s("title"), color = NavyDeep, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text(offerDiscountTextNative(o), color = Success, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
        item { DropdownField("نوع فاکتور", invoiceType, listOf("غیررسمی", "رسمی"), { it }) { invoiceType = it } }
        item {
            DropdownField(
                "روش پرداخت",
                when(payment) { "bank_transfer" -> "واریز بانکی / کارت‌به‌کارت"; "credit" -> "خرید اعتباری"; "check" -> "پرداخت با چک"; "installment" -> "پرداخت اقساطی"; else -> "انتخاب" },
                listOf("bank_transfer", "credit", "check", "installment"),
                { k -> when(k) { "bank_transfer" -> "واریز بانکی / کارت‌به‌کارت"; "credit" -> "خرید اعتباری"; "check" -> "پرداخت با چک"; else -> "پرداخت اقساطی" } },
                { payment = it }
            )
        }
        item {
            Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFFF1F3F6)) {
                Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LockClock, null, tint = Muted); Spacer(Modifier.width(8.dp))
                    Text("پرداخت آنلاین فعلاً تا اتصال API درگاه غیرفعال است.", color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                }
            }
        }
        item {
            OutlinedTextField(
                value = notes, onValueChange = { notes = it.take(500) }, modifier = Modifier.fillMaxWidth(), minLines = 3,
                label = { Text("توضیحات سفارش – اختیاری") }, shape = RoundedCornerShape(18.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, unfocusedBorderColor = Border)
            )
        }
        item {
            HeroCard(
                if (promoDiscount > 0) "جمع سفارش پس از تخفیف" else "جمع تقریبی سفارش",
                "${formatMoney(cartFinal)} تومان",
                if (promoDiscount > 0) "قبل تخفیف ${formatMoney(cartSubtotal)} تومان • تخفیف ${formatMoney(promoDiscount)} تومان" else "مبلغ نهایی پس از بررسی واحد فروش تأیید می‌شود",
                Icons.Default.AccountBalanceWallet
            )
        }
        item {
            GhadirButton(
                if (submitting) "در حال ثبت..." else "ثبت نهایی سفارش", enabled = cart.isNotEmpty() && !submitting,
                onClick = {
                    scope.launch {
                        submitting = true; error = ""
                        try {
                            val itemsJson = JSONArray()
                            cart.forEach { line -> itemsJson.put(JSONObject().put("product", line.product).put("qty", line.qty).put("price_key", line.priceKey)) }
                            if (promoCode.isNotBlank() && appliedOffer == null) {
                                error = "کد تخفیف را ابتدا اعمال و بررسی کنید"
                                submitting = false
                                return@launch
                            }
                            if (appliedOffer != null && promoDiscount <= 0) {
                                error = "کد تخفیف برای اقلام فعلی قابل استفاده نیست"
                                submitting = false
                                return@launch
                            }
                            val body = JSONObject()
                                .put("invoice_type", invoiceType)
                                .put("requested_payment_method", payment)
                                .put("notes", notes)
                                .put("promo_code", appliedOffer?.s("promo_code") ?: "")
                                .put("items", itemsJson)
                            api.post("/api/orders/add", body)
                            cart = emptyList()
                            promoCode = ""
                            promoMessage = ""
                            appliedOffer = null
                            onSuccess()
                        } catch (e: Exception) { error = e.message ?: "ثبت سفارش ناموفق بود" }
                        finally { submitting = false }
                    }
                }
            )
        }
    }
}

@Composable
private fun PortalCatalog(api: ApiClient, onOrder: (String) -> Unit) {
    var products by remember { mutableStateOf(emptyList<JSONObject>()) }
    var error by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        try { products = (api.get("/api/catalog") as JSONArray).objects() }
        catch(e: Exception) { error = e.message ?: "خطا در دریافت قیمت" }
        finally { loading = false }
    }
    if(loading) { LoadingPane(); return }
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SearchBox(query, {query=it}, "جستجوی کالا") }
        item { ErrorBanner(error) {error=""} }
        items(products.filter {it.b("available") && it.s("name").contains(query,true)}, key={it.s("name")}) { p ->
            Surface(shape=RoundedCornerShape(22.dp),color=Color.White,border=BorderStroke(1.dp,Border)) {
                Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Text(p.s("name"),fontSize=20.sp,fontWeight=FontWeight.Black,color=NavyDeep)
                    Text(if(p.i("stock")>0) "موجود" else "ناموجود",color=if(p.i("stock")>0) Success else Muted)
                    if(p.s("description").isNotBlank()) Text(p.s("description"),color=Muted)
                    val prices=p.obj("prices")
                    Text("سریال آزاد",color=Orange,fontWeight=FontWeight.Bold)
                    listOf("serial_1_50" to "۱ تا ۵۰", "serial_51_200" to "۵۱ تا ۲۰۰", "sales_agent" to "عامل فروش").forEach { (k,label) ->
                        DetailLine(label, if(prices.l(k)>0) "${formatMoney(prices.l(k))} تومان" else "—")
                    }
                    HorizontalDivider()
                    Text("ثبت در پنل شرکت",color=NavyDeep,fontWeight=FontWeight.Bold)
                    listOf("panel_cash" to "نقد", "panel_7d" to "هفت‌روزه", "panel_1m" to "یک‌ماهه").forEach { (k,label) ->
                        val price=if(k=="panel_cash") prices.optLong(k,p.l("price")) else prices.l(k)
                        DetailLine(label,if(price>0) "${formatMoney(price)} تومان" else "—")
                    }
                    GhadirButton("سفارش این کالا", onClick={onOrder(p.s("name"))}, enabled=p.i("stock")>0)
                }
            }
        }
        item { Text("اعتبار قیمت‌ها روزانه است؛ مبلغ نهایی پس از تأیید فروش مشخص می‌شود.",color=Muted,fontSize=11.sp) }
    }
}

@Composable
private fun ProfileAvatar(photo: String, name: String) {
    val bitmap = remember(photo) { runCatching {
        if(!photo.startsWith("data:image/") || photo.length>400000) null else {
            val bytes=Base64.decode(photo.substringAfter(","),Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes,0,bytes.size)?.asImageBitmap()
        }
    }.getOrNull() }
    Box(Modifier.size(64.dp).clip(CircleShape).background(Navy),contentAlignment=Alignment.Center) {
        if(bitmap!=null) Image(bitmap,"عکس پروفایل",Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
        else Text(name.take(1).ifBlank {"ق"},color=Color.White,fontSize=26.sp)
    }
}

@Composable
private fun PortalProfile(api: ApiClient, me: JSONObject, onUpdated: (JSONObject) -> Unit, onLogout: () -> Unit) {
    val initial = me.obj("customer")
    val scope = rememberCoroutineScope()
    var name by remember(me.toString()) { mutableStateOf(initial.s("name")) }
    var company by remember(me.toString()) { mutableStateOf(initial.s("company")) }
    var province by remember(me.toString()) { mutableStateOf(initial.s("province")) }
    var city by remember(me.toString()) { mutableStateOf(initial.s("city")) }
    var address by remember(me.toString()) { mutableStateOf(initial.s("address")) }
    var alternate by remember(me.toString()) { mutableStateOf(me.s("alternate_mobile")) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf("") }
    val context=LocalContext.current
    var photo by remember(me.toString()) { mutableStateOf(initial.s("profile_photo")) }
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if(uri!=null) scope.launch {
            try {
                photo=withContext(Dispatchers.IO) {
                    val bounds=BitmapFactory.Options().apply {inJustDecodeBounds=true}
                    context.contentResolver.openInputStream(uri).use {BitmapFactory.decodeStream(it,null,bounds)}
                    require(bounds.outWidth>0 && bounds.outHeight>0) {"عکس معتبر نیست"}
                    var sample=1
                    while(maxOf(bounds.outWidth,bounds.outHeight)/sample>1024) sample*=2
                    val opts=BitmapFactory.Options().apply {inSampleSize=sample}
                    val bitmap=context.contentResolver.openInputStream(uri).use {BitmapFactory.decodeStream(it,null,opts)} ?: throw IllegalArgumentException("عکس معتبر نیست")
                    val scale=minOf(1f,512f/maxOf(bitmap.width,bitmap.height))
                    val resized=Bitmap.createScaledBitmap(bitmap,maxOf(1,(bitmap.width*scale).toInt()),maxOf(1,(bitmap.height*scale).toInt()),true)
                    val output=ByteArrayOutputStream();resized.compress(Bitmap.CompressFormat.JPEG,82,output)
                    if(resized!==bitmap) bitmap.recycle();resized.recycle()
                    val encoded="data:image/jpeg;base64,"+Base64.encodeToString(output.toByteArray(),Base64.NO_WRAP)
                    require(encoded.length<=400000) {"حجم عکس زیاد است"};encoded
                }
            } catch(e:Exception) {error=e.message ?: "خواندن عکس ناموفق بود"}
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        item { Row(horizontalArrangement=Arrangement.spacedBy(12.dp),verticalAlignment=Alignment.CenterVertically) {
            ProfileAvatar(photo,name)
            TextButton(onClick={picker.launch("image/*")}) {Text("انتخاب عکس")}
            TextButton(onClick={photo=""}) {Text("حذف عکس")}
        } }
        item { HeroCard("حساب کاربری", name.ifBlank { me.s("username") }, company.ifBlank { "مشتری قدیر پارتنر" }, Icons.Default.VerifiedUser, emphasis = true) }
        item { ErrorBanner(error) { error = "" } }
        if (saved.isNotBlank()) item { Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFFE6F7EE)) { Text(saved, color = Success, modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.End, fontWeight = FontWeight.Bold) } }
        item { ProfileEditField("نام و نام خانوادگی", name) { name = it } }
        item { ProfileEditField("شرکت / فروشگاه", company) { company = it } }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Box(Modifier.weight(1f)) { ProfileEditField("استان", province) { province = it } }
                Box(Modifier.weight(1f)) { ProfileEditField("شهر", city) { city = it } }
            }
        }
        item {
            OutlinedTextField(
                value = address, onValueChange = { address = it; saved = "" }, modifier = Modifier.fillMaxWidth(), minLines = 2,
                label = { Text("آدرس") }, shape = RoundedCornerShape(17.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, unfocusedBorderColor = Border, focusedContainerColor = Color.White, unfocusedContainerColor = Color.White)
            )
        }
        item {
            OutlinedTextField(
                value = me.s("username"), onValueChange = {}, modifier = Modifier.fillMaxWidth(), readOnly = true, singleLine = true,
                label = { Text("شماره ورود") }, shape = RoundedCornerShape(17.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Border, disabledBorderColor = Border)
            )
        }
        item { ProfileEditField("شماره جایگزین – اختیاری", alternate) { alternate = it.filter(Char::isDigit).take(11) } }
        item {
            GhadirButton(if (saving) "در حال ذخیره..." else "ذخیره تغییرات پروفایل", enabled = !saving && name.trim().length >= 3, onClick = {
                scope.launch {
                    saving = true; error = ""; saved = ""
                    try {
                        val body = JSONObject().put("name", name).put("company", company).put("province", province).put("city", city).put("address", address).put("alternate_mobile", alternate).put("profile_photo", photo).put("postal_code", initial.s("postal_code"))
                        val result = api.post("/api/profile/update", body) as JSONObject
                        onUpdated(result); saved = "اطلاعات پروفایل با موفقیت بروزرسانی شد."
                    } catch (e: Exception) { error = e.message ?: "ذخیره پروفایل ناموفق بود" }
                    finally { saving = false }
                }
            })
        }
        item { GhadirButton("خروج از حساب", onLogout, secondary = true) }
        item { Text("نسخه Native ${BuildConfig.VERSION_NAME}", color = Muted, fontSize = 9.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
    }
}

@Composable
private fun ProfileEditField(title: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onValueChange, modifier = Modifier.fillMaxWidth(), singleLine = true,
        label = { Text(title) }, shape = RoundedCornerShape(17.dp),
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, unfocusedBorderColor = Border, focusedContainerColor = Color.White, unfocusedContainerColor = Color.White)
    )
}

@Composable
private fun <T> DropdownField(title: String, value: String, options: List<T>, display: (T) -> String, onSelect: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = value, onValueChange = {}, modifier = Modifier.fillMaxWidth().clickable { open = true }, readOnly = true, singleLine = true,
            label = { Text(title) }, trailingIcon = { Icon(Icons.Default.KeyboardArrowDown, null) }, shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, unfocusedBorderColor = Border, focusedContainerColor = Color.White, unfocusedContainerColor = Color.White)
        )
        Box(Modifier.matchParentSize().clickable { open = true })
        DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.fillMaxWidth(0.86f)) {
            options.forEach { option ->
                DropdownMenuItem(text = { Text(display(option), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End) }, onClick = { onSelect(option); open = false })
            }
        }
    }
}
