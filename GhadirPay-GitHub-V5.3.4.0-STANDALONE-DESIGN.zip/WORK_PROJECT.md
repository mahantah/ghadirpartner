# GhadirPartner V5.3.4.0

Design integration based on the released V5.3.3.1 archive; root repository app.html is older and is not the build input.
PHP/backend and customer portal files remain byte-identical to that release.
UI: app.html + assets/ghadir-ui. MySQL-only; config/storage must not be overwritten. Manual web deployment only.
See RELEASE_V5.3.4.0_FA.txt for installation and validation.
