<?php
return [
    'timezone' => 'Asia/Tehran',
    'warehouse_connected' => false,
    'storage' => __DIR__ . '/storage',
    // Homa CRM API جدید — روش اصلی: API Token
    'homa_api_token' => '',
    'homa_api_endpoint' => 'https://www.homacrm.com/api/v1/external/messaging/send',

    // اختیاری: fallback قدیمی فقط با username/password واقعی پنل
    'homa_legacy_fallback' => false,
    'homa_username' => '',
    'homa_password' => '',
    'homa_portal_code' => '',
    'homa_server_type' => '100',
    'homa_direct_endpoint' => 'https://api.homais.com/services/messaging/sms/api/sendMessage/direct/',
    'homa_otp_endpoint' => 'https://api.homais.com/services/messaging/sms/api/sendMessage/OTP/',

    // Token در پارامتر username ارسال می‌شود و password خالی می‌ماند.
    'homa_api_token' => '',
    'homa_portal_code' => '',
    'homa_server_type' => '100',
    'homa_direct_endpoint' => 'https://api.homais.com/services/messaging/sms/api/sendMessage/direct/',
    'homa_otp_endpoint' => 'https://api.homais.com/services/messaging/sms/api/sendMessage/OTP/',

    // سازگاری اختیاری با تنظیمات قدیمی؛ در اتصال Token نیازی به این دو نیست.
    'homa_username' => '',
    'homa_password' => '',

    // سرویس عمومی جایگزین؛ فقط در صورت استفاده از ارائه‌دهنده دیگری پر شود.
    'sms_endpoint' => '',
    'sms_token' => '',
    'payment_endpoint' => '',
];
