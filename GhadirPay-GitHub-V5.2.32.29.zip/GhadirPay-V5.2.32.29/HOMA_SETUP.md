# تنظیم Homa CRM — V5.2.32.29

روش اصلی این نسخه API جدید توکن‌محور هما است:

`https://www.homacrm.com/api/v1/external/messaging/send`

در `public_html/config.php` فقط این دو تنظیم برای روش جدید کافی است:

```php
'homa_api_token' => 'YOUR_API_TOKEN',
'homa_api_endpoint' => 'https://www.homacrm.com/api/v1/external/messaging/send',
```

OTP و پیامک‌های وضعیت سفارش هر دو از همین API جدید با پارامترهای `mobile` و `message` ارسال می‌شوند. برنامه ابتدا هدر `Authorization: Bearer` را امتحان می‌کند و فقط در خطای صریح احراز هویت، دو فرم رایج دیگر توکن را امتحان می‌کند. این retry فقط در خطای احراز هویت انجام می‌شود تا پیامک تکراری ارسال نشود.

## fallback قدیمی

فقط اگر واقعاً نام کاربری و رمز سرویس قدیمی را دارید:

```php
'homa_legacy_fallback' => true,
'homa_username' => '...',
'homa_password' => '...',
'homa_portal_code' => '...',
'homa_server_type' => '100',
```

توکن API جدید دیگر به عنوان `username` به `api.homais.com` ارسال نمی‌شود؛ این همان علت خطای `missing_credentials` نسخه قبل بود.

Token و اطلاعات واقعی نباید داخل GitHub قرار بگیرند.
