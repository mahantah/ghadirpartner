# GhadirPartner Android V5.4.3.5 — FIGMA EXACT

WebView wrapper for https://ghadirpartner.ir/partners/ with local Figma-exact CSS/JS injection.
Direct visual references: Figma nodes `6:2` (Profile) and `6:30` (Order Detail).
The web portal skin is injected locally as a fallback, while the same skin is also included in the Web V5.3.4.5 patch.
