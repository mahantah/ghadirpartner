package ir.ghadirpartner.portal;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import android.view.*;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 4404;
    private static final String HOME = "https://ghadirpartner.ir/partners/";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(11,31,58));
        getWindow().setNavigationBarColor(Color.rgb(245,247,250));
        web = new WebView(this);
        setContentView(web);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true); s.setUseWideViewPort(true); s.setSupportZoom(false);
        s.setUserAgentString(s.getUserAgentString()+" GhadirPartnerAndroid/5.4.3.5");
        CookieManager.getInstance().setAcceptCookie(true);
        if(Build.VERSION.SDK_INT>=21) CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){
                Uri u=r.getUrl(); String host=u.getHost();
                if(host!=null && (host.equals("ghadirpartner.ir")||host.endsWith(".ghadirpartner.ir"))) return false;
                startActivity(new Intent(Intent.ACTION_VIEW,u)); return true;
            }
            @Override public void onPageFinished(WebView v,String url){ super.onPageFinished(v,url); injectRedesign(); }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p){
                if(fileCallback!=null) fileCallback.onReceiveValue(null); fileCallback=cb;
                Intent i=p.createIntent(); try{startActivityForResult(i,FILE_CHOOSER);}catch(Exception e){fileCallback=null;Toast.makeText(MainActivity.this,"انتخاب فایل در دسترس نیست",Toast.LENGTH_SHORT).show();}
                return true;
            }
        });
        web.setDownloadListener((url,userAgent,contentDisposition,mimetype,contentLength)->download(url,userAgent,contentDisposition,mimetype));
        if(state==null) web.loadUrl(HOME); else web.restoreState(state);
    }

    private String asset(String name){
        try(InputStream in=getAssets().open(name); ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[8192]; int n; while((n=in.read(b))>0) out.write(b,0,n); return out.toString("UTF-8");
        }catch(Exception e){ return ""; }
    }
    private void injectRedesign(){
        String css=asset("redesign.css"), js=asset("redesign.js");
        String script="(function(){var o=document.getElementById('gp-native-redesign');if(!o){o=document.createElement('style');o.id='gp-native-redesign';document.head.appendChild(o);}o.textContent="+JSONObject.quote(css)+";try{"+js+"}catch(e){console.error(e);}})();";
        web.evaluateJavascript(script,null);
    }
    private void download(String url,String ua,String disposition,String mime){
        try{
            DownloadManager.Request r=new DownloadManager.Request(Uri.parse(url));
            r.addRequestHeader("User-Agent",ua); String c=CookieManager.getInstance().getCookie(url); if(c!=null)r.addRequestHeader("Cookie",c);
            String file=URLUtil.guessFileName(url,disposition,mime); r.setTitle(file); r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS,file);
            ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(r); Toast.makeText(this,"دانلود شروع شد",Toast.LENGTH_SHORT).show();
        }catch(Exception e){ startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url))); }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data); if(request!=FILE_CHOOSER||fileCallback==null)return;
        Uri[] out=WebChromeClient.FileChooserParams.parseResult(result,data); fileCallback.onReceiveValue(out); fileCallback=null;
    }
    @Override protected void onSaveInstanceState(Bundle out){ web.saveState(out); super.onSaveInstanceState(out); }
    @Override public void onBackPressed(){ if(web!=null&&web.canGoBack())web.goBack(); else super.onBackPressed(); }
}
