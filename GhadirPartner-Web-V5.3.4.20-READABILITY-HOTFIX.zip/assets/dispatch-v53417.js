(async()=>{'use strict';const button=document.querySelector('.toolbar button');if(button)button.disabled=true;await document.fonts.ready;
for(const original of [...document.querySelectorAll('.dispatchSheet')]){
 const template=original.cloneNode(true);const groups=[...original.querySelectorAll('.sections>.sectionCard')].map(s=>({shell:s.cloneNode(false),head:s.querySelector('.secHead').cloneNode(true),grid:s.querySelector('.secGrid').cloneNode(false),boxes:[...s.querySelectorAll('.infoBox')]}));
 let page=original,area=page.querySelector('.sections'),count=1;area.replaceChildren();
 function next(){const n=template.cloneNode(true);n.querySelector('.sections').replaceChildren();n.querySelectorAll('[id]').forEach(x=>x.removeAttribute('id'));const note=document.createElement('span');note.textContent=' · ادامه '+(++count);note.style.fontSize='2.6mm';n.querySelector('.metaRow').append(note);page.after(n);page=n;area=page.querySelector('.sections');}
 function section(g){const s=g.shell.cloneNode(false);s.append(g.head.cloneNode(true),g.grid.cloneNode(false));area.append(s);return s.lastElementChild;}
 function overflow(){return area.scrollHeight>area.clientHeight+1;}
 for(const g of groups){let grid=section(g);for(let box of g.boxes){grid.append(box);if(!overflow())continue;box.remove();if(!grid.children.length)grid.parentElement.remove();next();grid=section(g);grid.append(box);
 if(overflow()) {let val=box.querySelector('.iboxValue');const text=val.textContent;let rest=text;val.textContent='';while(rest){let lo=1,hi=rest.length,best=0;while(lo<=hi){let m=(lo+hi)>>1;val.textContent=rest.slice(0,m);if(!overflow()){best=m;lo=m+1}else hi=m-1;}if(!best)throw Error('فضای چاپ برای متن کافی نیست');val.textContent=rest.slice(0,best);rest=rest.slice(best);if(rest){next();grid=section(g);const b=box.cloneNode(true);grid.append(b);box=b;val=b.querySelector('.iboxValue');}} }
 }}
}
if(button)button.disabled=false;
})().catch(e=>{const b=document.querySelector('.toolbar');if(b){const p=document.createElement('p');p.textContent='چاپ آماده نیست: '+e.message;b.append(p);}});
