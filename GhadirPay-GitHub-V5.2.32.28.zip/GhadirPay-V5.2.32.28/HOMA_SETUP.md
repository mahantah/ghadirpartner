# اتصال Homa SMS — V5.2.32.26

در `config.php` ریشه پروژه این مقادیر را تنظیم کنید:

```php
'homa_api_token' => 'YOUR_API_TOKEN',
'homa_portal_code' => 'YOUR_PORTAL_CODE',
'homa_server_type' => '100',
'homa_direct_endpoint' => 'https://api.homais.com/services/messaging/sms/api/sendMessage/direct/',
'homa_otp_endpoint' => 'https://api.homais.com/services/messaging/sms/api/sendMessage/OTP/',
```

در روش Token، مقدار Token در پارامتر `username` ارسال می‌شود و `password` خالی است.

- OTP فراموشی رمز: `sendMessage/OTP/`
- پیام‌های آماده ارسال، ارسال شد، تحویل شد، کد مرسوله و تست: `sendMessage/direct/`

از این نسخه تنظیمات Homa پرتال مشتری از `config.php` ریشه خوانده می‌شود؛ نیازی به تکرار Token در `partners/config.php` نیست.

پس از تنظیم، در اتوماسیون به «پرتال مشتریان» بروید و از بخش «پیامک‌های هما» یک پیامک تست ارسال کنید. وضعیت ارسال و HTTP در همان جدول نمایش داده می‌شود.


### عیب‌یابی V5.2.32.28
در بخش مدیریت پرتال > پیامک‌های هما، پاسخ خام سرویس، HTTP، کد نتیجه و Endpoint نمایش داده می‌شود. در API قدیمی HomaIS پاسخ موفق باید شناسه عددی بزرگ‌تر از 1000 باشد.
