# Homa CRM — V5.2.32.42

این نسخه بر پایه V5.2.32.33 پایدار است و ارسال API جدید هما با فیلد `recipient` را حفظ و در تغییر وضعیت سفارش/OTP استفاده می‌کند.

در `public_html/config.php` روی سرور (نه GitHub) تنظیم شود:

```php
'homa_api_token' => 'YOUR_REAL_TOKEN',
'homa_api_endpoint' => 'https://www.homacrm.com/api/v1/external/messaging/send',
'homa_sender_number' => '50004310005294',
'homa_sender_field' => 'sender',
```

در API جدید، شماره مقصد با فیلد `recipient` و متن با `message` ارسال می‌شود.

توکن واقعی، `config.php` و داده زنده نباید داخل GitHub یا ZIP انتشار قرار بگیرند.

لاگ ارسال شامل HTTP status، error code، requestId، endpoint و raw response است.


### مدیریت متن پیامک‌ها
از بخش پرتال مشتریان → پیامک هما، متن‌های پیش‌فرض به تفکیک امنیت، سفارش، وضعیت سفارش، رهگیری و پرداخت قابل ویرایش و غیرفعال‌سازی هستند. تنظیمات در Data اصلی ذخیره می‌شود و config.php شامل متن پیامک نیست.

### خط فرستنده پیامک
در ارسال Token API، سامانه خط `50004310005294` را به عنوان شماره فرستنده در payload می‌فرستد. نام فیلد پیش‌فرض `sender` است و اگر Homa نام دیگری اعلام کند فقط مقدار `homa_sender_field` در `config.php` تغییر می‌کند.
