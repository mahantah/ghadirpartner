(()=>{
'use strict';

const selected = window.GP_CARTON_LABEL_SELECTION || new Set();
window.GP_CARTON_LABEL_SELECTION = selected;

function cartons(){ return Array.isArray(window.WH?.cartons) ? WH.cartons : []; }
function byCode(code){ return cartons().find(c=>String(c.code||'').trim()===String(code||'').trim()); }

function visibleCartonCheckboxes(){
  return [...document.querySelectorAll('#warehouseBody .gp-carton-label-check')]
    .filter(cb=>!cb.closest('tr')?.hidden);
}

function syncSelectedCount(){
  const badge=document.getElementById('gpSelectedCartonCount');
  if(badge) badge.textContent=`${selected.size.toLocaleString('fa-IR')} کارتن انتخاب شده`;
  const printBtn=document.getElementById('gpPrintSelectedCartons');
  const pdfBtn=document.getElementById('gpPdfSelectedCartons');
  if(printBtn) printBtn.disabled=selected.size===0;
  if(pdfBtn) pdfBtn.disabled=selected.size===0;

  const master=document.getElementById('gpSelectVisibleCartons');
  if(master){
    const visible=visibleCartonCheckboxes();
    const checked=visible.filter(cb=>cb.checked);
    master.checked=visible.length>0 && checked.length===visible.length;
    master.indeterminate=checked.length>0 && checked.length<visible.length;
  }
}

function decorateRows(){
  const body=document.getElementById('warehouseBody');
  if(!body)return;

  [...body.rows].forEach(row=>{
    const codeEl=row.querySelector('td:first-child .code');
    if(!codeEl)return;
    const c=byCode(codeEl.textContent);
    if(!c)return;

    row.dataset.cartonId=String(c.id);
    const cell=row.cells[0];
    if(cell.querySelector('.gp-carton-label-check'))return;

    const wrap=document.createElement('label');
    wrap.className='gp-carton-check-wrap';
    wrap.title='انتخاب این کارتن برای چاپ لیبل';

    const cb=document.createElement('input');
    cb.type='checkbox';
    cb.className='gp-carton-label-check';
    cb.value=String(c.id);
    cb.checked=selected.has(Number(c.id));
    cb.setAttribute('aria-label',`انتخاب کارتن ${c.code} برای چاپ لیبل`);
    cb.addEventListener('click',e=>e.stopPropagation());
    cb.addEventListener('change',()=>{
      const id=Number(cb.value);
      if(cb.checked)selected.add(id); else selected.delete(id);
      syncSelectedCount();
    });

    wrap.append(cb);
    cell.insertBefore(wrap,cell.firstChild);
  });

  syncSelectedCount();
}

function installToolbar(){
  const warehouse=document.getElementById('warehouse');
  const body=document.getElementById('warehouseBody');
  const listCard=body?.closest('.card');
  if(!warehouse||!listCard||document.getElementById('gpCartonSelectToolbar'))return;

  const box=document.createElement('div');
  box.id='gpCartonSelectToolbar';
  box.className='gp-carton-select-toolbar';
  box.innerHTML=`
    <div class="gp-carton-select-title">
      <b>چاپ انتخابی لیبل کارتن</b>
      <span class="small">کارتن‌های موردنظر را تیک بزنید؛ دیگر لازم نیست فقط با بازه تاریخ چاپ کنید.</span>
    </div>
    <div class="gp-carton-select-actions">
      <label class="gp-select-all-label"><input id="gpSelectVisibleCartons" type="checkbox"> انتخاب همه کارتن‌های نمایش‌داده‌شده</label>
      <span id="gpSelectedCartonCount" class="badge">۰ کارتن انتخاب شده</span>
      <button id="gpPrintSelectedCartons" class="btn2" type="button">چاپ لیبل انتخابی TSC</button>
      <button id="gpPdfSelectedCartons" class="btnlight" type="button">PDF A4 انتخابی</button>
      <button id="gpClearCartonSelection" class="btnlight" type="button">پاک کردن انتخاب‌ها</button>
    </div>`;

  listCard.insertBefore(box,listCard.querySelector('.tablewrap'));

  document.getElementById('gpSelectVisibleCartons').addEventListener('change',e=>{
    const checked=e.target.checked;
    visibleCartonCheckboxes().forEach(cb=>{
      cb.checked=checked;
      const id=Number(cb.value);
      if(checked)selected.add(id); else selected.delete(id);
    });
    syncSelectedCount();
  });

  document.getElementById('gpClearCartonSelection').onclick=()=>{
    selected.clear();
    document.querySelectorAll('.gp-carton-label-check').forEach(cb=>cb.checked=false);
    syncSelectedCount();
  };

  document.getElementById('gpPrintSelectedCartons').onclick=()=>printSelectedWarehouseCartons();
  document.getElementById('gpPdfSelectedCartons').onclick=()=>pdfSelectedWarehouseCartons();

  syncSelectedCount();
}

window.selectedWarehouseCartonIds=function(){
  return [...selected].filter(id=>cartons().some(c=>Number(c.id)===Number(id)));
};

window.printSelectedWarehouseCartons=function(){
  const ids=selectedWarehouseCartonIds();
  if(!ids.length)return alert('حداقل یک کارتن را از لیست تیک بزنید.');
  window.open('/print/warehouse-labels?ids='+encodeURIComponent(ids.join(',')),'_blank');
};

window.pdfSelectedWarehouseCartons=function(){
  const ids=selectedWarehouseCartonIds();
  if(!ids.length)return alert('حداقل یک کارتن را از لیست تیک بزنید.');
  window.open('/print/warehouse-carton-labels?pdf=1&ids='+encodeURIComponent(ids.join(',')),'_blank');
};

// Make the existing main warehouse print action selection-first.
// If nothing is selected, do not accidentally print an entire date range.
window.printWarehouseCartonLabels=function(){
  const ids=selectedWarehouseCartonIds();
  if(!ids.length)return alert('کارتن‌های موردنظر را از ستون شماره باکس تیک بزنید.');
  window.open('/print/warehouse-labels?ids='+encodeURIComponent(ids.join(',')),'_blank');
};

window.downloadWarehouseCartonLabels=function(){
  const ids=selectedWarehouseCartonIds();
  if(!ids.length)return alert('کارتن‌های موردنظر را از ستون شماره باکس تیک بزنید.');
  window.open('/print/warehouse-carton-labels?pdf=1&ids='+encodeURIComponent(ids.join(',')),'_blank');
};

const baseRender=window.renderWarehouse;
window.renderWarehouse=function(){
  baseRender.apply(this,arguments);
  installToolbar();
  decorateRows();
};

const baseLoad=window.loadWarehouse;
window.loadWarehouse=async function(){
  const r=await baseLoad.apply(this,arguments);
  installToolbar();
  decorateRows();
  return r;
};

// Redesign toolbar button should print selected cartons directly.
function bindTopPrintButton(){
  const b=document.getElementById('gpWhPrint');
  if(!b||b.dataset.selectionBound==='1')return;
  b.dataset.selectionBound='1';
  b.textContent='چاپ لیبل انتخابی';
  b.onclick=()=>printSelectedWarehouseCartons();
}

// Keep selection controls synced when search/filter hides rows.
const observer=new MutationObserver(()=>{decorateRows();syncSelectedCount();bindTopPrintButton();});
const wh=document.getElementById('warehouse');
if(wh)observer.observe(wh,{subtree:true,childList:true,attributes:true,attributeFilter:['hidden','style']});

setTimeout(()=>{
  installToolbar();
  decorateRows();
  bindTopPrintButton();

  const printCard=document.querySelector('#warehouse .gp-wh-panel:not(.gp-wh-entry)');
  if(printCard){
    const small=printCard.querySelector('.section-title .small');
    if(small)small.textContent='برای چاپ دقیق، کارتن‌های موردنظر را از جدول پایین تیک بزنید. فیلتر تاریخ و مدل فقط به‌عنوان ابزار جانبی باقی مانده است.';
  }
},150);
})();